from data.preparer import *
from model3 import *


def main():
    print("DiGCN++: A Multiplex Directional Graph Convolutional Neural Network")
    # Data

    # Karate dataset
    udgraph = load_data_karate_undirected()
    # dgraph = load_data_karate_directed()
    # g1, g2 = load_data_karate_directed_multiplex()

    # # Cora dataset
    # udgraph = load_data_cora_undirected()
    # dgraph = load_data_cora_directed()

    # # Citeseer dataset
    # udgraph = load_data_citeseer_undirected()
    # dgraph = load_data_citeseer_directed()

    # # Model 1 GCN with LayerNorm
    # hp1 = Hyperparameters()
    # hp1.add('trials', 1)
    # hp1.add('K', 1)
    # hp1.add('number_of_epochs', 100)
    # hp1.add('patience', 100)
    # hp1.add('split', 70)
    # hp1.add('batch_size', udgraph.number_of_nodes)
    # hp1.add('regularization_rate', 0.0005)
    # hp1.add('learning_rate', 0.001)
    # hp1.add('dropout_rate', 0.5)
    # hp1.add('layer_norm_rate', 0.001)
    # hp1.add('input_layer_dimension', udgraph.dimensions)
    # hp1.add('layer_1_dimension', 16)
    # hp1.add('layer_2_dimension', 16)
    # hp1.add('layer_3_dimension', 16)
    # hp1.add('output_layer_dimension', udgraph.number_of_classes)
    #
    # # Model 2 DiGCN with LayerNorm
    # hp2 = Hyperparameters()
    # hp2.add('trials', 1)
    # hp2.add('K', 1)
    # hp2.add('number_of_epochs', 100)
    # hp2.add('patience', 100)
    # hp2.add('split', 70)
    # hp2.add('batch_size', dgraph.number_of_nodes)
    # hp2.add('regularization_rate', 0.0005)
    # hp2.add('learning_rate', 0.005)
    # hp2.add('dropout_rate', 0.5)
    # hp2.add('layer_norm_rate', 0.001)
    # hp2.add('input_layer_dimension', dgraph.dimensions)
    # hp2.add('layer_1_dimension', 16)
    # hp2.add('layer_2_dimension', 16)
    # hp2.add('layer_3_dimension', 16)
    # hp2.add('output_layer_dimension', dgraph.number_of_classes)

    # Model 3 Vanilla GCN
    hp3 = Hyperparameters()
    hp3.add("trials", 1)
    hp3.add("K", 1)
    hp3.add("epochs", 100)
    hp3.add("patience", 100)
    hp3.add("split", 70)
    hp3.add("batch_size", udgraph.number_of_nodes)
    hp3.add("regularization_rate", 0.0005)
    hp3.add("learning_rate", 0.001)
    hp3.add("dropout_rate", 0.5)
    hp3.add('input_layer_dimension', udgraph.dimensions)
    hp3.add('layer_1_dimension', 16)
    hp3.add('layer_2_dimension', 16)
    hp3.add('layer_3_dimension', 16)
    hp3.add('output_layer_dimension', udgraph.number_of_classes)

    # # Model 4 Vanilla DiGCN
    # hp4 = Hyperparameters()
    # hp4.add("trials", 1)
    # hp4.add("K", 1)
    # hp4.add("epochs", 100)
    # hp4.add("patience", 100)
    # hp4.add("split", 70)
    # hp4.add("batch_size", dgraph.number_of_nodes)
    # hp4.add("regularization_rate", 0.0005)
    # hp4.add("learning_rate", 0.001)
    # hp4.add("dropout_rate", 0.5)
    # hp4.add('input_layer_dimension', dgraph.dimensions)
    # hp4.add('layer_1_dimension', 16)
    # hp4.add('layer_2_dimension', 16)
    # hp4.add('layer_3_dimension', 16)
    # hp4.add('output_layer_dimension', dgraph.number_of_classes)

    # # Model 5 DiGCN++
    # hp5 = Hyperparameters()
    # hp5.add("trials", 1)
    # hp5.add("K", 1)
    # hp5.add("epochs", 100)
    # hp5.add("split_1", 60)
    # hp5.add("split_2", 60)
    # hp5.add("batch_size_1", g1.number_of_nodes)
    # hp5.add("batch_size_2", g2.number_of_nodes)
    # hp5.add("regularization_rate", 0.0005)
    # hp5.add("learning_rate", 0.001)
    # hp5.add("dropout_rate", 0.5)
    # hp5.add("input_layer_dimension", 16)
    # hp5.add("layer_1_dimension", 16)
    # hp5.add("layer_2_dimension", 8)
    # hp5.add("output_layer_dimension", 8)

    # Test all models -----------------------------------

    # m1 = Model1(hp1, udgraph)
    # all_accuracies_1 = m1.run()
    # m2 = Model2(hp2, dgraph)
    # all_accuracies_2 = m2.run()
    m3 = Model3(hp3, udgraph)
    all_accuracies_3 = m3.run()
    # m4 = Model4(hp4, dgraph)
    # all_accuracies_4 = m4.run()
    # m5 = Model5(hp5, g1, g2)
    # all_accuracies_5 = m5.run()

    # Experiments --------------------------------------

    # # Experiment 1 DiGCN with LayerNorm vs GCN with LayerNorm
    # m1 = Model1(hp1, udgraph)
    # all_accuracies_1 = m1.run()
    # m2 = Model2(hp2, dgraph)
    # all_accuracies_2 = m2.run()
    # Statistics.t_test(all_accuracies_1, all_accuracies_2)

    # Experiement 2 DiGCN without LayerNorm vs GCN without LayerNorm
    # m3 = Model3(hp3, udgraph)
    # all_accuracies_1 = m3.run()
    # m4 = Model4(hp4, dgraph)
    # all_accuracies_2 = m4.run()
    # Statistics.t_test(all_accuracies_1, all_accuracies_2)

    # # Experiment 3 GCN with and without LayerNorm
    # m1 = Model1(hp1, udgraph)
    # all_accuracies_1 = m1.run()
    # m2 = Model3(hp3, udgraph)
    # all_accuracies_2 = m2.run()
    # Statistics.t_test(all_accuracies_1, all_accuracies_2)
    # # Result for running 5X5
    # # shapiro-statistic for Model 1 = 0.770907929148208
    # # p-value = 0.04595431355090931
    # # shapiro-statistic for Model 2 = 0.8834906936019795
    # # p-value = 0.32542950716411834
    # # t-statistic = -1.632993161855452
    # # p-value = 0.08890390417811063
    # # alternative being that with LayerNorm the model has less accuracy than without LayerNorm.
    # # null being that without LayerNorm the model has less accuracy than with LayerNorm.
    # # Some slightly significant evidence that LayerNorm does NOT improve model accuracy.
    # # We also have some slightly significant evidence that BatchNorm does NOT improve model performance.
    # # Possibly due to small batch size which leads to increasing the covariance shift between train and test not decrease it as intended.

    # # Experiement 4 DiGCN++
    # m5 = Model5(hp5, g1, g2)
    # all_accuracies_1 = m5.run()
    # print(all_accuracies_1)


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    main()
