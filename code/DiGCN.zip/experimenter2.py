import matplotlib.pyplot as plt

from grapher import *


class TanhActivationOperation:
    def __init__(self, input, shape: Shape):
        self.input = input
        self.output = None
        self.shape = shape
        self.e = tf.Variable(Utils.random_uniform(self.shape.batch_size, self.shape.out_size), trainable=True)

    def collect(self):
        return [self.e]

    def compute(self, parameters):
        self.output = tf.add(tf.nn.tanh(self.input.output), parameters[0])


class NormalizeOperation:
    def __init__(self, input, shape: Shape):
        self.input = input
        self.output = None
        self.shape = shape
        self.e = tf.Variable(Utils.random_uniform(self.shape.batch_size, self.shape.out_size), trainable=True)

    def collect(self):
        return [self.e]

    def compute(self, parameters):
        self.embedding = tf.add(tf.nn.l2_normalize(tf.convert_to_tensor(self.input.output), axis=1), parameters[0])
        self.output = self.input.output


class DropoutOperation:
    def __init__(self, input, shape: Shape, rate: float):
        self.input = input
        self.output = None
        self.shape = shape
        self.rate = rate
        self.e = tf.Variable(Utils.random_uniform(self.shape.batch_size, self.shape.out_size), trainable=True)

    def collect(self):
        return [self.e]

    def compute(self, parameters):
        self.output = tf.add(tf.nn.dropout(self.input.output, self.rate), parameters[0])


class RegularizeOperation:
    def __init__(self, input, shape: Shape, rate: float):
        self.input = input
        self.output = None
        self.regularization_constant = None
        self.shape = shape
        self.rate = rate
        self.e = tf.Variable(Utils.random_uniform(self.shape.batch_size, self.shape.out_size), trainable=True)

    def collect(self):
        return [self.e]

    def compute(self, parameters):
        r = tf.keras.regularizers.L2(self.rate)
        error_term = tf.reduce_mean(parameters[0])
        r_constant = r(self.input.output)
        self.regularization_constant = tf.add(r_constant,error_term)
        self.output = self.input.output


class GraphConvolutionOperation:
    def __init__(self, input, adjacency, shape: Shape):
        self.input = input
        self.output = None
        self.shape = shape
        self.X = tf.convert_to_tensor(self.input)
        self.adjacency = tf.convert_to_tensor(adjacency, dtype=tf.float32)

        self.W = tf.Variable(Utils.glorot_intializer(self.shape.in_size, self.shape.out_size), trainable=True)
        self.b = tf.Variable(Utils.glorot_intializer(self.shape.batch_size, self.shape.out_size), trainable=True)
        self.e = tf.Variable(Utils.random_uniform(self.shape.batch_size, self.shape.out_size), trainable=True)

    def collect(self):
        return [self.W, self.b, self.e]

    def compute(self, parameters):
        self.output = tf.add(tf.add(tf.matmul(tf.matmul(self.adjacency, self.X), parameters[0]), parameters[1]), parameters[2])


class DirectionalGraphConvolutionOperation:
    def __init__(self, input, in_adjacency, out_adjacency, shape: Shape):
        self.input = input
        self.output = None
        self.shape = shape
        self.X = tf.convert_to_tensor(self.input)
        self.in_adjacency = in_adjacency
        self.out_adjacency = out_adjacency
        # Parameters
        self.W_in = tf.Variable(Utils.glorot_intializer(self.shape.in_size, self.shape.out_size), trainable=True)
        self.W_out = tf.Variable(Utils.glorot_intializer(self.shape.in_size, self.shape.out_size), trainable=True)
        self.b_in = tf.Variable(Utils.glorot_intializer(self.shape.batch_size, self.shape.out_size), trainable=True)
        self.b_out = tf.Variable(Utils.glorot_intializer(self.shape.batch_size, self.shape.out_size), trainable=True)
        self.e_in = tf.Variable(Utils.random_uniform(self.shape.batch_size, self.shape.out_size), trainable=True)
        self.e_out = tf.Variable(Utils.random_uniform(self.shape.batch_size, self.shape.out_size), trainable=True)
        self.W_all = tf.Variable(Utils.glorot_intializer(self.shape.batch_size, self.shape.batch_size), trainable=True)
        self.b_all = tf.Variable(Utils.glorot_intializer(self.shape.batch_size, self.shape.out_size), trainable=True)
        self.e_all = tf.Variable(Utils.random_uniform(self.shape.batch_size, self.shape.out_size), trainable=True)

    def collect(self):
        return [self.W_in, self.W_out, self.b_in, self.b_out, self.e_in, self.e_out, self.W_all, self.b_all, self.e_all]

    def compute(self, parameters):
        a = tf.add(tf.add(tf.matmul(
            tf.matmul(tf.convert_to_tensor(self.out_adjacency, dtype=tf.float32),
                      self.X), parameters[1]), parameters[3]), parameters[5])
        aT = tf.transpose(a)
        b = tf.add(tf.add(tf.matmul(
            tf.matmul(tf.convert_to_tensor(self.in_adjacency, dtype=tf.float32),
                      self.X), parameters[0]), parameters[2]), parameters[4])
        bT = tf.transpose(b)
        directed_formula = tf.add_n([tf.matmul(a, aT), tf.matmul(a, bT), tf.matmul(b, aT), tf.matmul(b, bT)])
        self.output = tf.add(tf.matmul(tf.add(directed_formula, parameters[6]), parameters[7]), parameters[8])


class DenseOperation:
    def __init__(self, input, shape: Shape):
        self.input = input
        self.output = None
        self.shape = shape

        # Parameters
        self.W = tf.Variable(Utils.glorot_intializer(self.shape.in_size, self.shape.out_size), trainable=True)
        self.b = tf.Variable(Utils.glorot_intializer(self.shape.batch_size, self.shape.out_size), trainable=True)
        self.e = tf.Variable(Utils.random_uniform(self.shape.batch_size, self.shape.out_size), trainable=True)

    def collect(self):
        return [self.W, self.b, self.e]

    def compute(self, parameters):
        self.output = tf.add(tf.add(tf.matmul(self.input.output, parameters[0]), parameters[1]), parameters[2])


class ResidualOperation:
    def __init__(self, input1, input2, shape: Shape):
        self.input1 = input1
        self.input2 = input2
        self.output = None
        self.shape = shape
        # Parameters
        self.M = tf.Variable(Utils.glorot_intializer(self.shape.in_size, self.shape.out_size), trainable=True)
        self.b = tf.Variable(Utils.glorot_intializer(self.shape.batch_size, self.shape.out_size), trainable=True)
        self.e = tf.Variable(Utils.random_uniform(self.shape.batch_size, self.shape.out_size), trainable=True)

    def collect(self):
        return [self.M, self.b, self.e]

    def compute(self, parameters):
        self.output = tf.add(
            tf.add(self.input2.output, tf.add(tf.matmul(self.input1.output, parameters[0]), parameters[1])),
            parameters[2])


class SoftmaxPredictionOperation:
    def __init__(self, input, shape: Shape):
        self.input = input
        self.output = None
        self.shape = shape
        self.e = tf.Variable(Utils.random_uniform(self.shape.batch_size, self.shape.out_size), trainable=True)

    def collect(self):
        return [self.e]

    def compute(self, parameters):
        predictions = tf.map_fn(fn=lambda i: tf.nn.softmax(i), elems=self.input.output)
        self.output = tf.add(predictions, parameters[0])


class Model:
    def __init__(self, graph):
        self.graph = graph

        # Hyperparameters
        self.K = 10
        self.epochs = 40
        self.patience = 100
        self.split = 80
        self.residual = True
        self.batch_normalization = True
        self.batch_size = self.graph.number_of_nodes
        self.regularization_rate = 0.0005
        self.learning_rate = 0.005
        self.dropout_rate = 0.5
        self.activation = "tanh"
        self.input_layer_dimension = 16
        self.layer_1_dimension = 16
        self.layer_2_dimension = 4
        self.output_layer = self.graph.number_of_classes
        self.layer_1_dimensions = Shape(input=self.input_layer_dimension, output=self.layer_1_dimension, batch_size=self.batch_size)
        self.layer_2_dimensions = Shape(input=self.layer_1_dimension, output=self.layer_2_dimension, batch_size=self.batch_size)
        self.layer_3_dimensions = Shape(input=self.layer_2_dimension, output=self.output_layer, batch_size=self.batch_size)

        # Extract training, test and validation data
        self.train_mask, self.test_mask, self.valid_mask = self.graph.balanced_node_label_sampler(self.split)
        self.graph.prepare_training_data(self.input_layer_dimension)

        self.parameters = []

    def compile(self):
        # First DGCN layer
        # self.layer_1_operation_1 = DirectionalGraphConvolutionOperation(self.graph.features,
        #                                                                 self.graph.degree_normalized_weighted_in_adjacency,
        #                                                                 self.graph.degree_normalized_weighted_out_adjacency,
        #                                                                 self.layer_1_dimensions)
        self.layer_1_operation_1 = GraphConvolutionOperation(input=self.graph.features,
                                                             adjacency=self.graph.degree_normalized_adjacency,
                                                             shape=self.layer_1_dimensions)
        self.layer_1_operation_2 = TanhActivationOperation(input=self.layer_1_operation_1, shape=self.layer_1_dimensions)
        self.layer_1_operation_3 = ResidualOperation(input1=self.layer_1_operation_1, input2=self.layer_1_operation_2,
                                                     shape=self.layer_1_dimensions)
        self.layer_1_operation_4 = RegularizeOperation(input=self.layer_1_operation_3,
                                                       rate=self.regularization_rate, shape=self.layer_1_dimensions)
        self.layer_1_operation_5 = NormalizeOperation(input=self.layer_1_operation_4, shape=self.layer_1_dimensions)
        self.layer_1_operation_6 = DropoutOperation(input=self.layer_1_operation_5, shape=self.layer_1_dimensions,
                                                    rate=self.dropout_rate)

        # Second Dense layer
        self.layer_2_operation_1 = DenseOperation(input=self.layer_1_operation_6, shape=self.layer_2_dimensions)

        # Third Prediction layer
        self.layer_3_operation_1 = SoftmaxPredictionOperation(input=self.layer_2_operation_1,
                                                              shape=self.layer_3_dimensions)

    def compute(self):
        self.layer_1_operation_1.compute(self.parameters[0])
        self.layer_1_operation_2.compute(self.parameters[1])
        self.layer_1_operation_3.compute(self.parameters[2])
        self.layer_1_operation_4.compute(self.parameters[3])
        self.layer_1_operation_5.compute(self.parameters[4])
        self.layer_1_operation_6.compute(self.parameters[5])

        self.layer_2_operation_1.compute(self.parameters[6])

        self.layer_3_operation_1.compute(self.parameters[7])

        self.predictions = tf.convert_to_tensor(self.layer_3_operation_1.output)
        self.regularization_constant = self.layer_1_operation_4.regularization_constant
        self.embedding = self.layer_1_operation_5.embedding

    # def collect(self):
    #     self.parameters = []
    #     self.parameters = self.parameters + self.layer_1_operation_1.collect()
    #     self.parameters = self.parameters + self.layer_1_operation_2.collect()
    #     self.parameters = self.parameters + self.layer_1_operation_3.collect()
    #     self.parameters = self.parameters + self.layer_1_operation_4.collect()
    #     self.parameters = self.parameters + self.layer_1_operation_5.collect()
    #     self.parameters = self.parameters + self.layer_1_operation_6.collect()
    #
    #     self.parameters = self.parameters + self.layer_2_operation_1.collect()
    #
    #     self.parameters = self.parameters + self.layer_3_operation_1.collect()

    def collect(self):
        self.parameters.append(self.layer_1_operation_1.collect())
        self.parameters.append(self.layer_1_operation_2.collect())
        self.parameters.append(self.layer_1_operation_3.collect())
        self.parameters.append(self.layer_1_operation_4.collect())
        self.parameters.append(self.layer_1_operation_5.collect())
        self.parameters.append(self.layer_1_operation_6.collect())

        self.parameters.append(self.layer_2_operation_1.collect())

        self.parameters.append(self.layer_3_operation_1.collect())

        # self.parameters = Utils.flatten_extend(self.parameters)

    def train(self):
        for epoch in tf.range(self.epochs):
            # x=tf.Variable(Utils.glorot_intializer(16, 16), trainable=True)
            # with tf.GradientTape() as g:
            #     # g.watch(x)
            #     y = tf.reduce_mean(x * x)
            # dy_dx = g.gradient(y, [[x]])
            # print(dy_dx)

            # Timing
            start_time = time.perf_counter()
            # Train
            # x = tf.Variable(Utils.glorot_intializer(16, 16), trainable=True)
            # self.parameters = Utils.flatten_extend(self.parameters)

            with tf.GradientTape() as tape:
                # for p in self.parameters:
                #     tape.watch(p)
                # y = tf.reduce_mean(x * x)
                # tape.watch(self.parameters)

                self.compute()

                self.train_loss = Utils.masked_cross_entropy_loss_evaluater(self.predictions,
                                                                            self.graph.y, self.regularization_constant,
                                                                            self.train_mask)
                self.train_accuracy = Utils.masked_accuracy_evaluater(self.predictions, self.graph.y, self.train_mask)

            # self.parameters = Utils.flatten_extend(self.parameters)

            self.gradients = tape.gradient(self.train_loss, self.parameters)

            Utils.optimizer(self.learning_rate).apply_gradients(list(zip(self.gradients, self.parameters)))
            # Utils.optimizer(self.learning_rate).apply_gradients(self.gradients, self.parameters)
            pass

            # Test

            self.test_loss = Utils.masked_cross_entropy_loss_evaluater(self.predictions, self.graph.y,
                                                                       self.regularization_constant,
                                                                       self.test_mask)
            self.test_accuracy = Utils.masked_accuracy_evaluater(self.predictions, self.graph.y,
                                                                 self.test_mask)

            # Update
            #
            # self.collect()
            # self.compute()

            self.compute()

            # Timing
            end_time = time.perf_counter()

            # Print Information
            self.time_per_epoch = tf.constant(round((end_time - start_time), 3), dtype=tf.float32)
            tf.print(" Epoch: " + tf.strings.as_string(epoch)
                     + " Seconds/Epoch: " + tf.strings.as_string(self.time_per_epoch)
                     + " Learning Rate: " + tf.strings.as_string(
                tf.constant(round(self.learning_rate, 3), dtype=tf.float32))
                     + " Train Loss: " + tf.strings.as_string(self.train_loss)
                     + " Train Accuracy: " + tf.strings.as_string(self.train_accuracy)
                     + " Test Loss: " + tf.strings.as_string(self.test_loss)
                     + " Test Accuracy: " + tf.strings.as_string(self.test_accuracy)
                     )

            plt.plot(epoch, self.test_loss, label='loss')
            plt.plot(epoch, self.test_accuracy, label='accuracy')
            plt.legend()
            _ = plt.xlabel('epoch')
            plt.show()


def main():
    print("PubMed2Characters2Vec")
    # Prep Data
    G = nx.karate_club_graph()
    raw_data = []
    for edge in G.edges():
        raw_data.append((str(edge[0]), str(edge[1]), float(random.randint(1, 10))))
    graph = DirectedGraph(edges=raw_data)
    graph.create_node_labels(True)
    m1 = Model(graph)
    m1.compile()
    m1.collect()
    m1.compute()
    m1.train()


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    main()
