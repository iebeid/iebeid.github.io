import sys
import time
import re
import random
import chardet
import pickle
import gc
import tracemalloc
from operator import itemgetter
from copy import deepcopy
from contextlib import redirect_stdout

import collections.abc
from collections import defaultdict
from collections import Counter
from collections import deque

from itertools import chain
from tqdm import tqdm

import numpy as np
import scipy as sp
import pandas as pd
import networkx as nx

import sklearn as skl
from sklearn.manifold import TSNE
import tensorflow as tf
from tensorflow.keras.layers import Input, Lambda
from tensorflow.python.keras.backend import dtype
from tensorflow_graphics.math import math_helpers

from gensim.test.utils import common_texts
from gensim.models import KeyedVectors
from gensim.models import Word2Vec
from Levenshtein import distance, ratio

import matplotlib.pyplot as plt
import seaborn as sns

print("Numpy Version: ", np.version.version)
print("Tensorflow Version: ", tf.__version__)
print("Keras Version: ", tf.keras.__version__)

random.seed(123)
np.random.seed(123)
np.set_printoptions(threshold=np.inf)
tf.random.set_seed(123)
tf.config.run_functions_eagerly(False)
tf.config.threading.set_inter_op_parallelism_threads(8)
