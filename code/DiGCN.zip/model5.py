from models.directgcn.tensorflow.encoder import *


class Model5(Model):
    def __init__(self, hp, graph1, graph2):
        super(Model5, self).__init__()
        self.hp = hp
        self.graph1 = graph1
        self.graph2 = graph2

    def prepare(self):
        # Hyperparameters
        self.trials = self.hp.get("trials")
        self.K = self.hp.get("K")
        self.number_of_epochs = self.hp.get("epochs")

        self.split1 = self.hp.get("split_1")
        self.split2 = self.hp.get("split_2")
        self.batch_size_1 = self.hp.get("batch_size_1")
        self.batch_size_2 = self.hp.get("batch_size_2")

        self.input_layer_dimension = self.hp.get('input_layer_dimension')
        self.layer_1_dimension = self.hp.get('layer_1_dimension')
        self.layer_2_dimension = self.hp.get('layer_2_dimension')
        self.output_layer_dimension = self.hp.get('output_layer_dimension')

        self.regularization_rate = self.hp.get("regularization_rate")
        self.learning_rate = self.hp.get("learning_rate")
        self.dropout_rate = self.hp.get("dropout_rate")
        self.train_mask1, self.test_mask1, self.valid_mask1 = self.graph1.node_labels_sampler(self.split1)
        self.graph1.y = []
        for n, label in self.graph1.nodes.items():
            y_probabilty_vector = list(np.zeros((self.graph1.number_of_classes)))
            y_probabilty_vector[int(int(label) - 1)] = 1.0
            self.graph1.y.append(y_probabilty_vector)
        self.graph1.y = tf.reshape(tf.convert_to_tensor(self.graph1.y, dtype=tf.float32), shape=(self.batch_size_1, self.graph1.number_of_classes))
        self.graph1.X = tf.Variable(Initializers.identity(Shape(in_size=self.batch_size_1, out_size=self.graph1.dimensions, batch_size=self.batch_size_1)), dtype=tf.float32)
        self.graph1.degree_normalized_adjacency = tf.constant(tf.convert_to_tensor(self.graph1.degree_normalized_adjacency, dtype=tf.float32), dtype=tf.float32)
        self.train_mask2, self.test_mask2, self.valid_mask2 = self.graph2.node_labels_sampler(self.split2)
        self.graph2.y = []
        for n, label in self.graph2.nodes.items():
            y_probabilty_vector = list(np.zeros((self.graph2.number_of_classes)))
            y_probabilty_vector[int(int(label) - 1)] = 1.0
            self.graph2.y.append(y_probabilty_vector)
        self.graph2.y = tf.reshape(tf.convert_to_tensor(self.graph2.y, dtype=tf.float32), shape=(self.batch_size_2, self.graph2.number_of_classes))
        self.graph2.X = tf.Variable(Initializers.identity(Shape(in_size=self.batch_size_2, out_size=self.graph2.dimensions, batch_size=self.batch_size_2)), dtype=tf.float32)
        self.graph2.degree_normalized_adjacency = tf.constant(tf.convert_to_tensor(self.graph2.degree_normalized_adjacency, dtype=tf.float32), dtype=tf.float32)

        self.optimizer = Optimizers.optimizer(self.learning_rate)

        self.test_loss = tf.Variable(Initializers.glorot(Shape(in_size=1, out_size=1, batch_size=1)))
        self.test_accuracy = tf.Variable(Initializers.glorot(Shape(in_size=1, out_size=1, batch_size=1)))
        self.train_loss = tf.Variable(Initializers.glorot(Shape(in_size=1, out_size=1, batch_size=1)))
        self.train_accuracy = tf.Variable(Initializers.glorot(Shape(in_size=1, out_size=1, batch_size=1)))

    def compile(self):
        # Input Layer
        self.input_layer_operation_1 = Linear(input=Input(input=self.graph1.features, normalize=True), shape=Shape(in_size=self.graph1.dimensions, out_size=self.input_layer_dimension, batch_size=self.batch_size_1))

        # Layer 1 DiGCN++
        self.layer_1_operation_1 = DirectionalGraphConvolution(input=self.input_layer_operation_1, in_adjacency=self.graph1.degree_normalized_weighted_in_adjacency,
                                                               out_adjacency=self.graph1.degree_normalized_weighted_out_adjacency,
                                                               shape=Shape(in_size=self.input_layer_dimension, out_size=self.layer_1_dimension, batch_size=self.batch_size_1))
        self.layer_1_operation_2 = Aggregate(input=self.layer_1_operation_1, ids=self.graph2.ids, shape=Shape(in_size=self.layer_1_dimension, out_size=self.layer_1_dimension, batch_size=self.batch_size_2))
        self.layer_1_operation_3 = DirectionalGraphConvolution(input=self.layer_1_operation_2, in_adjacency=self.graph2.degree_normalized_weighted_in_adjacency,
                                                               out_adjacency=self.graph2.degree_normalized_weighted_out_adjacency,
                                                               shape=Shape(in_size=self.layer_1_dimension, out_size=self.layer_1_dimension, batch_size=self.batch_size_2))
        self.layer_1_operation_4 = Concatenate(input1=self.layer_1_operation_1, input2=self.layer_1_operation_3,
                                               shape=Shape(in_size=self.layer_1_dimension, out_size=self.layer_1_dimension, batch_size=self.batch_size_1 + self.batch_size_2))
        self.layer_1_operation_5 = Linear(input=self.layer_1_operation_4, shape=Shape(in_size=self.layer_1_dimension, out_size=self.layer_2_dimension, batch_size=self.batch_size_1 + self.batch_size_2))
        self.layer_1_operation_6 = Relu(input=self.layer_1_operation_5, shape=Shape(in_size=self.layer_2_dimension, out_size=self.layer_2_dimension, batch_size=self.batch_size_1 + self.batch_size_2))
        self.layer_1_operation_7 = Residual(input1=self.layer_1_operation_6, input2=self.layer_1_operation_6,
                                            shape=Shape(in_size=self.layer_2_dimension, out_size=self.layer_2_dimension, batch_size=self.batch_size_1 + self.batch_size_2))
        self.layer_1_operation_8 = Regularize(input=self.layer_1_operation_7, rate=self.regularization_rate,
                                              shape=Shape(in_size=self.layer_2_dimension, out_size=self.layer_2_dimension, batch_size=self.batch_size_1 + self.batch_size_2))
        self.layer_1_operation_9 = Dropout(input=self.layer_1_operation_8, shape=Shape(in_size=self.layer_2_dimension, out_size=self.layer_2_dimension, batch_size=self.batch_size_1 + self.batch_size_2),
                                           rate=self.dropout_rate)

        # Pipe Layer
        self.pipe_layer_operation_1 = Split(input=self.layer_1_operation_9, begin1=[0, 0], end1=[self.batch_size_1, self.layer_2_dimension], begin2=[self.batch_size_1, 0],
                                            end2=[self.batch_size_2, self.layer_2_dimension],
                                            shape=Shape(in_size=self.layer_2_dimension, out_size=self.layer_2_dimension, batch_size=self.batch_size_1 + self.batch_size_2))

        # Layer 2 DiGCN++
        self.layer_2_operation_1 = DirectionalGraphConvolution(input=Input(input=self.pipe_layer_operation_1.result_set_1, normalize=False), in_adjacency=self.graph1.degree_normalized_weighted_in_adjacency,
                                                               out_adjacency=self.graph1.degree_normalized_weighted_out_adjacency,
                                                               shape=Shape(in_size=self.layer_2_dimension, out_size=self.layer_2_dimension, batch_size=self.batch_size_1))
        self.layer_2_operation_2 = DirectionalGraphConvolution(input=Input(input=self.pipe_layer_operation_1.result_set_2, normalize=False), in_adjacency=self.graph2.degree_normalized_weighted_in_adjacency,
                                                               out_adjacency=self.graph2.degree_normalized_weighted_out_adjacency,
                                                               shape=Shape(in_size=self.layer_2_dimension, out_size=self.layer_2_dimension, batch_size=self.batch_size_2))
        self.layer_2_operation_3 = Concatenate(input1=self.layer_2_operation_1, input2=self.layer_2_operation_2,
                                               shape=Shape(in_size=self.layer_2_dimension, out_size=self.layer_2_dimension, batch_size=self.batch_size_1 + self.batch_size_2))
        self.layer_2_operation_4 = Linear(input=self.layer_2_operation_3, shape=Shape(in_size=self.layer_2_dimension, out_size=self.layer_2_dimension, batch_size=self.batch_size_1 + self.batch_size_2))
        self.layer_2_operation_5 = Residual(input1=self.layer_2_operation_3, input2=self.layer_2_operation_4,
                                            shape=Shape(in_size=self.layer_2_dimension, out_size=self.layer_2_dimension, batch_size=self.batch_size_1 + self.batch_size_2))
        self.layer_2_operation_6 = Normalize(input=self.layer_2_operation_5, shape=Shape(in_size=self.layer_2_dimension, out_size=self.layer_2_dimension, batch_size=self.batch_size_1 + self.batch_size_2))
        self.layer_2_operation_7 = Dropout(input=self.layer_2_operation_6, shape=Shape(in_size=self.layer_2_dimension, out_size=self.layer_2_dimension, batch_size=self.batch_size_1 + self.batch_size_2),
                                           rate=self.dropout_rate)

        # Output prediction layer
        self.layer_3_operation_1 = Linear(input=self.layer_2_operation_7,
                                          shape=Shape(in_size=self.output_layer_dimension, out_size=self.graph1.number_of_classes + self.graph2.number_of_classes, batch_size=self.batch_size_1 + self.batch_size_2))


        # Embedding extraction layer
        self.layer_4_operation_1 = Split(input=self.layer_3_operation_1, begin1=[0, 0], end1=[self.batch_size_1, self.graph1.number_of_classes + self.graph2.number_of_classes], begin2=[self.batch_size_1, 0],
                                         end2=[self.batch_size_2, self.graph1.number_of_classes + self.graph2.number_of_classes],
                                         shape=Shape(in_size=self.graph1.number_of_classes + self.graph2.number_of_classes, out_size=self.graph1.number_of_classes + self.graph2.number_of_classes, batch_size=self.batch_size_1 + self.batch_size_2))

        self.layer_4_operation_2 = Split(input=Input(self.layer_4_operation_1.result_set_1, normalize=False), begin1=[0, 0], end1=[self.batch_size_1, self.graph1.number_of_classes], begin2=[0, 0], end2=[0, 0],
                                         shape=Shape(in_size=self.graph1.number_of_classes + self.graph2.number_of_classes, out_size=self.graph1.number_of_classes, batch_size=self.batch_size_1))

        self.layer_4_operation_3 = Split(input=Input(self.layer_4_operation_1.result_set_2, normalize=False), begin1=[0, self.graph1.number_of_classes], end1=[self.batch_size_2, self.graph2.number_of_classes],
                                         begin2=[0, 0], end2=[0, 0],
                                         shape=Shape(in_size=self.graph1.number_of_classes + self.graph2.number_of_classes, out_size=self.graph2.number_of_classes, batch_size=self.batch_size_2))

        self.layer_4_operation_4 = Softmax(input=self.layer_4_operation_2.result_set_1, shape=Shape(in_size=self.graph1.number_of_classes, out_size=self.graph1.number_of_classes, batch_size=self.batch_size_1))
        self.layer_4_operation_5 = Softmax(input=self.layer_4_operation_3.result_set_1, shape=Shape(in_size=self.graph2.number_of_classes, out_size=self.graph2.number_of_classes, batch_size=self.batch_size_2))
        pass




    def compute(self):
        self.input_layer_operation_1.compute(self.parameters[0])

        self.layer_1_operation_1.compute(self.parameters[1])
        self.layer_1_operation_2.compute()
        self.layer_1_operation_3.compute(self.parameters[2])
        self.layer_1_operation_4.compute()
        self.layer_1_operation_5.compute(self.parameters[3])
        self.layer_1_operation_6.compute()
        self.layer_1_operation_7.compute(self.parameters[4])
        self.layer_1_operation_8.compute()
        self.layer_1_operation_9.compute()

        self.pipe_layer_operation_1.compute()

        self.layer_2_operation_1.compute(self.parameters[5])
        self.layer_2_operation_2.compute(self.parameters[6])
        self.layer_2_operation_3.compute()
        self.layer_2_operation_4.compute(self.parameters[7])
        self.layer_2_operation_5.compute(self.parameters[8])
        self.layer_2_operation_6.compute()
        self.layer_2_operation_7.compute()

        self.layer_3_operation_1.compute(self.parameters[9])

        self.layer_4_operation_1.compute()
        self.layer_4_operation_2.compute()
        self.layer_4_operation_3.compute()

        self.predictions = tf.convert_to_tensor(self.layer_3_operation_1.output)
        self.regularization_constant = self.layer_1_operation_8.regularization_constant
        self.embedding = self.layer_2_operation_6.embedding

        # self.split_predictions_nodes = self.layer_4_operation_1.result_set_1
        self.split_predictions_classes_node_nodes = self.layer_4_operation_4.output
        self.split_predictions_classes_edge_nodes = self.layer_4_operation_5.output

    def collect(self):
        self.parameters = []
        self.parameters.append(self.input_layer_operation_1.collect())
        self.parameters.append(self.layer_1_operation_1.collect())
        self.parameters.append(self.layer_1_operation_3.collect())
        self.parameters.append(self.layer_1_operation_5.collect())
        self.parameters.append(self.layer_1_operation_7.collect())
        self.parameters.append(self.layer_2_operation_1.collect())
        self.parameters.append(self.layer_2_operation_2.collect())
        self.parameters.append(self.layer_2_operation_4.collect())
        self.parameters.append(self.layer_2_operation_5.collect())
        self.parameters.append(self.layer_3_operation_1.collect())

        # self.parameters.append([tf.Variable(Initializers.glorot(Shape(in_size=1, out_size=1, batch_size=1)), trainable=True, name="Test:W")])
        # self.parameters.append([tf.Variable(Initializers.glorot(Shape(in_size=1, out_size=1, batch_size=1)), trainable=True, name="Test:W")])
        # self.parameters.append([tf.Variable(Initializers.glorot(Shape(in_size=1, out_size=1, batch_size=1)), trainable=True, name="Test:W")])
        # self.parameters.append([tf.Variable(Initializers.glorot(Shape(in_size=1, out_size=1, batch_size=1)), trainable=True, name="Test:W")])
        # self.parameters.append([tf.Variable(Initializers.glorot(Shape(in_size=1, out_size=1, batch_size=1)), trainable=True, name="Test:W")])
        # self.parameters.append([tf.Variable(Initializers.glorot(Shape(in_size=1, out_size=1, batch_size=1)), trainable=True, name="Test:W")])
        # self.parameters.append([tf.Variable(Initializers.glorot(Shape(in_size=1, out_size=1, batch_size=1)), trainable=True, name="Test:W")])
        # self.parameters.append([tf.Variable(Initializers.glorot(Shape(in_size=1, out_size=1, batch_size=1)), trainable=True, name="Test:W")])
        # self.parameters.append([tf.Variable(Initializers.glorot(Shape(in_size=1, out_size=1, batch_size=1)), trainable=True, name="Test:W")])
        # self.parameters.append([tf.Variable(Initializers.glorot(Shape(in_size=1, out_size=1, batch_size=1)), trainable=True, name="Test:W")])

    def evaluate(self, mask1, mask2):

        # self.loss1 = LossFunctions.masked_cross_entropy_loss_evaluater_2(self.split_predictions_classes_node_nodes.result_set_1, self.graph1.y, mask1)
        # self.accuracy1 = Evaluation.masked_accuracy_evaluater(self.split_predictions_classes_node_nodes.result_set_1, self.graph1.y, mask1)
        # self.loss2 = LossFunctions.masked_cross_entropy_loss_evaluater_2(self.split_predictions_classes_edge_nodes.result_set_1, self.graph2.y, mask2)
        # self.accuracy2 = Evaluation.masked_accuracy_evaluater(self.split_predictions_classes_edge_nodes.result_set_1, self.graph2.y, mask2)
        # self.loss = tf.add(tf.add(self.loss1, self.loss2), self.regularization_constant)
        # self.accuracy = tf.reduce_mean(self.accuracy1 + self.accuracy2)

        # loss1 = tf.nn.softmax_cross_entropy_with_logits(logits=self.split_predictions_classes_node_nodes, labels=self.graph1.y)
        # mask1 = tf.cast(mask1, dtype=tf.float32)
        # mask1 /= tf.reduce_mean(mask1)
        # loss1 *= mask1
        # loss1 = tf.reduce_mean(loss1)

        # loss2 = tf.nn.softmax_cross_entropy_with_logits(logits=self.split_predictions_classes_edge_nodes, labels=self.graph2.y)
        # mask2 = tf.cast(mask2, dtype=tf.float32)
        # mask2 /= tf.reduce_mean(mask2)
        # loss2 *= mask2
        # loss2 = tf.reduce_mean(loss2)

        loss1 = LossFunctions.masked_cross_entropy_loss_evaluater_1(self.split_predictions_classes_node_nodes, self.graph1.y, mask1)
        loss2 = LossFunctions.masked_cross_entropy_loss_evaluater_2(self.split_predictions_classes_edge_nodes, self.graph2.y, mask2)
        self.loss = tf.add(tf.add(loss1, loss2), self.regularization_constant)

        accuracy1= Evaluation.masked_accuracy_evaluater(self.split_predictions_classes_node_nodes, self.graph1.y, mask1)
        accuracy2 = Evaluation.masked_accuracy_evaluater(self.split_predictions_classes_edge_nodes, self.graph2.y, mask2)
        self.accuracy = tf.reduce_mean(accuracy1 + accuracy2)


    def update(self, tape):
        gradients = tape.gradient(self.train_loss, self.parameters)
        info = {}
        for i, p in enumerate(self.parameters):
            info[i] = len(p)
        self.parameters = [element for innerList in self.parameters for element in innerList]
        gradients = [element for innerList in gradients for element in innerList]
        combined_params_gradients = list(zip(gradients, self.parameters))
        self.optimizer.apply_gradients(combined_params_gradients)
        updated_parameters = []
        for k, v in info.items():
            popped_elements = [self.parameters.pop(0) for _ in range(v)]
            updated_parameters.append(popped_elements)
        self.parameters = updated_parameters

    # @tf.function
    def train(self):
        # Visualization
        self.losses = []
        self.accuracies = []
        self.epochs = []
        for epoch in tf.range(self.number_of_epochs):
            # Timing
            start_time = time.perf_counter()
            # Train
            with tf.GradientTape() as tape:
                self.collect()
                self.compute()
                self.evaluate(self.train_mask1, self.train_mask2)
                self.train_loss = self.loss
                self.train_accuracy = self.accuracy
            self.update(tape)
            # Test
            self.collect()
            self.compute()
            self.evaluate(self.test_mask1, self.test_mask2)
            self.test_loss = self.loss
            self.test_accuracy = self.accuracy
            # Timing
            end_time = time.perf_counter()
            # Print and Visualize Information
            self.time_per_epoch = tf.constant(round((end_time - start_time), 3), dtype=tf.float32)
            tf.print(" Epoch: " + tf.strings.as_string(epoch) + " Seconds/Epoch: " + tf.strings.as_string(self.time_per_epoch) + " Learning Rate: " + tf.strings.as_string(
                tf.constant(round(self.learning_rate, 3), dtype=tf.float32)) + " Train Loss: " + tf.strings.as_string(self.train_loss) + " Train Accuracy: " + tf.strings.as_string(
                self.train_accuracy) + " Test Loss: " + tf.strings.as_string(self.test_loss) + " Test Accuracy: " + tf.strings.as_string(self.test_accuracy))
            self.losses.append(self.test_loss.numpy())
            self.accuracies.append(self.test_accuracy.numpy())
            self.epochs.append(epoch.numpy())

    def validate(self):
        self.collect()
        self.compute()
        self.evaluate(self.valid_mask1, self.valid_mask2)
        self.valid_loss = self.loss
        self.valid_accuracy = self.accuracy
