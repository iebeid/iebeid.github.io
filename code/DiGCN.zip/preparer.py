from models.gnn.spectral.directgcn.tensorflow.grapher2 import *


def load_data_karate_undirected():
    print("Karate Network Undirected")
    G1 = nx.karate_club_graph()
    raw_edges1 = []
    for e1 in G1.edges():
        raw_edges1.append((str(e1[0]), str(e1[1]), float(1), float(1)))
    graphA = UndirectedGraph(edges=raw_edges1)
    del raw_edges1[:]
    graphA.node_labels(True)
    graphA.node_features(None, 64)
    return graphA

def load_data_karate_directed():
    print("Karate Network Directed")
    G2 = nx.karate_club_graph()
    raw_edges2 = []
    for e2 in G2.edges():
        raw_edges2.append((str(e2[0]), str(e2[1]), float(1), float(1)))
    graphB = DirectedGraph(edges=raw_edges2)
    del raw_edges2[:]
    graphB.node_labels(True)
    graphB.node_features(None, 64)
    return graphB

def load_data_karate_directed_multiplex():
    print("Karate Network Multiplexed")
    G3 = nx.karate_club_graph()
    raw_edges3 = []
    for e3 in G3.edges():
        raw_edges3.append((str(e3[0]), str(e3[1]), float(1), float(random.randint(0, 3))))
    graph1 = DirectedGraph(edges=raw_edges3)
    del raw_edges3[:]
    graph1.node_labels(True)
    graph1.node_features(None, 64)
    medges, mnodes = graph1.second_degree_graph()
    graph2 = DirectedGraph(nodes=mnodes, edges=medges)
    graph2.node_labels(True)
    graph2.node_features(None, 64)
    ids = []
    for n, i in graph2.node_index.items():
        the_two_nodes = n.split("|")
        ids.append([int(graph1.node_index[the_two_nodes[0]]), int(graph1.node_index[the_two_nodes[1]])])
    graph2.ids = ids
    return graph1, graph2

def load_data_cora_undirected():
    print("Cora Network Undirected")
    edges_df = pd.read_csv('data/cora/edges.tsv', sep='\t', header=None, low_memory=False)
    nodes_df = pd.read_csv('data/cora/nodes.tsv', sep='\t', header=None, low_memory=False)
    raw_edges = []
    for index, row in edges_df.iterrows():
        s_n = str(row.iloc[0])
        t_n = str(row.iloc[1])
        raw_edges.append((s_n, t_n, float(1), float(random.randint(0, 3))))
    node_labels = []
    for index, row in nodes_df.iterrows():
        l = str(row.iloc[-1])
        node_labels.append(l)
    node_labels = np.unique(node_labels).tolist()
    raw_nodes = {}
    feature_vectors = []
    for index, row in nodes_df.iterrows():
        n = str(row.iloc[0])
        l = str(row.iloc[-1])
        feature_vector = []
        for i in range(1, (len(row) - 1)):
            feature_vector.append(float(row.iloc[i]))
        feature_vectors.append(feature_vector)
        raw_nodes[n] = node_labels.index(l)
    graph = UndirectedGraph(nodes=raw_nodes, edges=raw_edges)
    print("Loaded number of nodes: ", graph.number_of_nodes)
    print("Loaded number of edges: ", graph.number_of_edges)
    graph.node_labels(False)
    graph.node_features(feature_vectors, None)
    return graph


def load_data_cora_directed():
    print("Cora Network Directed")
    edges_df = pd.read_csv('data/cora/edges.tsv', sep='\t', header=None, low_memory=False)
    nodes_df = pd.read_csv('data/cora/nodes.tsv', sep='\t', header=None, low_memory=False)
    raw_edges = []
    for index, row in edges_df.iterrows():
        s_n = str(row.iloc[0])
        t_n = str(row.iloc[1])
        raw_edges.append((s_n, t_n, float(1), float(random.randint(0, 3))))
    node_labels = []
    for index, row in nodes_df.iterrows():
        l = str(row.iloc[-1])
        node_labels.append(l)
    node_labels = np.unique(node_labels).tolist()
    raw_nodes = {}
    feature_vectors = []
    for index, row in nodes_df.iterrows():
        n = str(row.iloc[0])
        l = str(row.iloc[-1])
        feature_vector = []
        for i in range(1, (len(row) - 1)):
            feature_vector.append(float(row.iloc[i]))
        feature_vectors.append(feature_vector)
        raw_nodes[n] = node_labels.index(l)
    graph = DirectedGraph(nodes=raw_nodes, edges=raw_edges)
    print("Loaded number of nodes: ", graph.number_of_nodes)
    print("Loaded number of edges: ", graph.number_of_edges)
    graph.node_labels(False)
    graph.node_features(feature_vectors, None)
    return graph


def load_data_citeseer_undirected():
    print("Citeseer Network Undirected")
    edges_df = pd.read_csv('data/citeseer/edges.tsv', sep='\t', header=None, low_memory=False)
    nodes_df = pd.read_csv('data/citeseer/nodes.tsv', sep='\t', header=None, low_memory=False)
    raw_edges = []
    all_nodes = []
    for index, row in edges_df.iterrows():
        s_n = str(row.iloc[0])
        t_n = str(row.iloc[1])
        raw_edges.append((s_n, t_n, float(1)))
        all_nodes.append(s_n)
        all_nodes.append(t_n)
    all_nodes = np.unique(all_nodes).tolist()
    node_labels = []
    for index, row in nodes_df.iterrows():
        l = str(row.iloc[-1])
        node_labels.append(l)
    node_labels = np.unique(node_labels).tolist()
    raw_nodes = {}
    feature_vectors = []
    different_nodes = list(set(all_nodes) - set(nodes_df[0].tolist()))
    # different_nodes = np.subtract(np.array(all_nodes), np.array(nodes_df[0].tolist())).tolist()
    dim = len(nodes_df) - 2
    for index, row in nodes_df.iterrows():
        n = str(row.iloc[0])
        l = str(row.iloc[-1])
        feature_vector = []
        for i in range(1, (len(row) - 1)):
            feature_vector.append(float(row.iloc[i]))
        feature_vectors.append(feature_vector)
        raw_nodes[n] = node_labels.index(l)
    for n in different_nodes:
        raw_nodes[n] = "N/A"
        feature_vector = np.zeros(dim).tolist()
        feature_vectors.append(feature_vector)
    graph = UndirectedGraph(nodes=raw_nodes, edges=raw_edges)
    print("Loaded number of nodes: ", graph.number_of_nodes)
    print("Loaded number of edges: ", graph.number_of_edges)
    graph.node_labels(False)
    graph.node_features(feature_vectors, None)
    return graph


def load_data_citeseer_directed():
    print("Citeseer Network Directed")
    edges_df = pd.read_csv('data/citeseer/edges.tsv', sep='\t', header=None, low_memory=False)
    nodes_df = pd.read_csv('data/citeseer/nodes.tsv', sep='\t', header=None, low_memory=False)
    raw_edges = []
    all_nodes = []
    for index, row in edges_df.iterrows():
        s_n = str(row.iloc[0])
        t_n = str(row.iloc[1])
        raw_edges.append((s_n, t_n, float(1)))
        all_nodes.append(s_n)
        all_nodes.append(t_n)
    all_nodes = np.unique(all_nodes).tolist()
    node_labels = []
    for index, row in nodes_df.iterrows():
        l = str(row.iloc[-1])
        node_labels.append(l)
    node_labels = np.unique(node_labels).tolist()
    raw_nodes = {}
    feature_vectors = []
    different_nodes = list(set(all_nodes) - set(nodes_df[0].tolist()))
    # different_nodes = np.subtract(np.array(all_nodes), np.array(nodes_df[0].tolist())).tolist()
    dim = len(nodes_df) - 2
    for index, row in nodes_df.iterrows():
        n = str(row.iloc[0])
        l = str(row.iloc[-1])
        feature_vector = []
        for i in range(1, (len(row) - 1)):
            feature_vector.append(float(row.iloc[i]))
        feature_vectors.append(feature_vector)
        raw_nodes[n] = node_labels.index(l)
    for n in different_nodes:
        raw_nodes[n] = "N/A"
        feature_vector = np.zeros(dim).tolist()
        feature_vectors.append(feature_vector)
    graph = DirectedGraph(nodes=raw_nodes, edges=raw_edges)
    print("Loaded number of nodes: ", graph.number_of_nodes)
    print("Loaded number of edges: ", graph.number_of_edges)
    graph.node_labels(False)
    graph.node_features(feature_vectors, None)
    return graph


def load_data_kipf(dataset_str):
    """
    Loads input data from gcn/data directory

    ind.dataset_str.x => the feature vectors of the training instances as scipy.sparse.csr.csr_matrix object;
    ind.dataset_str.tx => the feature vectors of the test instances as scipy.sparse.csr.csr_matrix object;
    ind.dataset_str.allx => the feature vectors of both labeled and unlabeled training instances
        (a superset of ind.dataset_str.x) as scipy.sparse.csr.csr_matrix object;
    ind.dataset_str.y => the one-hot labels of the labeled training instances as numpy.ndarray object;
    ind.dataset_str.ty => the one-hot labels of the test instances as numpy.ndarray object;
    ind.dataset_str.ally => the labels for instances in ind.dataset_str.allx as numpy.ndarray object;
    ind.dataset_str.graph => a dict in the format {index: [index_of_neighbor_nodes]} as collections.defaultdict
        object;
    ind.dataset_str.test.index => the indices of test instances in graph, for the inductive setting as list object.

    All objects above must be saved using python pickle module.

    :param dataset_str: Dataset name
    :return: All data input files loaded (as well the training/test data).
    """
    names = ['x', 'y', 'tx', 'ty', 'allx', 'ally', 'graph']
    objects = []
    for i in range(len(names)):
        with open("data/ind.{}.{}".format(dataset_str, names[i]), 'rb') as f:
            if sys.version_info > (3, 0):
                objects.append(pickle.load(f, encoding='latin1'))
            else:
                objects.append(pickle.load(f))

    x, y, tx, ty, allx, ally, graph = tuple(objects)
    test_idx_reorder = Utils.parse_index_file("data/ind.{}.test.index".format(dataset_str))
    test_idx_range = np.sort(test_idx_reorder)

    if dataset_str == 'citeseer':
        # Fix citeseer dataset (there are some isolated nodes in the graph)
        # Find isolated nodes, add them as zero-vecs into the right position
        test_idx_range_full = range(min(test_idx_reorder), max(test_idx_reorder)+1)
        tx_extended = sp.sparse.lil_matrix((len(test_idx_range_full), x.shape[1]))
        tx_extended[test_idx_range-min(test_idx_range), :] = tx
        tx = tx_extended
        ty_extended = np.zeros((len(test_idx_range_full), y.shape[1]))
        ty_extended[test_idx_range-min(test_idx_range), :] = ty
        ty = ty_extended

    # features = sp.vstack((allx, tx)).tolil()
    features = sp.sparse.lil_matrix(np.vstack((allx.todense(), tx.todense())))
    features[test_idx_reorder, :] = features[test_idx_range, :]
    adj = nx.adjacency_matrix(nx.from_dict_of_lists(graph))

    labels = np.vstack((ally, ty))
    labels[test_idx_reorder, :] = labels[test_idx_range, :]

    idx_test = test_idx_range.tolist()
    idx_train = range(len(y))
    idx_val = range(len(y), len(y)+500)

    train_mask = Utils.sample_mask(idx_train, labels.shape[0])
    val_mask = Utils.sample_mask(idx_val, labels.shape[0])
    test_mask = Utils.sample_mask(idx_test, labels.shape[0])

    y_train = np.zeros(labels.shape)
    y_val = np.zeros(labels.shape)
    y_test = np.zeros(labels.shape)
    y_train[train_mask, :] = labels[train_mask, :]
    y_val[val_mask, :] = labels[val_mask, :]
    y_test[test_mask, :] = labels[test_mask, :]




    graph = UndirectedGraph(adjacency=adj, features=features, feature_dimension=64)
    print("Loaded number of nodes: ", graph.number_of_nodes)
    print("Loaded number of edges: ", graph.number_of_edges)
    graph.create_node_labels(True)



    return graph, y_train, y_val, y_test, train_mask, val_mask, test_mask