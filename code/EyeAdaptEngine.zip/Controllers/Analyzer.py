import socket
import struct
# import matplotlib.pyplot as plt
# import matplotlib.image as mpimg
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from Core.Classifier import Classifier
from Core.Velocity import VelocityKernel
from Models.Screen import Screen
from Models.Sample import Sample
from Models.AOI import Grid
from PIL import ImageGrab
from PIL import Image
from Core.Filter import MovingAverageFilter
from Core.Backend import Backend
import copy
import json
import sys
import subprocess
from Operations import FaceDetect
from GUI.Gauge import Gauge
import random

#Author: Islam Akef Ebeid
#This file contains runs once the analysis runs
#The script listens to the server and parses incoming samples
#Note that the strange notation that contains "Q" is related to the

class AnalyzerSignals(QObject):
    result = pyqtSignal('QString')

class Analyzer(QRunnable):

    def __init__(self, screen = Screen(), portNumber=0, serverName=0, bufferSize=0, dataPath=0,
                           minimumFixationDuration=0, maximumTimeBetweenFixations=0, windowLength=0, gridSize = 0,
                           fixationVelocityThreshold=30.0, fixationDegreesThreshold=1.5, fixationTimeThreshold=75.0):
        super(Analyzer, self).__init__()

        self.screen = screen
        self.portNumber = portNumber
        self.serverName = serverName
        self.bufferSize = bufferSize
        self.dataPath = dataPath
        self.minimumFixationDuration = minimumFixationDuration
        self.maximumTimeBetweenFixations = maximumTimeBetweenFixations
        self.windowLength = windowLength
        self.gridSize = gridSize
        self.fixationVelocityThreshold = fixationVelocityThreshold
        self.fixationDegreesThreshold = fixationDegreesThreshold
        self.fixationTimeThreshold = fixationTimeThreshold

        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.serverAddress = (self.serverName, int(self.portNumber))
        self.sock.connect(self.serverAddress)
        # self.forwardSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        self.messageSizes = [6,8,10,11,18,150]
        self.trialNumber = 0
        self.signals = AnalyzerSignals()
        # self.faceDetectionWidget = FaceDetect.Detect(0)

        self.reset()

        # print("Connecting to %s port %s" % self.serverAddress)
        # print("Port number: " + str(self.portNumber))
        # print("Server name: " + str(self.serverName))
        # print("Buffer size: " + str(self.bufferSize))
        # print("Data path: " + str(self.dataPath))
        # print("Minimum fixation duration: " + str(self.minimumFixationDuration))
        # print("Maximum time between fixations: " + str(self.maximumTimeBetweenFixations))
        # print("Window length: " + str(self.windowLength))

    def reset(self):
        self.imageName = ''
        self.timestamp = 0
        self.gazeLeftX = 0.0
        self.gazeLeftY = 0.0
        self.gazeRightX = 0.0
        self.gazeRightY = 0.0
        self.leftPupilDiameter = 0.0
        self.rightPupilDiameter = 0.0
        self.leftEyeDistance = self.screen.defaultDistanceToScreen
        self.rightEyeDistance = self.screen.defaultDistanceToScreen
        self.leftEyePositionX = 0.0
        self.leftEyePositionY = 0.0
        self.rightEyePositionX = 0.0
        self.rightEyePositionY = 0.0
        self.gazePointX = 0.0
        self.gazePointY = 0.0
        self.filteredGazePointX = 0.0
        self.filteredGazePointY = 0.0
        self.eyeToScreenDistance = 0.0
        self.gazeAOI = 0
        self.interSampleTimestampDifference = 0.0
        self.timePassed = 0.0
        self.interSampleDistance = 0.0
        self.interSampleVelocity = 0.0
        self.interSampleAcceleration = 0.0
        self.gazeEventType = ''
        self.interslide = ''
        self.counter = 0
        self.start = False
        self.grid = None
        self.maFilterX = None
        self.maFilterY = None

    #https://stackoverflow.com/questions/17667903/python-socket-receive-large-amount-of-data?utm_medium=organic&utm_source=google_rich_qa&utm_campaign=google_rich_qa
    def recv_msg(self):
        # Read message length and unpack it into an integer
        raw_msglen = self.recvall(4)
        if not raw_msglen:
            return None
        msglen = struct.unpack('>I', raw_msglen)[0]
        # Read the message data
        return self.recvall(msglen)

    def recvall(self, n):
        # Helper function to recv n bytes or return None if EOF is hit
        data = b''
        while len(data) < n:
            packet = self.sock.recv(n - len(data))
            if not packet:
                return None
            data += packet
        return data

    @pyqtSlot('QString')
    def run(self):
        # labels = ['Low Attention', '', 'Optimum Attention', '', 'Chaotic Attention']
        # colors = ['red', 'orange', 'green', 'orange', 'red']
        # title = 'Entropy'
        # self.gauge = Gauge(labels, colors, title, 0.5, 1)
        while True:
            self.line = self.recv_msg().decode("utf-8")
            self.parsedMessage = self.line.split(";")
            if int(len(self.parsedMessage)) in self.messageSizes:
                # print(str(self.parsedMessage))
                self.eventSource = self.parsedMessage[1].strip().rstrip()
                self.sampleName = self.parsedMessage[2].strip().rstrip()

                if (str(self.eventSource) == str("EyeTracker")) and (str(self.sampleName) == str("GazeCalibrationResult")):
                    self.calibrationPoints = self.parsedMessage[5].strip().rstrip()
                    self.calibrationQuality = self.parsedMessage[6].strip().rstrip()
                    self.calibrationResult = self.parsedMessage[7].strip().rstrip()
                    self.errorMean = self.parsedMessage[8].strip().rstrip()
                    self.errorStandardDeviation = self.parsedMessage[9].strip().rstrip()
                    # print("Number of calibration points: " + str(self.calibrationPoints))
                    # print("Calibration quality: " + str(self.calibrationQuality))
                    # print("Calibration result: " + str(self.calibrationResult))
                    # print("Mean of error: " + str(self.errorMean))
                    # print("Standard deviation of error: " + str(self.errorStandardDeviation))
                    continue

                if (str(self.eventSource) == str("AttentionTool")) and (str(self.sampleName) == str("SlideStart")):
                    self.imagePath = str(self.dataPath) + str(self.parsedMessage[6].strip().rstrip()) + str(".jpg")
                    self.imageName = str(self.parsedMessage[6].strip().rstrip()) + str(".jpg")
                    self.interslide = self.parsedMessage[7].strip().rstrip()
                    if (str(self.interslide) == str("TestImage")):
                        self.maFilterX = MovingAverageFilter(5)
                        self.maFilterY = MovingAverageFilter(5)
                        self.classifier = Classifier(self.screen, self.fixationVelocityThreshold, self.fixationDegreesThreshold, self.fixationTimeThreshold)
                        self.velocityKernel = VelocityKernel(self.screen.ipp,3)
                        if "Question" not in str(self.imageName):
                            self.im = Image.open(self.imagePath)
                        else:
                            self.im = ImageGrab.grab()
                        self.imWidth, self.imHeight = self.im.size
                        self.grid = Grid(self.screen.screenResolutionHeight, self.screen.screenResolutionWidth, self.imHeight, self.imWidth, self.gridSize)
                        self.backend = Backend(self.grid,75,0.5,self.screen,1.0,100)
                        self.start = True
                        self.trialNumber = self.trialNumber + 1
                        continue

                if (str(self.eventSource) == str("AttentionTool")) and (str(self.sampleName) == str("SlideEnd")):
                    if (str(self.interslide) == str("TestImage")):
                        self.reset()
                        self.backend.endBackendOperations = True
                        break

                if (self.start is True) and (str(self.eventSource) == str("EyeTracker")) and (str(self.sampleName) == str("EyeData")):
                    self.counter = self.counter + 1
                    self.timestamp = self.parsedMessage[5].strip().rstrip()
                    self.gazeLeftX = float(self.parsedMessage[6].strip().rstrip())
                    self.gazeLeftY = float(self.parsedMessage[7].strip().rstrip())
                    self.gazeRightX = float(self.parsedMessage[8].strip().rstrip())
                    self.gazeRightY = float(self.parsedMessage[9].strip().rstrip())
                    self.leftPupilDiameter = float(self.parsedMessage[10].strip().rstrip())
                    self.rightPupilDiameter = float(self.parsedMessage[11].strip().rstrip())
                    self.leftEyeDistance = float(self.parsedMessage[12].strip().rstrip())/10
                    self.rightEyeDistance = float(self.parsedMessage[13].strip().rstrip())/10
                    #TODO: Compute sample to sample data from normalized screen coordinates
                    # self.leftEyePositionX = float(self.parsedMessage[14])
                    # self.leftEyePositionY = float(self.parsedMessage[15])
                    # self.rightEyePositionX = float(self.parsedMessage[16])
                    # self.rightEyePositionY = float(self.parsedMessage[17])
                    self.leftEyePositionX = 0.0
                    self.leftEyePositionY = 0.0
                    self.rightEyePositionX = 0.0
                    self.rightEyePositionY = 0.0

                    sample = Sample(self.counter,self.trialNumber,self.imageName,self.timestamp,self.gazeLeftX,
                                    self.gazeLeftY,self.gazeRightX,self.gazeRightY,self.leftPupilDiameter,self.rightPupilDiameter,
                                    self.leftEyeDistance,self.rightEyeDistance,self.leftEyePositionX,self.leftEyePositionY,
                                    self.rightEyePositionX,self.rightEyePositionY)
                    sample.compute_gaze(self.screen.screenResolutionHeight, self.screen.screenResolutionWidth, self.imHeight, self.imWidth)
                    sample.find_eye_to_screen_distance()
                    sample.filteredGazePointX = self.maFilterX.run(sample.gazePointX)
                    sample.filteredGazePointY = self.maFilterY.run(sample.gazePointY)
                    sample.gazeAOI = self.grid.check_sample_in_grid(sample.filteredGazePointX,sample.filteredGazePointY)
                    sample = self.classifier.compute_velocity(sample)
                    self.timePassed = self.timePassed + sample.interSampleTimestampDifference
                    sample.timePassed = self.timePassed
                    sample.filteredInterSampleVelocity = self.velocityKernel.run(sample)
                    sample.gazeEventType = self.classifier.classify(sample)
                    self.backend.find_fixations_cumulative(sample)
                    # self.backend.visualize()
                    self.backend.process_fixations_window()




                    # print(str(sample))
                    # print(self.backend.transitionMatrix)
                    # print(self.backend.transitionMatrix.states)
                    # print("Number of Transitions: " + str(len(self.backend.transitionMatrix.transitions)))
                    # self.gauge.draw(random.randint(1, 5))



                    # sample.__dict__.update(self.backend.latestFixation.create_dictionary())
                    # sample.__dict__.update(self.backend.transitionMatrix.create_dictionary())
                    # s = json.dumps(sample.__dict__)

                    # self.sock.sendto(s.encode("utf-8"), ("localhost", 11300))
                    # self.signals.result.emit(s)

                    # sample.__dict__.update(self.backend.latestFixation.create_dictionary())
                    # sample.__dict__.update(self.backend.transitionMatrix.create_dictionary())
                    # s = json.dumps(sample.__dict__)
                    # print(s)
                    # sock.sendto(s.encode("utf-8"), ("localhost", 11300))

                # if (str(self.eventSource).strip() == "AFFDEX") and (str(self.sampleName).strip() == "AffRaw"):
                #     afftimestamp = self.parsedMessage[3]
                #     affnumberOfFacesDetected = self.parsedMessage[6]
                #     affframeIndex = self.parsedMessage[9]
                #     afffaceId = self.parsedMessage[10]
                #     affnumberOfClassifiers = self.parsedMessage[11]
                #     anger = self.parsedMessage[33]
                #     sadness = self.parsedMessage[34]
                #     disgust = self.parsedMessage[35]
                #     joy = self.parsedMessage[36]
                #     surprise = self.parsedMessage[37]
                #     fear = self.parsedMessage[38]
                #     contempt = self.parsedMessage[39]
                #     facsValueSigma = float(anger) + float(sadness) + float(disgust) + float(joy) + float(
                #         surprise) + float(fear) + float(contempt)
                #     print("Total Emotional Valence: " + str(facsValueSigma))
                #     numberOfLandmarksDetected = self.parsedMessage[46]
                    continue