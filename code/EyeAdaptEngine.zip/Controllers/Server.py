import socket
import struct
import time
from ctypes import *
from PyQt5.QtCore import QRunnable

#Author: Islam Akef Ebeid
#This scripts has three functionalities the first is a server class which reads the original file and streams to simulate iMotions streaming
#The second class acts as a proxy for iMotions streaming server
#The third class is a mouse emulator to test realtime functionality
#Each class implements QRunnable and runs a seperate thread to listen

class Server(QRunnable):

    def __init__(self, portNumber, serverName, delay, bufferSize, fileName, dataPath):
        super(Server, self).__init__()
        self.portNumber = portNumber
        self.serverName = serverName
        self.delay = delay
        self.bufferSize = bufferSize
        self.fileName = fileName
        self.dataPath = dataPath

        # Create a TCP/IP socket
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # Bind the socket to the port
        self.serverAddress = (self.serverName, int(self.portNumber))
        print("Starting up on %s port %s" % self.serverAddress)
        self.sock.bind(self.serverAddress)
        # Listen for incoming connections
        self.sock.listen(1)
        self.filePath = str(self.dataPath)+str(self.fileName)
        self.file = open(str(self.filePath), 'r')
        self.connection = 0
        print("Port number: " + str(self.portNumber))
        print("Server name: " + str(self.serverName))
        print("Delay: " + str(self.delay))
        print("Buffer size: " + str(self.bufferSize))
        print("File name: " + str(self.fileName))
        print("Data path: " + str(self.dataPath))

    def send_msg(self,msg):
        # Prefix each message with a 4-byte length (network byte order)
        msg = struct.pack('>I', len(msg)) + msg
        self.connection.sendall(msg)

    def run(self):
        while True:
            try:
                while True:
                    try:
                        print("Waiting for a connection")
                        self.connection, self.clientAddress = self.sock.accept()
                        print("Connection from", self.clientAddress)
                    except socket.error as err:
                        print("Caught exception socket.error : %s" % err)

                    for line in self.file:
                        self.send_msg(line.encode("utf-8"))
                        time.sleep(float(self.delay))
            finally:
                print("Closing connection")
                self.sock.close()
                self.connection.close()
                self.file.close()

class Proxy(QRunnable):

    def __init__(self, parent, proxyPortNumber,proxyServerName,iMotionsPortNumber,iMotionsServerName,proxyDataPath,proxyBufferSize):
        super(Proxy, self).__init__(parent)
        self.proxyPortNumber = proxyPortNumber
        self.proxyServerName = proxyServerName
        self.iMotionsPortNumber = iMotionsPortNumber
        self.iMotionsServerName = iMotionsServerName
        self.proxyDataPath = proxyDataPath
        self.proxyBufferSize = proxyBufferSize

    def run(self):
        #connect to iMotions
        iMotionsSock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        iMotionsServerAddress = (self.iMotionsServerName, int(self.iMotionsPortNumber))
        print("Connecting to %s port %s" % iMotionsServerAddress)
        iMotionsSock.connect(iMotionsServerAddress)
        #proxy server
        proxySock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        proxyServerAddress = (self.proxyServerName, int(self.proxyPortNumber))
        print("Starting up on %s port %s" % proxyServerAddress)
        proxySock.bind(proxyServerAddress)
        proxySock.listen(1)
        proxyConnection = 0
        print("Proxy port number: " + str(self.proxyPortNumber))
        print("Proxy server name: " + str(self.proxyServerName))
        print("iMotions port number: " + str(self.iMotionsPortNumber))
        print("iMotions server name: " + str(self.iMotionsServerName))
        print("Proxy data path: " + str(self.proxyDataPath))
        print("Proxy buffer size: " + str(self.proxyBufferSize))
        while True:
            try:
                print("Waiting for a connection")
                proxyConnection, clientAddress = proxySock.accept()
                print("Connection from", clientAddress)
                while True:
                    iMotionsData = iMotionsSock.recv(int(self.proxyBufferSize))
                    proxyConnection.sendall(iMotionsData)
            finally:
                print("Closing connection")
                iMotionsSock.close()
                proxyConnection.close()


class Mouse(QRunnable):

    def __init__(self, parent):
        super(Mouse, self).__init__(parent)

    def run(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        port_number = 11100
        server_address = ("localhost", port_number)
        print("Starting up on %s port %s" % server_address)
        sock.bind(server_address)
        sock.listen(1)
        connection = 0
        while True:
            try:
                print("Waiting for a connection")
                connection, client_address = sock.accept()
                print("Connection from", client_address)
                while True:
                    pt = {"x": 0, "y": 0}
                    windll.user32.GetCursorPos(byref(pt))
                    mousePosition = str(pt).encode('utf-8')
                    connection.sendall(mousePosition)
                    time.sleep(0.00333333333)

            finally:
                print("Closing connection")
                connection.close()
                sock.close()