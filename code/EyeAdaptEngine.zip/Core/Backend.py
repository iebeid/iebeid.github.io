#Author: Islam Akef Ebeid
#This class is a backend thread which processes samples into fixations and fixations into AOI sequences and AOI sequences into transition matrices
#The realtime processing is implemented according to Olsen 2012

import copy
import time
import numpy as np
from threading import Thread
from Models.Sample import Sample
from Models.Fixation import Fixation
from Models.TransitionMatrix import Transition
from Models.TransitionMatrix import TransitionMatrix
from Core import Utils as u
from GUI.Gauge import Gauge

class Backend:
    def __init__(self,grid,maximumTimeBetweenFixations,maxAngleBetweenFixations,screen,processingWindow,shortFixaitonThreshold):
        #AOI grid size
        self.grid = grid
        #Number of states (AOI grids)
        self.numberOfStates = self.grid.grid_size ** 2
        #Maximum time between fixations or the fixation is not classified
        self.maximumTimeBetweenFixations = maximumTimeBetweenFixations
        #Maximum angle between fixations
        self.maxAngleBetweenFixations = maxAngleBetweenFixations
        #Screen object
        self.screen = screen
        #processing window for realtime classification
        self.processingWindow = processingWindow
        #Number of samples considered in
        self.numberOfSamplesInAProcessingWindow = u.compute_window_size(self.processingWindow*1000)
        #The duration of the fixation where it is considered short and discarded
        self.shortFixaitonThreshold = shortFixaitonThreshold

        self.sample = Sample()
        self.currentSample = Sample()
        self.previousSample = Sample()
        self.currentFixation = Fixation()
        self.previousFixation = Fixation()
        self.fixationCounter = 0
        self.transitionMatrix = TransitionMatrix(0,[])
        self.windowTransitionMatrix = TransitionMatrix(0, [])
        self.latestFixation = Fixation()
        self.fixation = []
        self.fixations = []
        self.states = []
        self.windowStates = []
        self.transitions = []
        self.startOfFixation = False
        self.endBackendOperations = False

        self.t1 = Thread(target=self.process_fixations_cumulative)
        self.t1.daemon = True
        self.t1.start()
        self.t2 = Thread(target=self.process_fixations_window)
        self.t2.daemon = True
        self.t2.start()
        # self.t3 = Thread(target=self.visualize)
        # self.t3.daemon = True
        # self.t3.start()

    #This function converts samples which were classified as a fixation to a fixation object
    def samples_to_fixation(self,fixationSamples):
        sizeOfFixation = len(fixationSamples)
        fixationDuration = int(fixationSamples[sizeOfFixation - 1].timestamp) - int(fixationSamples[0].timestamp)
        fixationSpatialDataX = []
        fixationSpatialDataY = []
        averageEyeScreenDistance = 0
        for sample in fixationSamples:
            fixationSpatialDataX.append(float(sample.filteredGazePointX))
            fixationSpatialDataY.append(float(sample.filteredGazePointY))
            averageEyeScreenDistance = averageEyeScreenDistance + sample.eyeToScreenDistance
        averageEyeScreenDistance = averageEyeScreenDistance / sizeOfFixation
        xMean = np.mean(fixationSpatialDataX)
        yMean = np.mean(fixationSpatialDataY)
        fixationAOI = self.grid.check_sample_in_grid(xMean,yMean)
        fixationObject = Fixation(0, xMean, yMean,
                                  fixationSamples[0].timestamp,
                                  fixationSamples[sizeOfFixation - 1].timestamp, fixationDuration, fixationAOI,
                                  fixationSpatialDataX, fixationSpatialDataY, fixationSamples[0],
                                  fixationSamples[sizeOfFixation - 1], averageEyeScreenDistance)
        return fixationObject

    #TODO: Include in the calucaltions the x and y values of the samples in between the two fixations
    #This function merges close fixations into one fixation according to Olsen, (2012)
    def merge_fixations(self):
        mergedFixationDuration = self.previousFixation.fixationDuration + self.currentFixation.fixationDuration
        mergedFixationSpatialDataX = np.concatenate([self.previousFixation.xPos,self.currentFixation.xPos])
        mergedFixationSpatialDataY = np.concatenate([self.previousFixation.yPos, self.currentFixation.yPos])
        xMean = np.mean(mergedFixationSpatialDataX)
        yMean = np.mean(mergedFixationSpatialDataY)
        mergedFixationAOI = self.grid.check_sample_in_grid(xMean, yMean)
        mergedFixationObject = Fixation(self.previousFixation.sequence-1, xMean, yMean,
                                        self.previousFixation.fixationStart, self.currentFixation.fixationEnd,
                                        mergedFixationDuration, mergedFixationAOI,
                                        mergedFixationSpatialDataX, mergedFixationSpatialDataY, self.previousFixation.firstSample,
                                        self.currentFixation.lastSample,
                                        float((self.previousFixation.averageEyeDistance+self.currentFixation.averageEyeDistance)/2))
        return mergedFixationObject

    #This function knocks out short fixations
    def filter_fixation(self,fixation):
        if fixation.sequence == 1:
            self.currentFixation = copy.deepcopy(fixation)
            self.previousFixation = copy.deepcopy(self.currentFixation)
        else:
            self.currentFixation = copy.deepcopy(fixation)
            timeBetweenFixations = int(self.currentFixation.fixationStart) - int(self.previousFixation.fixationEnd)
            if timeBetweenFixations < self.maximumTimeBetweenFixations:
                dx = float(self.currentFixation.firstSample.filteredGazePointX) - float(
                    self.previousFixation.lastSample.filteredGazePointX)
                dy = float(self.currentFixation.firstSample.filteredGazePointY) - float(
                    self.previousFixation.lastSample.filteredGazePointY)
                distanceInPixels = ((dx ** 2) + (dy ** 2)) ** 0.5
                distanceInCM = distanceInPixels * self.screen.ipp
                angleBetweenFixations = u.convert_distance_to_angle(distanceInCM, fixation.averageEyeDistance)
                if angleBetweenFixations < self.maxAngleBetweenFixations:
                    fixation = self.merge_fixations()
                else:
                    fixation = copy.deepcopy(self.currentFixation)
            else:
                fixation = copy.deepcopy(self.currentFixation)
            self.previousFixation = copy.deepcopy(self.currentFixation)
        if fixation.fixationDuration > self.shortFixaitonThreshold:
            return fixation
        else:
            return None

    #Visualization function for the "Realtime transition entropy" ETRA video
    def visualize(self):
        labels = ['Low Attention', '', 'Optimum Attention', '', 'Chaotic Attention']
        colors = ['red', 'orange', 'green', 'orange', 'red']
        title = 'Entropy'
        self.gauge = Gauge(labels, colors, title, 0.001, 8)
        while True:
            # delta_entropy = float(abs(float(self.windowTransitionMatrix.stationaryDistributionEntropy) - float(self.windowTransitionMatrix.transitionMatrixEntropy)))
            delta_entropy = float(abs(float(self.windowTransitionMatrix.transitionMatrixEntropy)))
            self.gauge.draw(delta_entropy, 3, 12, 1000)
            if self.endBackendOperations is True:
                break

    #Realtime processing
    def process_fixations_window(self):
        # file = open('C:/Users/islam/Desktop/output.txt', 'w')
        while True:
            time.sleep(3.0)
            AOIS = []
            if len(self.windowStates) != 0:
                i = 0
                for s in self.windowStates:
                    AOIS.append(s)
                    self.windowStates.pop(i)
                    i = i + 1
                self.windowTransitionMatrix = TransitionMatrix(self.numberOfStates, AOIS)
            else:
                self.windowTransitionMatrix = TransitionMatrix(0, AOIS)
            # print("Transition Entropy: " + str(self.windowTransitionMatrix.transitionMatrixEntropy))

            print(str(self.windowTransitionMatrix.stationaryDistributionEntropy) + "," + str(self.windowTransitionMatrix.transitionMatrixEntropy))
            print("Number of states: " + str(len(AOIS)))
            print(str(AOIS))
            #
            # file.write("Transition Entropy: " + str(self.windowTransitionMatrix.transitionMatrixEntropy))
            # file.write("Stationary Entropy: " + str(self.windowTransitionMatrix.stationaryDistributionEntropy))
            # file.write("Number of states: " + str(len(AOIS)))
            # file.write(str(AOIS))
            # file.write("\n")

            # gaugeValue = 1
            # if (self.windowTransitionMatrix.transitionMatrixEntropy <= 0.3):
            #     gaugeValue = 1
            # if (self.windowTransitionMatrix.transitionMatrixEntropy > 0.3) \
            #         and (self.windowTransitionMatrix.transitionMatrixEntropy <= 0.5):
            #     gaugeValue = 2
            # if (self.windowTransitionMatrix.transitionMatrixEntropy > 0.5) \
            #         and (self.windowTransitionMatrix.transitionMatrixEntropy <= 0.6):
            #     gaugeValue = 3
            # if (self.windowTransitionMatrix.transitionMatrixEntropy > 0.6) \
            #         and (self.windowTransitionMatrix.transitionMatrixEntropy <= 0.7):
            #     gaugeValue = 4
            # if (self.windowTransitionMatrix.transitionMatrixEntropy > 0.7):
            #     gaugeValue = 5
            # if len(AOIS) <= 3:
            #     gaugeValue = 1

            # delta_entropy = float(abs(float(self.windowTransitionMatrix.stationaryDistributionEntropy) - float(self.windowTransitionMatrix.transitionMatrixEntropy)))

            # self.gauge.draw(delta_entropy, 3, 12, 1000)
            if self.endBackendOperations is True:
                break
    #This function finds fixations up until this point rather than a processing window
    def process_fixations_cumulative(self):
        while True:
            time.sleep(self.processingWindow)
            if len(self.states) > 0:
                self.transitionMatrix = TransitionMatrix(self.numberOfStates,self.states)
                if self.endBackendOperations is True:
                    break
    #Finds fixations
    def find_fixations_cumulative(self , sample):
        self.sample = copy.deepcopy(sample)
        if int(sample.id) == 1:
            self.currentSample = copy.deepcopy(sample)
            self.previousSample = copy.deepcopy(self.currentSample)
        else:
            self.currentSample = copy.deepcopy(sample)
            if (self.previousSample.gazeEventType is None) and (self.currentSample.gazeEventType == "Fixation"):
                self.startOfFixation = True
                self.fixation = []
                self.fixation.append(self.currentSample)
            if (self.startOfFixation is True) and (self.previousSample.gazeEventType is "Fixation") \
                    and (self.currentSample.gazeEventType is "Fixation"):
                self.fixation.append(self.currentSample)
            if (self.startOfFixation is True) and (self.previousSample.gazeEventType is "Fixation") \
                    and (self.currentSample.gazeEventType is None):
                self.startOfFixation = False
                fixationObject = self.samples_to_fixation(self.fixation)
                self.fixationCounter = self.fixationCounter + 1
                fixationObject.sequence = self.fixationCounter
                fixationObject = self.filter_fixation(fixationObject)
                if (fixationObject is not None) and (fixationObject.fixationAOI != -1):
                    self.fixations.append(fixationObject)
                    self.states.append(fixationObject.fixationAOI)
                    self.windowStates.append(fixationObject.fixationAOI)
                    self.latestFixation = copy.deepcopy(fixationObject)
            self.previousSample = copy.deepcopy(self.currentSample)
        # self.create_transtions()

    # def find_fixations_window(self , sample):
    #     if int(sample.id) == 1:
    #         self.currentSample = copy.deepcopy(sample)
    #         self.previousSample = copy.deepcopy(self.currentSample)
    #     else:
    #         self.currentSample = copy.deepcopy(sample)
    #
    #         self.previousSample = copy.deepcopy(self.currentSample)
