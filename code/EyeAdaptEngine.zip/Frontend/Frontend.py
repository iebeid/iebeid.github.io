from threading import Lock
from flask import Flask, render_template, request
from flask_socketio import SocketIO
import socket

async_mode = None
app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app, async_mode=async_mode)
thread = None
thread_lock = Lock()

def background_thread():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(("localhost", 11300))
    while True:
        socketio.sleep(0.001)
        data, addr = sock.recvfrom(2048)
        line = data.decode("utf-8")
        socketio.emit('sample', line, namespace='/test')

@app.route('/')
def index():
    return render_template('index.html', async_mode=socketio.async_mode)

@socketio.on('connect', namespace='/test')
def connect():
    global thread
    print('Client connected')
    with thread_lock:
        if thread is None:
            thread = socketio.start_background_task(target=background_thread)

@socketio.on('disconnect', namespace='/test')
def disconnect():
    print('Client disconnected', request.sid)

def run():
    socketio.run(app, debug=True)

if __name__ == "__main__":
    run()