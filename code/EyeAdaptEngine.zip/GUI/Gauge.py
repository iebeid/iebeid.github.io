
import random
import numpy as np
from matplotlib import cm
from matplotlib import pyplot as plt
from matplotlib.patches import Circle, Wedge, Rectangle

class Gauge:
    def __init__(self,labels,colors,title,delay,numberOfFrames):
        plt.ion()
        self.labels = labels
        self.colors= colors
        self.title = title
        self.delay = delay
        self.numberOfFrames = numberOfFrames
        self.animationCounter = 0
        self.currentKeyframe = 0
        self.previousKeyframe = 0
        self.N = len(self.labels)
        if isinstance(self.colors, str):
            cmap = cm.get_cmap(self.colors, self.N)
            cmap = cmap(np.arange(self.N))
            self.colors = cmap[::-1, :].tolist()
        if isinstance(self.colors, list):
            if len(self.colors) == self.N:
                self.colors = self.colors[::-1]
            else:
                raise Exception("Number of colors {} not equal to number of categories{}".format(len(self.colors), self.N))
        self.fig, self.ax = plt.subplots()
        self.ang_range, self.mid_points = self.degree_range(self.N)
        self.labels = self.labels[::-1]


    def draw_gauge(self,pos,fontsize):
        plt.cla()
        self.ax.arrow(0, 0, 0.225 * np.cos(np.radians(pos)), 0.225 * np.sin(np.radians(pos)), width=0.04, head_width=0.09, head_length=0.1, fc='k', ec='k')
        patches = []
        for ang, c in zip(self.ang_range, self.colors):
            patches.append(Wedge((0., 0.), .4, *ang, facecolor='w', lw=2))
            patches.append(Wedge((0., 0.), .4, *ang, width=0.10, facecolor=c, lw=2, alpha=0.5))
        [self.ax.add_patch(p) for p in patches]
        for mid, lab in zip(self.mid_points, self.labels):
            self.ax.text(0.35 * np.cos(np.radians(mid)), 0.35 * np.sin(np.radians(mid)), lab, horizontalalignment='center',
                         verticalalignment='center', fontsize=fontsize, fontweight='bold', rotation=self.rot_text(mid))
        r = Rectangle((-0.4, -0.1), 0.8, 0.1, facecolor='w', lw=2)
        self.ax.add_patch(r)
        self.ax.text(0, -0.05, self.title, horizontalalignment='center', verticalalignment='center', fontsize=22, fontweight='bold')
        self.ax.add_patch(Circle((0, 0), radius=0.02, facecolor='k'))
        self.ax.add_patch(Circle((0, 0), radius=0.01, facecolor='w', zorder=11))
        self.ax.set_frame_on(False)
        self.ax.axes.set_xticks([])
        self.ax.axes.set_yticks([])
        self.ax.axis('equal')
        self.ax.plot()

    def wiggle_arrow(self,frame, fontsize, tolerance):
        self.draw_gauge(frame, fontsize)
        plt.pause(self.delay / self.numberOfFrames)
        self.draw_gauge(frame + tolerance, fontsize)
        plt.pause(self.delay / self.numberOfFrames)
        self.draw_gauge(frame, fontsize)
        plt.pause(self.delay / self.numberOfFrames)
        self.draw_gauge(frame - tolerance, fontsize)
        plt.pause(self.delay / self.numberOfFrames)
        self.draw_gauge(frame, fontsize)
        plt.pause(self.delay / self.numberOfFrames)

    def draw(self,arrow,rounding,fontsize,sensitivity):
        angles = np.linspace(0, 180, sensitivity+1, endpoint=True)[::-1]
        values = np.linspace(0, 1, sensitivity+1, endpoint=True)
        roundedArrowIndex = round(arrow, rounding)
        c = 0
        for i in range(0,values.size):
            if np.allclose([float(values[i])],[float(roundedArrowIndex)]):
                c = i
        pos = angles[c]
        self.animationCounter = self.animationCounter + 1
        if self.animationCounter == 1:
            self.currentKeyframe = pos
            self.previousKeyframe = self.currentKeyframe
        else:
            self.currentKeyframe = pos
            frames = np.linspace(self.previousKeyframe, self.currentKeyframe, num=self.numberOfFrames, endpoint=True)
            for i in range(0,self.numberOfFrames):
                self.wiggle_arrow(frames[i], fontsize, 3)
                # plt.pause(self.delay/self.numberOfFrames)
            self.previousKeyframe = self.currentKeyframe

    def degree_range(self,n):
        start = np.linspace(0,180,n+1,endpoint=True)[0:-1]
        end = np.linspace(0,180,n+1,endpoint=True)[1::]
        mid_points = start + ((end-start)/2.)
        return np.c_[start, end], mid_points

    def rot_text(self,ang):
        rotation = np.degrees(np.radians(ang) * np.pi / np.pi - np.radians(90))
        return rotation