import socket

if __name__ == "__main__":
    port_number = 11310 # Create a TCP/IP socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM) # Connect the socket to the port where the server is listening
    server_address = ("localhost", port_number)
    print("Connecting to %s port %s" % server_address)
    sock.connect(server_address)
    file = open('D:/IAE/Projects/EyeAdaptUI/Data/Main/P28/online.txt', 'w')
    while True:
        data = sock.recv(2048)
        print(str(data))
        file.write(str(data.decode('utf-8')))