import sys
import json
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from Controllers.Server import Server
from Controllers.Analyzer import Analyzer
from Models import Screen
from Core import Utils as u
from GUI.Interface import Ui_MainWindow
from PyQt5 import QtGui
from PyQt5.QtWidgets import QApplication, QDialog, QPushButton, QVBoxLayout
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
from matplotlib.figure import Figure
import subprocess
import webbrowser
import os
import random
import random
from GUI.Gauge import Gauge
from matplotlib import pyplot as plt

class MainWindow(QMainWindow, Ui_MainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        Ui_MainWindow.__init__(self)
        self.left = 100
        self.top = 100
        self.width = 920
        self.height = 920
        self.setGeometry(self.left, self.top, self.width, self.height)
        self.setupUi(self)
        #buttons
        self.pushButton.clicked.connect(self.analyzer_handler)
        # Load parameters from file into a line edit
        parameters = json.load(open("Config/parameters.json"))
        # simulation
        self.simPortNumber = int(parameters["parameters"]["simulation"]["port_number"])
        self.simServerName = str(parameters["parameters"]["simulation"]["server_name"])
        self.delay = float(parameters["parameters"]["simulation"]["delay"])
        self.simBufferSize = int(parameters["parameters"]["simulation"]["buffer_size"])
        self.fileName = str(parameters["parameters"]["simulation"]["file_name"])
        self.simDataPath = str(parameters["parameters"]["simulation"]["data_path"])
        # proxy
        self.proxyPortNumber = int(parameters["parameters"]["proxy"]["port_number"])
        self.proxyServerName = str(parameters["parameters"]["proxy"]["server_name"])
        self.iMotionsPortNumber = int(parameters["parameters"]["proxy"]["iMotions_port"])
        self.iMotionsServerName = str(parameters["parameters"]["proxy"]["iMotions_server"])
        self.proxyBufferSize = int(parameters["parameters"]["proxy"]["buffer_size"])
        self.proxyDataPath = str(parameters["parameters"]["proxy"]["data_path"])
        #listener
        self.portNumber = int(parameters["parameters"]["listener"]["port_number"])
        self.serverName = str(parameters["parameters"]["listener"]["server_name"])
        self.bufferSize = int(parameters["parameters"]["listener"]["buffer_size"])
        self.dataPath = str(parameters["parameters"]["listener"]["data_path"])
        self.minimumFixationDuration = int(parameters["parameters"]["listener"]["min_fix_duration"])
        self.maximumTimeBetweenFixations = int(parameters["parameters"]["listener"]["max_time_between_fix"])
        self.windowLength = int(parameters["parameters"]["listener"]["window_length"])
        self.fixationVelocityThreshold = float(parameters["parameters"]["listener"]["fixation_velocity_threshold"])
        self.fixationDegreesThreshold = float(parameters["parameters"]["listener"]["fixation_degrees_threshold"])
        self.fixationTimeThreshold = float(parameters["parameters"]["listener"]["fixation_time_threshold"])
        # listener
        self.lineEdit_16.setText(str(self.portNumber))
        self.lineEdit_17.setText(str(self.serverName))
        self.lineEdit_18.setText(str(self.bufferSize))
        self.lineEdit_19.setText(str(self.dataPath))
        self.lineEdit_20.setText(str(self.minimumFixationDuration))
        self.lineEdit_21.setText(str(self.maximumTimeBetweenFixations))
        self.lineEdit_22.setText(str(self.windowLength))
        # proxy
        self.lineEdit_5.setText(str(self.proxyPortNumber))
        self.lineEdit_6.setText(str(self.proxyServerName))
        self.lineEdit_7.setText(str(self.iMotionsPortNumber))
        self.lineEdit_8.setText(str(self.iMotionsServerName))
        self.lineEdit_11.setText(str(self.proxyDataPath))
        self.lineEdit_12.setText(str(self.proxyBufferSize))
        # simulation
        self.lineEdit.setText(str(self.simPortNumber))
        self.lineEdit_2.setText(str(self.simServerName))
        self.lineEdit_3.setText(str(self.delay))
        self.lineEdit_4.setText(str(self.simBufferSize))
        self.lineEdit_9.setText(str(self.fileName))
        self.lineEdit_10.setText(str(self.simDataPath))
        #Gauge stuff
        # self.figure = Figure()
        # self.canvas = FigureCanvas(self.figure)

        # labels = ['Low Attention', '', 'Optimum Attention', '', 'Chaotic Attention']
        # colors = ['red', 'orange', 'green', 'orange', 'red']
        # title = 'Entropy'
        # self.gauge = Gauge(labels, colors, title, 0.5, 20)
        # self.canvas = FigureCanvas(self.gauge.fig)
        # # self.gauge.draw(random.randint(1, 5))
        # # self.canvas.draw()
        # self.gridLayout_6.addWidget(self.canvas)


        # self.gauge.draw(random.randint(1, 5))

        #screen
        self.screen = Screen.Screen(float(parameters["parameters"]["screen"]["screen_width_in_CM"]),
                                    float(parameters["parameters"]["screen"]["screen_height_in_CM"]),
                                    int(parameters["parameters"]["screen"]["screen_resolution_width"]),
                                    int(parameters["parameters"]["screen"]["screen_resolution_height"]),
                                    float(parameters["parameters"]["screen"]["default_distance_from_screen"]))
        self.screen.ppi = u.calculate_ppi(self.screen)
        self.screen.ipp = u.calculate_ipp(self.screen)
        self.gridSize = int(parameters["parameters"]["screen"]["grid_size"])
        self.threadpool = QThreadPool()
        print("Multithreading with maximum %d threads" % self.threadpool.maxThreadCount())

    def analyzer_handler(self):
        self.serverThread = Server(self.portNumber, self.serverName, self.delay, self.bufferSize, self.fileName,
                              self.dataPath)
        self.threadpool.start(self.serverThread)
        self.analyzerThread = Analyzer(self.screen, self.portNumber, self.serverName,
                                  self.bufferSize, self.dataPath,
                                  self.minimumFixationDuration,
                                  self.maximumTimeBetweenFixations, self.windowLength, self.gridSize,
                                  self.fixationVelocityThreshold, self.fixationDegreesThreshold, self.fixationTimeThreshold)
        self.analyzerThread.signals.result.connect(self.update_gui_image)
        self.threadpool.start(self.analyzerThread)

    def update_gui_image(self, sample):
        x=0
        # self.canvas.draw()
        # self.gauge.draw(random.randint(1, 5))
        # sampleObject = json.loads(sample)
        # print(str(sampleObject))
        # self.lcdNumber_4.display(sampleObject["trialNumber"])
        # self.lcdNumber.display(sampleObject["transitionMatrixEntropy"])
        # self.lcdNumber_2.display(sampleObject["stationaryDistributionEntropy"])
        # self.lcdNumber_3.display(sampleObject["numberOfTransitions"])
        # fileName = str(self.dataPath) + str(sampleObject["imageName"])
        # imageObject = QImage(fileName)

        #draw raw data

        # painterInstance = QPainter()
        # painterInstance.begin(imageObject)
        # painterInstance.setPen(QPen(Qt.red, 20))
        # if str(sampleObject["gazeEventType"]) == str("Fixation"):
        #     painterInstance.setPen(QPen(Qt.blue, 20))
        # else:
        #     painterInstance.setPen(QPen(Qt.green, 20))
        # picGeometry = self.label_16.geometry().topLeft()
        # pointX = float(sampleObject["gazePointX"])
        # pointY = float(sampleObject["gazePointY"])
        # scaleX = float(400/1920)
        # scaleY = float(400/1080)
        # imageTopLeftXRelativeToWidget = float(picGeometry.x())
        # imageTopLeftYRelativeToWidget = float(picGeometry.y())
        # widgetTopLeftXRelativeToScreen = float(self.left)
        # widgetTopLeftYRelativeToScreen = float(self.top)
        # originX = imageTopLeftXRelativeToWidget+widgetTopLeftXRelativeToScreen
        # originY = imageTopLeftYRelativeToWidget+widgetTopLeftYRelativeToScreen
        # translatePointX = float(pointX+originX)
        # translatePointY = float(pointY+originY)
        # realPointX = int(translatePointX*scaleX)
        # realPointY = int(translatePointY*scaleY)
        # point = QPoint(realPointX, realPointY)
        # painterInstance.drawPoint(point)
        # painterInstance.end()

        #####

        # pixmapImage = QPixmap(imageObject)
        # self.label_16.setPixmap(pixmapImage)

if __name__ == "__main__":
    now = QDate.currentDate()
    print(now.toString(Qt.ISODate))
    print(now.toString(Qt.DefaultLocaleLongDate))
    datetime = QDateTime.currentDateTime()
    print(datetime.toString())
    t = QTime.currentTime()
    print(t.toString(Qt.DefaultLocaleLongDate))
    app = QApplication(sys.argv)
    server_ui = MainWindow()
    server_ui.show()
    sys.exit(app.exec_())