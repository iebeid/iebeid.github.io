#Example stream calibration data: 00028002;EyeTracker;GazeCalibrationResult;-1;-1;5;Good;75;39.5251;24.3326
# <Sequence Number> : 00028002
# <Event Source> : EyeTracker
# <Sample Name> : GazeCalibrationResult
# <Timestamp> : -1
# <Media Time> : -1
# <Calibration Points> : 5
# <Calibration Quality (Excellent, Good or Poor)> : Good
# <Calibration Result (from 0 to 100)> : 75
# <Mean> : 39.5251
# <Standard Deviation> : 24.3326
#
# I need to calculate precision (RMS noise in pixels)
