
class FacsModel:

    def __init__(self, anger, sadness, disgust, joy, surprise, fear, contempt):
        self.anger = anger
        self.sadness = sadness
        self.disgust = disgust
        self.joy = joy
        self.surprise = surprise
        self.fear = fear
        self.contempt = contempt

    def getModel(self):
        return {'anger':self.anger,
                'sadness':self.sadness,
                'disgust':self.disgust,
                'joy':self.joy,
                'surprise':self.surprise,
                'fear':self.fear,
                'contempt':self.contempt}