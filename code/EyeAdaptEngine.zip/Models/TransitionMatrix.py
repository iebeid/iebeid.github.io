import numpy as np
import math
from scipy.stats import entropy
import copy

class Transition:
    def __init__(self, fromAOI=0,toAOI=0,count=0,numberOfTransitionsTillNow=0):
        self.fromAOI = fromAOI
        self.toAOI = toAOI
        self.count = count
        self.numberOfTransitionsTillNow = numberOfTransitionsTillNow

    def __eq__(self, other) :
        return self.__dict__ == other.__dict__

    def __str__(self):
        toBePrinted = "\n("+str(self.fromAOI)+" , "+str(self.toAOI)+")---->("\
                       +str(self.count)+"/"+str(self.numberOfTransitionsTillNow)+")"
        return toBePrinted

class TransitionMatrix:
    def __init__(self, numberOfStates, states):
        # self.transitions = copy.deepcopy(transitions)
        self.transitions = []
        self.states = copy.deepcopy(states)
        self.numberOfStates = numberOfStates
        self.T = np.zeros((self.numberOfStates, self.numberOfStates), dtype='float32')
        self.S = np.zeros(self.numberOfStates, dtype='float32')
        self.estimatedS = np.zeros(self.numberOfStates, dtype='float32')
        self.transitionMatrixEntropy = 0
        self.stationaryDistributionEntropy = 0
        self.sdTest = 0
        self.markovTest = 0
        if (self.numberOfStates != 0) and (self.states):
            self.create_transtions()
            self.create_transition_matrix()
            self.create_state_vector()
            self.compute_transition_matrix_normalized_entropy()
            self.compute_stationary_distribution_normalized_entropy()
            self.estimate_stationary_distribution()
            self.test_stationary_distribition_error()


    def create_transtions(self):
        stateCounter = 0
        currentState = 0
        previousState = 0

        numberOfTransitions = int(len(self.states) - 1)
        for state in self.states:
            stateCounter = stateCounter + 1
            if stateCounter == 1:
                currentState = copy.deepcopy(state)
                previousState = copy.deepcopy(currentState)
            else:
                currentState = copy.deepcopy(state)
                transition = Transition(previousState, currentState, 0, numberOfTransitions)
                self.transitions.append(transition)
                previousState = copy.deepcopy(currentState)

    def create_transition_matrix(self):
        for transition in self.transitions:
            transitionHash = str(transition.fromAOI) + str(transition.toAOI)
            for lookupTransition in self.transitions:
                lookupTransitionHash = str(lookupTransition.fromAOI) + str(lookupTransition.toAOI)
                if transitionHash == lookupTransitionHash:
                    transition.count = transition.count + 1
            fromAOI = int(str(transition.fromAOI))
            toAOI = int(str(transition.toAOI))
            probability = float(transition.count/transition.numberOfTransitionsTillNow)
            self.T[toAOI, fromAOI] = probability
        for rows in range(self.numberOfStates):
            if self.T[rows].sum() > 0:
                self.T[rows] /= self.T[rows].sum()
            else:
                self.T[rows] = float(1/self.numberOfStates)

    def create_state_vector(self):
        for s in range(self.numberOfStates):
            stateCounter = 0
            for lookupS in self.states:
                if s == lookupS:
                    stateCounter = stateCounter + 1
            self.S[s] = float(stateCounter/(len(self.states)))

    def estimate_stationary_distribution(self):
        self.W, self.V = np.linalg.eig(self.T.T)
        j_stationary = np.argmin(abs(self.W - 1.0))
        self.estimatedS = self.V[:,j_stationary].real
        self.estimatedS /= self.estimatedS.sum()

    def compute_transition_matrix_normalized_entropy(self):
        en = 0.0
        for i in range(self.numberOfStates):
            r = 0.0
            for j in range(self.numberOfStates):
                if self.T[j, i] != 0:
                    r = r + (self.T[j, i] * math.log2(self.T[j, i]))
                else:
                    r = r
            value = self.S[i] * r
            en = en + value
        en = -1.0 * en
        en = en / math.log2(self.numberOfStates)
        self.transitionMatrixEntropy = en

    def compute_stationary_distribution_normalized_entropy(self):
        sen = 0.0
        value = 0.0
        for i in range(self.numberOfStates):
            if self.S[i] != 0:
                value = self.S[i] * math.log2(self.S[i])
            else:
                value = value
            sen = sen + value
        sen = -1.0 * sen
        sen = sen / math.log2(self.numberOfStates)
        self.stationaryDistributionEntropy = sen

    def test_stationary_distribition_error(self):
        error = entropy(self.S, self.estimatedS, 2)
        if error == math.inf:
            error = -1
        self.sdTest = error

    def test_markov_property(self):
        self.markovTest = 0

    def create_dictionary(self):

        return {"numberOfTransitions": len(self.transitions),"states": self.states, "numberOfStates": self.numberOfStates, "T":self.T.tolist(),"S":self.S.tolist(),
                "transitionMatrixEntropy":self.transitionMatrixEntropy,"stationaryDistributionEntropy":self.stationaryDistributionEntropy,
                "sdTest":self.sdTest,"markovTest":self.markovTest}

    def __str__(self):
        m = ''
        for row in self.T: m = m + "\n" + str(' '.join('{0:.2f}'.format(x) for x in row))
        s = str(' '.join('{0:.2f}'.format(x) for x in self.S))
        toBePrinted = "Transition Matrix: \n" + str(m) \
                      + "\n\nStationary Distribution: \n\n" + str(s) \
                      + "\n\nTransition Matrix Entropy: " + str(self.transitionMatrixEntropy) \
                      + "\n\nStationary Distribution Entropy: " + str(self.stationaryDistributionEntropy) \
                      + "\n\nStationary Distribution Error: " + str(self.sdTest) \
                      + "\n\nMarkov Property Test: " + str(self.markovTest) + "\n-------------\n"
        return toBePrinted