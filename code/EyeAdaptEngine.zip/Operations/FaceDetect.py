
from os import path
import cv2
import numpy as np

class FaceDetection():
    def __init__(self, haar_cascade_filepath):
        self.classifier = cv2.CascadeClassifier(haar_cascade_filepath)
        self._min_size = (30, 30)

    def detect_faces(self, image: np.ndarray):
        gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        gray_image = cv2.equalizeHist(gray_image)

        faces = self.classifier.detectMultiScale(gray_image,
                                                 scaleFactor=1.3,
                                                 minNeighbors=4,
                                                 flags=cv2.CASCADE_SCALE_IMAGE,
                                                 minSize=self._min_size)
        return faces

    def image_data_slot(self, image_data):
        faces = self.detect_faces(image_data)
        if len(faces)>0:
            return 0
        elif len(faces)>1:
            return -2
        else:
            return -1

class Detect():
    def __init__(self, cameraPort):
        self.result = -1
        fp = path.abspath('C:/Users/islam/Box Sync/Projects/RealtimeGazeAnalysis/Code/PyCharmProjects/EyeAdaptEngine/Config/haarcascade_frontalface_default.xml')
        self.face_detection_widget = FaceDetection(fp)
        try:
            self.camera = cv2.VideoCapture(cameraPort)
        except:
            print("No webcam is setup")
            self.result = -3

    def run(self):
        ret, frame = self.camera.read()
        self.result = self.face_detection_widget.image_data_slot(frame)
        return self.result

    def final(self):
        self.camera.release()

# if __name__ == '__main__':
#     main_widget = Detect(0)
#     while True:
#         check = main_widget.run()
#         print(str(check))