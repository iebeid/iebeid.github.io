# from setuptools import setup
#
# setup(
#     name='RealtimeOculomotorFramework',
#     version='0.1',
#     packages=['AOI', 'Utils', 'Server', 'Listener', 'Affectiva', 'SituationAwareness'],
#     url='www.i3akef.com',
#     license='Apache',
#     author='Islam Akef Ebeid',
#     author_email='iaebeid@utexas.edu',
#     description=''
# )

import subprocess

subprocess.run(["D:/Programs/Anaconda3/Scripts/pyuic5.exe",
                "C:/Users/islam/Box Sync/Projects/Spring2018/RealtimeGazeAnalysis/Code/PyCharmProjects/EyeAdaptEngine/GUI/main.ui", "-o" ,
                "C:/Users/islam/Box Sync/Projects/Spring2018/RealtimeGazeAnalysis/Code/PyCharmProjects/EyeAdaptEngine/GUI/Interface.py"],
               stdout=subprocess.PIPE)
