print("Hello World!")
# install.packages('RMySQL', repos='http://cran.us.r-project.org')
# install.packages('expm', repos='http://cran.us.r-project.org')
# install.packages('markovchain', repos='http://cran.us.r-project.org')
# install.packages('diagram', repos='http://cran.us.r-project.org')

library(markovchain)