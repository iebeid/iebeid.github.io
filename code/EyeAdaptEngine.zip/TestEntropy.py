import numpy as np
import math
from Models.TransitionMatrix import Transition
from Models.TransitionMatrix import TransitionMatrix
from scipy.stats import entropy

def compute_transition_matrix_normalized_entropy(T,S,numberOfStates):
    en = 0.0
    for i in range(numberOfStates):
        r = 0.0
        for j in range(numberOfStates):
            if T[j, i] != 0:
                r = r + (T[j, i] * math.log2(T[j, i]))
            else:
                r = r
        value = S[i] * r
        en = en + value
    en = -1.0 * en
    en = en / math.log2(numberOfStates)
    return en

def compute_stationary_distribution_normalized_entropy(S,numberOfStates):
    sen = 0.0
    value = 0.0
    for i in range(numberOfStates):
        if S[i] != 0:
            value = S[i] * math.log2(S[i])
        else:
            value = value
        sen = sen + value
    sen = -1.0 * sen
    sen = sen / math.log2(numberOfStates)
    return sen

T = np.array([[0.78, 0.06, 0.16], [0.18, 0.46, 0.36], [0.15, 0.09, 0.76]])
numberOfStates = 3
S = [0.42,0.14,0.44]

print("Transition Matrix")
for row in T: print(' '.join('{0:.2f}'.format(x) for x in row))
print("Stationary Distribution")
print(str(S))
print("Transition Matrix Normlized Entropy")
en = compute_transition_matrix_normalized_entropy(T,S,numberOfStates)
print(en)
print("Stationary Distribution Normlized Entropy")
sen = compute_stationary_distribution_normalized_entropy(S,numberOfStates)
print(sen)



# def create_transtions(states):
#     stateCounter = 0
#     currentState = 0
#     previousState = 0
#     transitions = []
#     for state in states:
#         stateCounter = stateCounter + 1
#         if stateCounter == 1:
#             currentState = state
#             previousState = currentState
#         else:
#             currentState = state
#             transition = Transition(previousState, currentState, 0, int(len(states) - 1))
#             transitions.append(transition)
#             previousState = currentState
#     return transitions
#
# states = [1, 3, 2, 2, 2, 2, 0, 2, 3, 3]
#
# numberOfStates = 4
#
# transitionMatrix = TransitionMatrix(numberOfStates,states)
# transitionMatrix.create_transition_matrix()

# P = np.array([[0.78,0.06,0.16],[0.18,0.46,0.36],[0.15,0.09,0.76]])
# numberOfStates = 3
# # P = transitionMatrix.T
# print("Transition Matrix")
# for row in P: print(' '.join('{0:.2f}'.format(x) for x in row))
# w, v = np.linalg.eig(P.T)
# j_stationary = np.argmin(abs(w - 1.0))
# p_stationary = v[:,j_stationary].real
# p_stationary /= p_stationary.sum()
# print("State Vector")
# # state_vector = [float(1/10),float(1/10),float(5/10),float(3/10)]
# state_vector = [0.42,0.14,0.44]
# print(str(state_vector))
# print("Stationary Distribution")
# print(p_stationary)
# print("Transition Matrix Normlized Entropy")
# en = 0.0
# for i in range(numberOfStates):
#     r = 0.0
#     for j in range(numberOfStates):
#         if P[j,i] != 0:
#             r = r + (P[j,i] * math.log2(P[j,i]))
#         else:
#             r = r
#     value = p_stationary[i] * r
#     en = en + value
# en = -1.0 * en
# en = en / math.log2(numberOfStates)
# print(en)
# print("Stationary Distribution Normlized Entropy")
# sen = 0.0
# value = 0.0
# for i in range(numberOfStates):
#     if p_stationary[i] != 0:
#         value = p_stationary[i] * math.log2(p_stationary[i])
#     else:
#         value = value
#     sen = sen + value
# sen = -1.0 * sen
# sen = sen / math.log2(numberOfStates)
# print(sen)
# print("Test First Order Markov Property")
# test = entropy(state_vector,p_stationary,2)
# print(test)