# import numpy as np
# points = np.linspace(0,180, 20 + 1, endpoint=True)
# print(points)

# import random
# from GUI.Gauge import Gauge
#
# if __name__ == "__main__":
#     labels = ['Low Attention', '', 'Optimum Attention', '', 'Chaotic Attention']
#     colors = ['red', 'orange', 'green', 'orange', 'red']
#     title = 'Entropy'
#     g = Gauge(labels,colors,title,0.001,10)
#     while True:
#         g.draw(random.uniform(0, 1),3,12,1000)




# import random
# import numpy as np
# from matplotlib import cm
# from matplotlib import pyplot as plt
# from matplotlib.patches import Circle, Wedge, Rectangle
# from PyQt5 import QtGui
# from PyQt5.QtWidgets import QApplication, QDialog, QPushButton, QVBoxLayout
# from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
# from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
# from Core import Utils as u
# from GUI.Interface import Ui_MainWindow
# from PyQt5 import QtGui
# from PyQt5.QtWidgets import QApplication, QDialog, QPushButton, QVBoxLayout
# from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
# from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
# from matplotlib.figure import Figure
#
# def degree_range(n):
#     start = np.linspace(0, 180, n + 1, endpoint=True)[0:-1]
#     end = np.linspace(0, 180, n + 1, endpoint=True)[1::]
#     mid_points = start + ((end - start) / 2.)
#     return np.c_[start, end], mid_points
#
#
# def rot_text(ang):
#     rotation = np.degrees(np.radians(ang) * np.pi / np.pi - np.radians(90))
#     return rotation
#
#
# if __name__ == "__main__":
#     labels = ['Low Attention', '', 'Optimum Attention', '', 'Chaotic Attention']
#     colors = ['red', 'orange', 'green', 'orange', 'red']
#     title = 'Entropy'
#
#     delay = 1.0
#     numberOfFrames = 20
#     animationCounter = 0
#     currentKeyframe = 0
#     previousKeyframe = 0
#     N = len(labels)
#
#     figure = Figure()
#     canvas = FigureCanvas(figure)
#     ax = figure.add_subplot(111)
#
#     ang_range, mid_points = degree_range(N)
#     labels = labels[::-1]
#
#     while True:
#         plt.cla()
#
#         arrow = random.randint(1, 5)
#         if arrow > N:
#             raise Exception("The category ({}) is greater than the length of the labels ({})".format(arrow, N))
#         pos = mid_points[abs(int(arrow) - N)]
#         animationCounter = animationCounter + 1
#         if animationCounter == 1:
#             currentKeyframe = pos
#             previousKeyframe = currentKeyframe
#
#
#
#             ax.arrow(0, 0, 0.225 * np.cos(np.radians(pos)), 0.225 * np.sin(np.radians(pos)), width=0.04,
#                           head_width=0.09, head_length=0.1, fc='k', ec='k')
#             patches = []
#             for ang, c in zip(ang_range, colors):
#                 patches.append(Wedge((0., 0.), .4, *ang, facecolor='w', lw=2))
#                 patches.append(Wedge((0., 0.), .4, *ang, width=0.10, facecolor=c, lw=2, alpha=0.5))
#             [ax.add_patch(p) for p in patches]
#             for mid, lab in zip(mid_points, labels):
#                 ax.text(0.35 * np.cos(np.radians(mid)), 0.35 * np.sin(np.radians(mid)), lab,
#                              horizontalalignment='center',
#                              verticalalignment='center', fontsize=7, fontweight='bold', rotation=rot_text(mid))
#             r = Rectangle((-0.4, -0.1), 0.8, 0.1, facecolor='w', lw=2)
#             ax.add_patch(r)
#             ax.text(0, -0.05, title, horizontalalignment='center', verticalalignment='center', fontsize=22,
#                          fontweight='bold')
#             ax.add_patch(Circle((0, 0), radius=0.02, facecolor='k'))
#             ax.add_patch(Circle((0, 0), radius=0.01, facecolor='w', zorder=11))
#             ax.set_frame_on(False)
#             ax.axes.set_xticks([])
#             ax.axes.set_yticks([])
#             ax.axis('equal')
#             ax.plot()
#
#
#         else:
#             currentKeyframe = pos
#             frames = np.linspace(previousKeyframe, currentKeyframe, num=numberOfFrames, endpoint=True)
#             for i in range(0,numberOfFrames):
#                 pos = frames[i]
#
#                 plt.cla()
#
#                 ax.arrow(0, 0, 0.225 * np.cos(np.radians(pos)), 0.225 * np.sin(np.radians(pos)), width=0.04,
#                          head_width=0.09, head_length=0.1, fc='k', ec='k')
#                 patches = []
#                 for ang, c in zip(ang_range, colors):
#                     patches.append(Wedge((0., 0.), .4, *ang, facecolor='w', lw=2))
#                     patches.append(Wedge((0., 0.), .4, *ang, width=0.10, facecolor=c, lw=2, alpha=0.5))
#                 [ax.add_patch(p) for p in patches]
#                 for mid, lab in zip(mid_points, labels):
#                     ax.text(0.35 * np.cos(np.radians(mid)), 0.35 * np.sin(np.radians(mid)), lab,
#                             horizontalalignment='center',
#                             verticalalignment='center', fontsize=7, fontweight='bold', rotation=rot_text(mid))
#                 r = Rectangle((-0.4, -0.1), 0.8, 0.1, facecolor='w', lw=2)
#                 ax.add_patch(r)
#                 ax.text(0, -0.05, title, horizontalalignment='center', verticalalignment='center', fontsize=22,
#                         fontweight='bold')
#                 ax.add_patch(Circle((0, 0), radius=0.02, facecolor='k'))
#                 ax.add_patch(Circle((0, 0), radius=0.01, facecolor='w', zorder=11))
#                 ax.set_frame_on(False)
#                 ax.axes.set_xticks([])
#                 ax.axes.set_yticks([])
#                 ax.axis('equal')
#                 ax.plot()
#
#
#                 plt.pause(delay/numberOfFrames)
#             previousKeyframe = currentKeyframe
#
#         plt.pause(1.0)