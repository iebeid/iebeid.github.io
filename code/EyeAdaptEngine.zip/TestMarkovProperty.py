
#
# import os
# from pyRscript import pyRscript
# RPATH = 'C:/Program Files/R/R-3.4.4/bin/x64'
# cmd = '-d,SN1234,-t,2017-07-13 00:00:00'
# r = pyRscript.Rscript(path=RPATH,
#                       file='C:/Users/islam/Box Sync/Projects/RealtimeGazeAnalysis/Code/PyCharmProjects/OnlineGazeAnalysis/Setup/rscript.R',
#                       cmd=cmd)
# print(r)
#
# ret = r.execute()
# print(ret)
# print(ret.returncode)
#
# print(ret.stdout)
#
# print(ret.stderr)
