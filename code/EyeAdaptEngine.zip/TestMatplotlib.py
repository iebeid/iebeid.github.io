
# import sys
# from matplotlib import pyplot as plt
# from PyQt5 import QtGui
# from PyQt5.QtWidgets import QApplication, QDialog, QPushButton, QVBoxLayout
# from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
# from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
# from matplotlib.figure import Figure
# import random
#
# class Window(QDialog):
#     def __init__(self, parent=None):
#         super(Window, self).__init__(parent)
#         plt.ion()
#         self.figure = Figure()
#         self.canvas = FigureCanvas(self.figure)
#         self.ax = self.figure.add_subplot(111)
#         layout = QVBoxLayout()
#         layout.addWidget(self.canvas)
#         self.setLayout(layout)
#         data = [random.random() for i in range(10)]
#         print(str(data))
#         self.ax.clear()
#         self.ax.plot(data, '*-')
#         self.canvas.draw()
#         plt.pause(1.0)
#
# if __name__ == '__main__':
#     app = QApplication(sys.argv)
#     main = Window()
#     main.show()
#     sys.exit(app.exec_())