# import cv2
#
# def GenerateAOI(grid_size, image_width, image_height, screen_width, screen_height):
#     rows = grid_size
#     cols = grid_size
#     for r in range(rows):
#         for c in range(cols):
#