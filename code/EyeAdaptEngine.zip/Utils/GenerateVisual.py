import sys
import time
import pygame

pygame.init()
screen = pygame.display.set_mode((1920, 1080),pygame.FULLSCREEN)
done = False
file = open('../Data/Study1/ground-truth.txt', 'r')

while not done:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
    counter = 1
    for line in file:
        if counter > 1:
            if line != '\n':
                fields = line.split("\t")
                GazeX = fields[13]
                GazeY = fields[14]
                GazeEventType = fields[15]
                if str(GazeEventType) == "Unclassified":
                    pygame.draw.rect(screen, (255, 0, 0), pygame.Rect(float(GazeX), float(GazeY), 5, 5))
                if str(GazeEventType) == "Saccade":
                    pygame.draw.rect(screen, (0, 255, 0), pygame.Rect(float(GazeX), float(GazeY), 5, 5))
                if str(GazeEventType) == "Fixation":
                    pygame.draw.rect(screen, (0, 0, 255), pygame.Rect(float(GazeX), float(GazeY), 5, 5))
        counter = counter + 1
    pygame.display.flip()

file.close()