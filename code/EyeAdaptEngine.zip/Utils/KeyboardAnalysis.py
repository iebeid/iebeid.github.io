import os
stimuli = ["S01","S02","S03","S04","S05","S06","S07","S08","S09", "S10","S11","S13","S14","S15","S16","S18"]
stimuliOriginal = ["S01-c","S02-c","S03-c","S04-c","S05-c","S06-c","S07-c","S08-c","S09-c",
                    "S10-c","S11-c","S13-c","S14-c","S15-c","S16-c","S18-c"]
stimuliDistorted = ["S01-a-L","S01-a-M","S01-a-S",
                    "S02-a-L","S02-a-M","S02-a-S",
                    "S03-a-L","S03-a-M","S03-a-S",
                    "S04-a-L","S04-a-M","S04-a-S",
                    "S05-a-L","S05-a-M","S05-a-S",
                    "S06-a-L","S06-a-M","S06-a-S",
                    "S07-a-L","S07-a-M","S07-a-S",
                    "S08-a-L","S08-a-M","S08-a-S",
                    "S09-a-L","S09-a-M","S09-a-S",
                    "S10-a-L","S10-a-M","S10-a-S",
                    "S11-a-L","S11-a-M","S11-a-S",
                    "S13-a-L","S13-a-M","S13-a-S",
                    "S14-a-L","S14-a-M","S14-a-S",
                    "S15-a-L","S15-a-M","S15-a-S",
                    "S16-a-L","S16-a-M","S16-a-S",
                    "S18-a-L","S18-a-M","S18-a-S"]
users = ["P01","P02","P03","P04","P05","P06","P07","P08","P09","P10",
         "P11","P12","P13","P14","P15","P16","P17","P18","P19","P20",
         "P21","P22","P23","P24","P25","P26","P27","P28","P29","P30",
         "P31","P32"]
directory = "C:/Users/islam/Box Sync/04 EyeArt/results-finalstudy"
for userDir in os.listdir(directory):
    if userDir in users:
        filePath = directory + "/"+userDir+"/"
        fileToOpen = filePath + "data.txt"
        file = open(fileToOpen, "r")
        messageSizes = [6,8,10,11,18,150]
        start = False
        trialNumber = 0
        imageName = ''
        newImageName = ''
        priorKnowledge = "No"
        recognized = "No"
        for line in file:
            if line != "\n":
                parsedMessage = line.split(";")
                if int(len(parsedMessage)) in messageSizes:
                    eventSource = parsedMessage[1].strip().rstrip()
                    sampleName = parsedMessage[2].strip().rstrip()
                    if (str(eventSource) == str("AttentionTool")):

                        if (str(sampleName) == str("SlideStart")):
                            imageName = str(parsedMessage[6].strip().rstrip())

                        if (str(sampleName) == str("SlideEnd")):
                            if "-d" in imageName:
                                if imageName[:-4] in stimuli:
                                    print(str(userDir) + "," + str(imageName[:-4]) + "," + recognized + "," + priorKnowledge)

                        if (str(sampleName) == str("Keyboard")) and (parsedMessage[5].strip().rstrip()=="Up"):
                            if (imageName in stimuliDistorted):
                                recognized = "Yes"
                                priorKnowledge = "Yes"
                            if (imageName in stimuliOriginal):
                                priorKnowledge = "Yes"
