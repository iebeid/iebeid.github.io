# coding=UTF-8
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#          Getting the AOI data from the XML file             #
#                    Writen by Amélie                         #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
import re

from lxml import etree


def parseAoi(fileName, dispsize):
    # parse xml file to get the measures
    file = etree.parse(fileName)

    AOINUM = 0
    aoi = []  # have to define multiple AoIs and keep them
    cont = False

    aoiListD = [] # list to define the distance between aois

    # visit the tree structure to be where we have data
    for highlight in file.xpath("/iMotions/highlightTemplate/highlight"):
        children = highlight.getchildren()

        label = highlight.get('label')

        for child in children:
            # getting the vertices of the shape
            if (child.tag == 'vertices'):
                subchildren = child.getchildren()

                # only accept certain type of shapes
                if len(subchildren) == 2:
                    cont = True

                    # extracting the float from the string
                    vert1 = re.findall(r"[-+]?\d*\.\d+|\d+", subchildren[0].get("point"))
                    vert2 = re.findall(r"[-+]?\d*\.\d+|\d+", subchildren[1].get("point"))

                    # computing width and length from the measures
                    width = float(vert2[0]) - float(vert1[0])  # x2 - x1
                    width = width * dispsize[0]
                    if width < 0:
                        width = -width

                    height = float(vert2[1]) - float(vert1[1])  # y2 - y1
                    height = height * dispsize[1]
                    if height < 0:
                        height = -height

                    # measures in the AOI format
                    length = (width, height)

                else:
                    print("Shape not accepted")
                    cont = False

            # extracting the shape from the XML file
            elif (child.tag == 'shape'):
                shape = child.text

            # if everything is valid then define AOI
            if cont:
                # if everything is valid then define AOI
                if cont:
                    # value = (label, AOI(shape.lower(), (float(vert1[0]) * dispsize[0],
                    #                                     float(vert1[1]) * dispsize[1]), length))
                    # aoi.append(value)
                    #
                    # measure = (float(vert1[0]) * dispsize[0], float(vert1[1]) * dispsize[1],
                    #            float(vert2[0]) * dispsize[0], float(vert2[1]) * dispsize[1], label)
                    # aoiListD.append(measure)

                    # useful for later to have the number of AoI
                    AOINUM = + 1

                    # so we don't have mix between shapes
                    cont = False

    return aoi, aoiListD