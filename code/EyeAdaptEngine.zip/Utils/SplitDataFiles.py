file = open("C:/Users/islam/Box Sync/RealtimeGazeAnalysis/Data/DRIVER-VIDEO/data.txt", "r")
counter = 0
datafile = 0
start = False
for line in file:
    if line != "\n":
        parsedMessage = line.split(";")
        eventSource = parsedMessage[1].strip().rstrip()
        sampleName = parsedMessage[2].strip().rstrip()
        print(line)
        if (str(eventSource) == str("EyeTracker")) and (str(sampleName) == str("GazeCalibrationResult")):
            counter = counter + 1
            datafile = open("C:/Users/islam/Box Sync/RealtimeGazeAnalysis/Data/DRIVER-VIDEO/data"+str(counter)+".txt", "w")
            start = True

        if (str(eventSource) == str("AttentionTool")) and (str(sampleName) == str("SlideEnd")):
            start = False

        if start:
            datafile.write(str(line))
