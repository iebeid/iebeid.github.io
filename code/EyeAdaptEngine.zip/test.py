# #Test Kalman Filter Implementation
#
# import numpy as np
# import cv2
#
# def draw_mouse(event,x,y,flags,param):
#     cv2.circle(img, (x, y), 1, (0, 0, 255))
#
# if __name__ == "__main__":
#     winname = "Kalman Test"
#     screenPosX = 100
#     screenPosY = 100
#     windowSizeX = 512
#     windowSizeY = 512
#     img = np.zeros((windowSizeX, windowSizeY, 3), np.uint8)
#     cv2.namedWindow(winname)
#     cv2.moveWindow(winname, screenPosX, screenPosY)
#     cv2.setMouseCallback(winname, draw_mouse)
#     while True:
#         cv2.imshow(winname, img)
#         cv2.waitKey(1)

# import matplotlib.pyplot as plt
# import numpy as np
# from numpy.random import randn

# weights = [158.0, 164.2, 160.3, 159.9, 162.1, 164.6, 169.6, 167.4, 166.4, 171.0, 171.2, 172.6]
# prediction = 160.0
# time_step = 1.0
# weight_belief = 4.0 / 10.0
# gain_belief = 1.0/3.0
# gain_rate = -1.0
#
# estimates, predictions = [prediction], []
#
# for z in weights:
#     # predict new position
#     prediction = prediction + (gain_rate * time_step)
#     gain_rate = gain_rate
#     predictions.append(prediction)
#
#     # update filter
#     residual = (z - prediction)
#     gain_rate = gain_rate + (gain_belief * (residual/time_step))
#     estimate = prediction + (weight_belief * residual)
#     estimates.append(estimate)
#
# print(estimates)
# print("----------")
# print(predictions)
# print("----------")
# print(weights)
#
# plt.plot(weights, color='black', label='Measurements')
# plt.plot(predictions, color='red', label='Predictions')
# plt.plot(estimates, color='blue', label='Estimates')
# plt.legend(bbox_to_anchor=(0.0, 1.02, 1.0, 0.102), loc=3, ncol=2, mode='expand', borderaxespad=0.0)
# plt.ylabel('Weights')
# plt.show()

import matplotlib.pyplot as plt
import numpy as np
from numpy.random import randn

def g_h_filter(data, x0, dx, g, h, dt=1.0):
    x_est = x0
    estimates = []
    predictions = []
    for z in data:
        #prediction
        x_pred = x_est + (dx*dt)

        predictions.append(x_pred)

        #update
        residual = z - x_pred
        dx = dx + (h * (residual / dt))
        x_est = x_pred + (g * residual)

        estimates.append(x_est)

    return np.array(estimates), np.array(predictions)

# def gen_data(x0, dx, count, noise_factor, accel=0.):
#     zs = []
#     for i in range(count):
#         zs.append(x0 + dx * i + randn() * noise_factor)
#     dx += accel
#     return zs

def compute_new_position(pos, vel, dt=1.):
    """ dt is the time delta in seconds."""
    return pos + (vel * dt)

def measure_position(pos):
    return pos + randn()*500

def gen_train_data(pos, vel, count):
    zs = []
    for t in range(count):
        pos = compute_new_position(pos, vel)
        zs.append(measure_position(pos))
    return np.asarray(zs)

np.random.seed(100)
# measurements = gen_data(x0=5., dx=5., count=50, noise_factor=50)
# measurements = [158.0, 164.2, 160.3, 159.9, 162.1, 164.6, 169.6, 167.4, 166.4, 171.0, 171.2, 172.6]
# measurements = gen_data(0, 1, 30, 1)
# measurements = gen_data(x0=5., dx=2., count=100, noise_factor=10)
# measurements = gen_data(x0=10., dx=0., count=20, noise_factor=0, accel=2.)

measurements = gen_train_data(pos=23.*1000, vel=15.0, count=100)
estimates, predictions = g_h_filter(data=measurements, x0=23.*1000, dx=15.0, dt=1.0, g=0.01, h=0.1)


plt.plot(measurements, color='black', label='Measurements')
plt.plot(predictions, color='red', label='Predictions')
plt.plot(estimates, color='blue', label='Estimates')
plt.legend(bbox_to_anchor=(0.0, 1.02, 1.0, 0.102), loc=3, ncol=2, mode='expand', borderaxespad=0.0)
plt.ylabel('Weights')
plt.show()

# from filterpy.gh import GHFilter
#
# f = GHFilter(x=0., dx=0., dt=1., g=.8, h=.2)
#
# f.update(z=1.2)
#
# print(f.x, f.dx)