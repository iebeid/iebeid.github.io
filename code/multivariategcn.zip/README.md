# MultiVariateGCN
**Author:** Islam Akef Ebeid

## Overview
MultiVariateGCN (featuring the core **DirectGCN** architecture) is a highly expressive Graph Neural Network framework tailored for complex, directed, and heterophilic graphs. Traditional GCNs often struggle with asymmetric graph structures and rely on forced neighborhood smoothing (low-pass filtering), which destroys node identity in highly heterophilic datasets (like Texas).

DirectGCN solves this by decoupling the message passing operations and processing the graph through 5 specialized structural "paths" (Incoming, Outgoing, Undirected, Homophilic, and Heterophilic). By completely avoiding forced initial smoothing and utilizing advanced structural multi-tasking, DirectGCN achieves state-of-the-art performance on featureless graphs, relying purely on structural topology.

### Key Features (Latest Architecture)
* **Decoupled Path Convolution (`DirectGCNVariable`)**: Removes the forced neighborhood averaging of standard `GCNConv`. It projects the root node's features (`W_root`) completely independently from the neighborhood messages (`W_msg`), preserving isolated structural identity.
* **High-Pass Filter Gating (`Tanh`)**: Dynamically weights the importance of each structural path per node using a learnable gating mechanism (`node_gate_vector`, `vector`, or `scalar`). By using `Tanh` activations, the model can learn **negative weights**, actively subtracting toxic heterophilic noise to act as an adaptive high-pass filter.
* **4-Task Multi-Objective Optimization**: Simultaneously optimizes for:
  1. Node Classification (Cross-Entropy)
  2. Link Existence (BCE)
  3. Link Similarity (BCE)
  4. Edge Directionality (BCE)
* **Gradient Decoupling (H1 vs H2)**: Extracts structural embeddings for link prediction tasks from the intermediate `H1` layer, completely freeing the final `H2` layer for pure semantic node classification without gradient interference.
* **Distance-Aware Link Predictors**: Replaces standard concatenation with a mathematical distance array `[u, v, u*v, |u - v|]`. By explicitly feeding the MLPs the Hadamard product and absolute difference, the model can easily recognize anti-correlated, heterophilic edges.
* **64-Dimensional Lossless Backbone**: Optimized for "featureless" structural learning by maintaining a consistent 64-dim bottleneck from the random noise input to the final decoders.
* **Advanced Subgraphing**: Supports both a custom `StratifiedConnectedSubgraphLoader` (BFS-based) and PyTorch Geometric's native `ClusterLoader` for rapidly training on massive graphs (e.g., `ogbn-arxiv`).

---

## Installation

### 1. Clone the repository
```bash
git clone https://github.com/iebeid/MultiVariateGCN.git
cd MultiVariateGCN
```

### 2. Create the Environment
We recommend using Conda to manage your environment (e.g., `protgram-directgcn-env`).
```bash
conda create -n directgcn-env python=3.10 -y
conda activate directgcn-env
```

### 3. Install Dependencies
You will find the environment.yaml file  in the report. You can just  import it after you create the environment or install PyTorch and PyTorch Geometric according to your system's CUDA version. For example:
```bash
# PyTorch (Example for CUDA 11.8)
conda install pytorch torchvision torchaudio pytorch-cuda=11.8 -c pytorch -c nvidia

# PyTorch Geometric (PyG)
pip install torch_geometric

# Core project dependencies
pip install networkx scipy numpy pandas h5py pyyaml psutil pydantic scikit-learn mlflow
```

---

## Configuration
The project is entirely driven by a declarative YAML configuration file located at `configuration/config.yaml`. 

Here you can easily modify:
- `GNN_MODELS_TO_RUN`: Which models to run (e.g., `['DirectGCN', 'GCN', 'GAT', 'GTN']`)
- `DATASETS`: Which datasets to benchmark on (e.g., `['Cora_Original', 'Texas', 'ogbn-arxiv']`)
- `LOSS_WEIGHT_*`: The ratio of influence for each of the 4 independent tasks (Classification, Existence, Similarity, Directionality).
- `SUBGRAPH_LOADER_TYPE`: Choose between `"bfs"` (custom loader) or `"cluster"` (PyG ClusterLoader) for large graphs.

---

## Usage
Once your environment is set up and your `config.yaml` is configured to your liking, launch the benchmarking pipeline by simply running:

```bash
python main.py
```

### Outputs
Everything is automatically saved to uniquely timestamped run directories in `results/run_YYYYMMDD_HHMMSS/`:
- **Logs & CSVs**: Detailed execution logs, timing metrics, and test accuracies are saved to CSVs for easy benchmarking.
- **MLflow Tracking**: All metrics, hyperparameters, and architecture variants are logged via MLflow.
- **Embeddings**: If `SAVE_EMBEDDINGS` is true, the final node embeddings from the models are processed via PCA and saved as highly-compressed `.h5` files for downstream analysis.

---

## Repository Structure
- `models/gnn/spectral/directgcn.py`: The core DirectGCN multi-path architecture, variables, high-pass gates, and distance-aware MLPs.
- `train/gnns.py`: The primary training loops, 4-task loss functions, and PyG data overrides.
- `utils/graph_utils.py`: The custom `StratifiedConnectedSubgraphLoader` logic.
- `configuration/`: Contains the Pydantic data models (`config.py`) and YAML definitions (`config.yaml`).
