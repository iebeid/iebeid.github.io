# ==============================================================================
# MODULE: configuration/config.py
# PURPOSE: Centralized configuration loaded from a YAML file.
# VERSION: Minimal (Benchmarking Only)
# ==============================================================================

import os
from pathlib import Path
from typing import Optional, Dict, List, Any
import yaml
import sys
from pydantic import BaseModel, Field
import time


class GNNBenchmarkingParams(BaseModel):
    # --- EXPERIMENT SETTINGS ---
    SAVE_EMBEDDINGS: bool = Field(default=False)
    TEST_ON_UNDIRECTED: bool = Field(default=False)
    SPLIT_RATIOS: Dict[str, float] = Field(default_factory=lambda: {'train': 0.2, 'val': 0.2, 'test': 0.6})
    EVAL_FREQUENCY: int = Field(default=10, gt=0)
    
    # --- MODELS & DATASETS ---
    GNN_MODELS_TO_RUN: List[str] = Field(default_factory=list)
    DATASETS: List[str] = Field(default_factory=list)
    
    # --- GNN GENERAL HYPERPARAMETERS ---
    EPOCHS: int = Field(gt=0)
    LEARNING_RATE: float = Field(gt=0.0)
    WEIGHT_DECAY: float = Field(ge=0.0)
    GNN_NUM_LAYERS: int = Field(gt=0)
    GNN_HIDDEN_CHANNELS: int = Field(gt=0)
    GNN_INIT_DIM: Optional[int] = Field(default=None)
    GNN_DROPOUT_RATE: float = Field(ge=0.0, lt=1.0)
    PCA_TARGET_DIM: int = Field(default=16, gt=0)
    GRADIENT_CLIPPING_NORM: float = Field(default=1.0, gt=0.0)

    LOSS_WEIGHT_CLS: float = Field(default=0.25, ge=0.0, le=1.0)
    LOSS_WEIGHT_EXIST: float = Field(default=0.25, ge=0.0, le=1.0)
    LOSS_WEIGHT_SIM: float = Field(default=0.25, ge=0.0, le=1.0)
    LOSS_WEIGHT_DIR: float = Field(default=0.25, ge=0.0, le=1.0)
    LOSS_WEIGHT_CYC: float = Field(default=0.25, ge=0.0, le=1.0)
    FOCAL_LOSS_GAMMA: float = Field(default=2.0)
    FOCAL_LOSS_ALPHA: float = Field(default=1.0)
    NEGATIVE_SAMPLING_RATIO: float = Field(default=1.0, gt=0.0)

    # --- MODEL SPECIFIC ---
    DIRECTGCN_HIDDEN_DIM: int = Field(gt=0)
    DIRECTGCN_NUM_LAYERS_PER_MODULE: int = Field(gt=0)
    DIRECTGCN_NUM_BASES: Optional[int] = Field(default=None)
    DIRECTGCN_NUM_BLOCKS: Optional[int] = Field(default=None)
    DIRECTGCN_DECOMPOSE_PROJECTIONS: bool = Field(default=False)
    DIRECTGCN_PROJ_NUM_BASES: Optional[int] = Field(default=None)
    DIRECTGCN_PROPAGATION_EPSILON: float = Field(gt=0.0)
    DIRECTGCN_GATING_MODE: str = Field(default="vector")
    DIRECTGCN_HOMOPHILY_SAMPLING: str = Field(default="coin_flip")
    DIRGNN_ALPHA: float = Field(default=0.5, ge=0.0, le=1.0)

    GAT_HEADS: int = Field(gt=0)
    GAT_DROPOUT_RATE: float = Field(ge=0.0, lt=1.0)
    CHEBNET_K: int = Field(gt=0)
    RGCN_NUM_RELATIONS: int = Field(gt=0)
    GRAPHSAGE_AGGR: str = Field(default='mean')
    NODE2VEC_P: float = Field(default=1.0, gt=0.0)
    NODE2VEC_Q: float = Field(default=1.0, gt=0.0)
    NODE2VEC_WALK_LENGTH: int = Field(default=2, gt=0)
    NODE2VEC_NUM_NEGATIVES: int = Field(default=5, gt=0)
    METAPATH2VEC_WALK_LENGTH: int = Field(default=2, gt=0)
    METAPATH2VEC_NUM_NEGATIVES: int = Field(default=5, gt=0)
    KGE_NUM_NEGATIVES: int = Field(default=5, gt=0)
    KGE_REG_WEIGHT: float = Field(default=0.01, ge=0.0)
    EVAL_MRR: bool = Field(default=True)
    HITS_AT_K: List[int] = Field(default=[1, 3, 10])
    MRR_NUM_NEGATIVES: int = Field(default=100, gt=0)
    MRR_MAX_EVAL_TRIPLES: int = Field(default=2048, gt=0)

    # --- SUBGRAPH SAMPLING ---
    SUBGRAPH_LOADER_TYPE: str = Field(default="bfs")
    SUBGRAPH_NODES_N: int = Field(default=5000, gt=0)
    SUBGRAPH_BATCHES_M: int = Field(default=20, gt=0)
    SUBGRAPH_BFS_ROOT_RATIO: float = Field(default=0.10, gt=0.0, lt=1.0)


class ValidationSchema(BaseModel):
    """The root model for validating the config."""
    RANDOM_STATE: int = 42
    DEBUG_VERBOSE: bool = True
    DIRECTGCN_PROPAGATION_EPSILON: float = Field(default=1e-9, gt=0)
    gnn_benchmarking: GNNBenchmarkingParams


class Config:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(Config, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self, config_path: str = 'configuration/config.yaml'):
        if hasattr(self, '_initialized') and self._initialized:
            return

        # Load and validate
        full_path = Path.cwd() / config_path
        if not full_path.exists():
            full_path = Path(__file__).parent.parent / config_path
            if not full_path.exists():
                raise FileNotFoundError(f"Configuration file not found at: {full_path}")

        with open(full_path, 'r') as f:
            raw_config = yaml.safe_load(f)

        # Pydantic validation
        validated_config = ValidationSchema(**raw_config).dict()

        self.RANDOM_STATE = validated_config['RANDOM_STATE']
        self.DEBUG_VERBOSE = validated_config['DEBUG_VERBOSE']
        self.DIRECTGCN_PROPAGATION_EPSILON = validated_config['DIRECTGCN_PROPAGATION_EPSILON']

        # Parse benchmarking config
        bench = validated_config['gnn_benchmarking']
        self.BENCHMARK_NODE_CLASSIFICATION_DATASETS = bench['DATASETS']
        self.BENCHMARK_GNN_MODELS_TO_RUN = bench['GNN_MODELS_TO_RUN']
        self.BENCHMARK_SAVE_EMBEDDINGS = bench['SAVE_EMBEDDINGS']
        self.BENCHMARK_TEST_ON_UNDIRECTED = bench['TEST_ON_UNDIRECTED']
        self.BENCHMARK_SPLIT_RATIOS = bench['SPLIT_RATIOS']
        self.BENCHMARK_PCA_TARGET_DIM = bench['PCA_TARGET_DIM']
        self.BENCHMARK_GNN_INIT_DIM = bench['GNN_INIT_DIM']
        self.BENCHMARK_GNN_EPOCHS = bench['EPOCHS']
        self.BENCHMARK_GNN_LEARNING_RATE = bench['LEARNING_RATE']
        self.BENCHMARK_GNN_WEIGHT_DECAY = bench['WEIGHT_DECAY']
        self.BENCHMARK_GNN_HIDDEN_CHANNELS = bench['GNN_HIDDEN_CHANNELS']
        self.BENCHMARK_GNN_NUM_LAYERS = bench['GNN_NUM_LAYERS']
        self.BENCHMARK_GNN_DROPOUT_RATE = bench['GNN_DROPOUT_RATE']
        self.BENCHMARK_GAT_HEADS = bench['GAT_HEADS']
        
        self.LOSS_WEIGHT_CLS = bench.get('LOSS_WEIGHT_CLS', 0.85)
        self.LOSS_WEIGHT_EXIST = bench.get('LOSS_WEIGHT_EXIST', 0.05)
        self.LOSS_WEIGHT_SIM = bench.get('LOSS_WEIGHT_SIM', 0.05)
        self.LOSS_WEIGHT_DIR = bench.get('LOSS_WEIGHT_DIR', 0.05)
        self.LOSS_WEIGHT_CYC = bench.get('LOSS_WEIGHT_CYC', 0.05)
        self.FOCAL_LOSS_GAMMA = bench.get('FOCAL_LOSS_GAMMA', 2.0)
        self.FOCAL_LOSS_ALPHA = bench.get('FOCAL_LOSS_ALPHA', 1.0)
        self.BENCHMARK_GAT_DROPOUT_RATE = bench['GAT_DROPOUT_RATE']
        self.BENCHMARK_CHEBNET_K = bench['CHEBNET_K']
        self.BENCHMARK_RGCN_NUM_RELATIONS = bench['RGCN_NUM_RELATIONS']
        self.BENCHMARK_GRAPHSAGE_AGGR = bench.get('GRAPHSAGE_AGGR', 'mean')
        self.BENCHMARK_NODE2VEC_P = bench.get('NODE2VEC_P', 1.0)
        self.BENCHMARK_NODE2VEC_Q = bench.get('NODE2VEC_Q', 1.0)
        self.BENCHMARK_NODE2VEC_WALK_LENGTH = bench.get('NODE2VEC_WALK_LENGTH', 2)
        self.BENCHMARK_NODE2VEC_NUM_NEGATIVES = bench.get('NODE2VEC_NUM_NEGATIVES', 5)
        self.BENCHMARK_METAPATH2VEC_WALK_LENGTH = bench.get('METAPATH2VEC_WALK_LENGTH', 2)
        self.BENCHMARK_METAPATH2VEC_NUM_NEGATIVES = bench.get('METAPATH2VEC_NUM_NEGATIVES', 5)
        self.BENCHMARK_KGE_NUM_NEGATIVES = bench.get('KGE_NUM_NEGATIVES', 5)
        self.BENCHMARK_KGE_REG_WEIGHT = bench.get('KGE_REG_WEIGHT', 0.01)
        self.BENCHMARK_EVAL_MRR = bench.get('EVAL_MRR', True)
        self.BENCHMARK_HITS_AT_K = bench.get('HITS_AT_K', [1, 3, 10])
        self.BENCHMARK_MRR_NUM_NEGATIVES = bench.get('MRR_NUM_NEGATIVES', 100)
        self.BENCHMARK_MRR_MAX_EVAL_TRIPLES = bench.get('MRR_MAX_EVAL_TRIPLES', 2048)
        self.BENCHMARK_DIRECTGCN_HIDDEN_DIM = bench['DIRECTGCN_HIDDEN_DIM']
        self.BENCHMARK_DIRECTGCN_NUM_BASES = bench['DIRECTGCN_NUM_BASES']
        self.BENCHMARK_DIRECTGCN_NUM_BLOCKS = bench['DIRECTGCN_NUM_BLOCKS']
        self.BENCHMARK_DIRECTGCN_DECOMPOSE_PROJECTIONS = bench['DIRECTGCN_DECOMPOSE_PROJECTIONS']
        self.BENCHMARK_DIRECTGCN_PROJ_NUM_BASES = bench['DIRECTGCN_PROJ_NUM_BASES']
        self.BENCHMARK_DIRECTGCN_NUM_LAYERS_PER_MODULE = bench['DIRECTGCN_NUM_LAYERS_PER_MODULE']
        self.BENCHMARK_DIRECTGCN_GATING_MODE = bench.get('DIRECTGCN_GATING_MODE', 'vector')
        self.BENCHMARK_DIRECTGCN_HOMOPHILY_SAMPLING = bench.get('DIRECTGCN_HOMOPHILY_SAMPLING', 'coin_flip')
        self.BENCHMARK_DIRGNN_ALPHA = bench.get('DIRGNN_ALPHA', 0.5)
        self.BENCHMARK_EVAL_FREQUENCY = bench.get('EVAL_FREQUENCY', 10)
        self.BENCHMARK_GRADIENT_CLIPPING_NORM = bench.get('GRADIENT_CLIPPING_NORM', 1.0)
        self.BENCHMARK_NEGATIVE_SAMPLING_RATIO = bench.get('NEGATIVE_SAMPLING_RATIO', 1.0)
        self.BENCHMARK_SUBGRAPH_NODES_N = bench['SUBGRAPH_NODES_N']
        self.BENCHMARK_SUBGRAPH_BATCHES_M = bench['SUBGRAPH_BATCHES_M']
        self.BENCHMARK_SUBGRAPH_BFS_ROOT_RATIO = bench.get('SUBGRAPH_BFS_ROOT_RATIO', 0.10)
        self.BENCHMARK_SUBGRAPH_LOADER_TYPE = bench.get('SUBGRAPH_LOADER_TYPE', 'bfs')

        # Setup basic paths needed by the benchmarking pipeline
        self.PROJECT_ROOT = Path(__file__).parent.parent.resolve()
        run_id = f"run_{time.strftime('%Y%m%d_%H%M%S')}"
        self.BASE_OUTPUT_DIR = self.PROJECT_ROOT / "results" / run_id

        self.BASE_DATA_DIR = self.PROJECT_ROOT / "data"
        self.DATA_STANDARD_DATASETS_DIR = self.BASE_DATA_DIR / "benchmarks"

        self.PERSISTENT_DATA_CACHE = Path.home() / ".cache" / "protgram_directgcn"
        self.RESULTS_BENCHMARKING_DIR = self.BASE_OUTPUT_DIR / "benchmarking_results"
        self.RESULTS_BENCHMARK_EMBEDDINGS_DIR = self.RESULTS_BENCHMARKING_DIR / "embeddings"

        self._initialized = True
