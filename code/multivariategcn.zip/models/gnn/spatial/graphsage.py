# ==============================================================================
# MODULE: models/gnn/spatial/graphsage.py
# PURPOSE: Standard implementation of Inductive Representation Learning on
#          Large Graphs (GraphSAGE, Hamilton et al., NeurIPS 2017).
# VERSION: 1.0
# AUTHOR: Islam Ebeid
# ==============================================================================
from typing import Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.data import Data
from torch_geometric.nn import SAGEConv


class GraphSAGE(nn.Module):
    """
    Standard implementation of GraphSAGE (Hamilton et al., 2017).
    Aggregates local neighborhood features via SAGEConv layers (default: mean
    aggregator) with residual connections on the first hidden layer.
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int = 2,
        dropout_rate: float = 0.5,
        aggr: str = "mean",
        normalize: bool = True,
        root_weight: bool = True,
        **kwargs,
    ):
        super().__init__()
        self.convs = nn.ModuleList()
        self.dropout_rate = dropout_rate
        self.embedding_output = None

        if num_layers <= 0:
            raise ValueError("num_layers must be positive")

        sage_kwargs = {
            "aggr": aggr,
            "normalize": normalize,
            "root_weight": root_weight,
        }

        if num_layers == 1:
            self.convs.append(SAGEConv(in_channels, out_channels, **sage_kwargs))
            self.res_proj = nn.Identity()
        else:
            self.convs.append(SAGEConv(in_channels, hidden_channels, **sage_kwargs))
            if in_channels != hidden_channels:
                self.res_proj = nn.Linear(in_channels, hidden_channels)
            else:
                self.res_proj = nn.Identity()
            for _ in range(num_layers - 2):
                self.convs.append(SAGEConv(hidden_channels, hidden_channels, **sage_kwargs))
            self.convs.append(SAGEConv(hidden_channels, out_channels, **sage_kwargs))

    def forward(self, data: Data) -> Tuple[torch.Tensor, torch.Tensor]:
        x, edge_index = data.x, data.edge_index

        if len(self.convs) == 1:
            logits = self.convs[0](x, edge_index)
            self.embedding_output = logits
            return logits, self.embedding_output

        x_res = self.res_proj(x)

        for i, conv in enumerate(self.convs[:-1]):
            x = conv(x, edge_index)
            if i == 0:
                x = x + x_res
            x = F.relu(x)
            x = F.dropout(x, p=self.dropout_rate, training=self.training)

        self.embedding_output = x
        logits = self.convs[-1](self.embedding_output, edge_index)

        return logits, self.embedding_output
