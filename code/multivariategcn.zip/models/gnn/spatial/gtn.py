# ==============================================================================
# MODULE: models/gnn/spatial/gtn.py
# PURPOSE: Implements the Graph Transformer Networks (GTN) model.
# AUTHOR: Islam Ebeid (Refactored by Gemini Code Assist)
# ==============================================================================

from typing import Tuple, List

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.data import Data
from torch_geometric.nn import GCNConv
from torch_sparse import spspmm, coalesce


class GTLayer(nn.Module):
    """
    Graph Transformer Layer that computes a soft combination of adjacency matrices.
    """

    def __init__(self, num_edge_types: int, num_channels: int):
        super().__init__()
        self.weight = nn.Parameter(torch.Tensor(num_channels, num_edge_types))
        nn.init.normal_(self.weight)

    def forward(self, A_list: List[Tuple[torch.Tensor, torch.Tensor]], num_nodes: int):
        w = F.softmax(self.weight, dim=1)  # (C, K)

        out_A = []
        for c in range(self.weight.size(0)):
            c_indices = []
            c_values = []
            for k in range(len(A_list)):
                idx, val = A_list[k]
                c_indices.append(idx)
                c_values.append(val * w[c, k])

            cat_idx = torch.cat(c_indices, dim=1)
            cat_val = torch.cat(c_values, dim=0)

            cat_idx, cat_val = coalesce(cat_idx, cat_val, num_nodes, num_nodes)
            out_A.append((cat_idx, cat_val))

        return out_A


class GTN(nn.Module):
    """
    Graph Transformer Networks (GTN) by Yun et al. (2019).
    This implementation handles multiple edge types (or a single edge type) by generating
    meta-paths via soft selection and sparse matrix multiplication.
    """

    def __init__(self, in_channels: int, hidden_channels: int, out_channels: int,
                 num_layers: int = 2, dropout_rate: float = 0.5, **kwargs):
        super().__init__()
        self.num_layers = max(1, num_layers)
        self.num_edge_types = kwargs.get('num_relations', 1) + 1  # +1 for identity
        self.channels = kwargs.get('gtn_channels', 2)
        self.dropout_rate = dropout_rate
        self.embedding_output = None

        self.gt_layers = nn.ModuleList([
            GTLayer(self.num_edge_types, self.channels) for _ in range(self.num_layers)
        ])

        self.gcn_conv = GCNConv(in_channels, hidden_channels)
        self.out_linear = nn.Linear(hidden_channels * self.channels, out_channels)

    def forward(self, data: Data) -> Tuple[torch.Tensor, torch.Tensor]:
        x, edge_index = data.x, data.edge_index
        edge_type = getattr(data, 'edge_type', None)
        num_nodes = x.size(0)

        if edge_type is None:
            edge_type = torch.zeros(edge_index.size(1), dtype=torch.long, device=x.device)

        # 1. Prepare adjacency matrices A_list
        A_list = []
        # Identity matrix for self-loops (A_0)
        id_idx = torch.arange(num_nodes, device=x.device).unsqueeze(0).repeat(2, 1)
        id_val = torch.ones(num_nodes, device=x.device)
        A_list.append((id_idx, id_val))

        # Edge type matrices (A_1 ... A_K)
        for k in range(self.num_edge_types - 1):
            mask = edge_type == k
            idx = edge_index[:, mask]
            val = torch.ones(idx.size(1), device=x.device)
            A_list.append((idx, val))

        # 2. Pass through GT layers to generate meta-paths
        A_l = self.gt_layers[0](A_list, num_nodes)

        for l in range(1, self.num_layers):
            Q_l = self.gt_layers[l](A_list, num_nodes)
            new_A_l = []
            for c in range(self.channels):
                idx1, val1 = A_l[c]
                idx2, val2 = Q_l[c]

                # Multiply sparse matrices: A^{(l)} = A^{(l-1)} * Q^{(l)}
                idx_res, val_res = spspmm(idx1, val1, idx2, val2, num_nodes, num_nodes, num_nodes)
                new_A_l.append((idx_res, val_res))
            A_l = new_A_l

        # 3. Apply standard GCN convolution over the new meta-path structures
        h_list = []
        for c in range(self.channels):
            idx, val = A_l[c]
            h = self.gcn_conv(x, idx, edge_weight=val)
            h_list.append(h)

        # Combine channels
        h_cat = torch.cat(h_list, dim=1)
        h_cat = F.relu(h_cat)
        h_cat = F.dropout(h_cat, p=self.dropout_rate, training=self.training)

        self.embedding_output = h_cat
        logits = self.out_linear(self.embedding_output)

        return logits, self.embedding_output
