# ==============================================================================
# MODULE: models/gnn/spatial/metapath2vec.py
# PURPOSE: Relational / Heterogeneous MetaPath2Vec representation learning model
#          (Dong et al., KDD 2017) integrated with the unified benchmark pipeline.
# VERSION: 1.0
# AUTHOR: Islam Ebeid
# ==============================================================================
from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.data import Data
from torch_geometric.utils import negative_sampling


class MetaPath2Vec(nn.Module):
    """
    MetaPath2Vec model (Dong et al., KDD 2017) adapted for relational and
    directed heterogeneous graphs.

    When `data.edge_type` is available (e.g., Knowledge Graphs such as FB15k,
    WN18, or RGCN-prepared graphs), MetaPath2Vec constructs relation-specific
    metapath context transitions (u -r1-> v -r2-> w). When `edge_type` is not
    explicitly present, it decomposes directed edges into forward (r=0) and
    reverse (r=1) relation types to form directed metapaths (e.g., out-in and
    in-out motifs).
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_graph_nodes: int = 0,
        num_relations: int = 2,
        dropout_rate: float = 0.5,
        walk_length: int = 2,
        num_negatives: int = 5,
        **kwargs,
    ):
        super().__init__()
        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.num_graph_nodes = max(1, int(num_graph_nodes))
        self.num_relations = max(2, int(num_relations))
        self.dropout_rate = dropout_rate
        self.walk_length = max(1, int(walk_length))
        self.num_negatives = max(1, int(num_negatives))
        self.embedding_output = None

        # Heterogeneous / relational node & context embeddings
        self.node_emb = nn.Embedding(self.num_graph_nodes, hidden_channels)
        self.context_emb = nn.Embedding(self.num_graph_nodes, hidden_channels)
        self.rel_emb = nn.Embedding(self.num_relations, hidden_channels)

        self.feat_proj = nn.Linear(in_channels, hidden_channels)
        self.norm = nn.LayerNorm(hidden_channels)
        self.classifier = nn.Linear(hidden_channels, out_channels)

        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.node_emb.weight)
        nn.init.xavier_uniform_(self.context_emb.weight)
        nn.init.xavier_uniform_(self.rel_emb.weight)
        self.feat_proj.reset_parameters()
        self.norm.reset_parameters()
        self.classifier.reset_parameters()

    def _ensure_capacity(self, num_nodes: int, num_rels: int, device: torch.device):
        if num_nodes > self.node_emb.num_embeddings:
            old_node = self.node_emb.weight.data
            old_ctx = self.context_emb.weight.data
            self.node_emb = nn.Embedding(num_nodes, self.hidden_channels, device=device)
            self.context_emb = nn.Embedding(num_nodes, self.hidden_channels, device=device)
            nn.init.xavier_uniform_(self.node_emb.weight)
            nn.init.xavier_uniform_(self.context_emb.weight)
            with torch.no_grad():
                self.node_emb.weight[: old_node.size(0)] = old_node.to(device)
                self.context_emb.weight[: old_ctx.size(0)] = old_ctx.to(device)
            self.num_graph_nodes = num_nodes

        if num_rels > self.rel_emb.num_embeddings:
            old_rel = self.rel_emb.weight.data
            self.rel_emb = nn.Embedding(num_rels, self.hidden_channels, device=device)
            nn.init.xavier_uniform_(self.rel_emb.weight)
            with torch.no_grad():
                self.rel_emb.weight[: old_rel.size(0)] = old_rel.to(device)
            self.num_relations = num_rels

    def _get_relational_edges(self, data: Data) -> Tuple[torch.Tensor, torch.Tensor]:
        edge_index = data.edge_index
        edge_type = getattr(data, "edge_type", None)
        if edge_type is not None and edge_type.numel() == edge_index.size(1):
            return edge_index, edge_type
        # Construct forward (r=0) and backward (r=1) directed relation types
        num_e = edge_index.size(1)
        fwd_type = torch.zeros(num_e, dtype=torch.long, device=edge_index.device)
        bwd_type = torch.ones(num_e, dtype=torch.long, device=edge_index.device)
        rel_edge_index = torch.cat([edge_index, edge_index.flip(0)], dim=1)
        rel_edge_type = torch.cat([fwd_type, bwd_type], dim=0)
        return rel_edge_index, rel_edge_type

    def compute_unsup_loss(self, h: torch.Tensor, data: Data) -> torch.Tensor:
        """
        Computes the MetaPath2Vec heterogeneous skip-gram objective over
        relation-typed metapath steps.
        """
        rel_edge_index, rel_edge_type = self._get_relational_edges(data)
        num_nodes = h.size(0)
        if rel_edge_index.numel() == 0:
            return torch.tensor(0.0, device=h.device)

        max_rels = int(rel_edge_type.max().item()) + 1
        node_ids = getattr(data, "original_indices", getattr(data, "n_id", getattr(data, "node_id", None)))
        if node_ids is None:
            self._ensure_capacity(num_nodes, max_rels, h.device)
            node_ids = torch.arange(num_nodes, device=h.device)
        else:
            node_ids = node_ids.to(h.device)
            self._ensure_capacity(int(node_ids.max().item()) + 1, max_rels, h.device)

        max_pairs = 16384
        num_edges = rel_edge_index.size(1)
        if num_edges > max_pairs:
            perm = torch.randint(0, num_edges, (max_pairs,), device=rel_edge_index.device)
            pos_edges = rel_edge_index[:, perm]
            pos_types = rel_edge_type[perm]
        else:
            pos_edges = rel_edge_index
            pos_types = rel_edge_type

        src, dst = pos_edges[0], pos_edges[1]
        ctx_vectors = self.context_emb(node_ids)
        r_vec = self.rel_emb(pos_types)

        # Relation-conditioned metapath context score: <h_u * r_rel, c_v>
        pos_score = (h[src] * r_vec * ctx_vectors[dst]).sum(dim=-1)
        pos_loss = -F.logsigmoid(pos_score).mean()

        # 2-hop metapath composition (r1 o r2)
        if self.walk_length >= 2 and pos_edges.size(1) > 1:
            idx2 = torch.randint(0, pos_edges.size(1), (pos_edges.size(1),), device=rel_edge_index.device)
            hop2_dst = pos_edges[1, idx2]
            r_vec_2 = 0.5 * (r_vec + self.rel_emb(pos_types[idx2]))
            pos_score_2 = (h[src] * r_vec_2 * ctx_vectors[hop2_dst]).sum(dim=-1)
            pos_loss = 0.65 * pos_loss + 0.35 * (-F.logsigmoid(pos_score_2).mean())

        # Type-conditioned negative sampling
        num_neg = min(pos_edges.size(1) * self.num_negatives, max_pairs * 2)
        neg_edges = negative_sampling(
            edge_index=data.edge_index,
            num_nodes=num_nodes,
            num_neg_samples=num_neg,
        )
        if neg_edges.numel() > 0:
            neg_src, neg_dst = neg_edges[0], neg_edges[1]
            neg_rel_ids = pos_types[torch.randint(0, pos_types.size(0), (neg_src.size(0),), device=h.device)]
            neg_r_vec = self.rel_emb(neg_rel_ids)
            neg_score = (h[neg_src] * neg_r_vec * ctx_vectors[neg_dst]).sum(dim=-1)
            neg_loss = -F.logsigmoid(-neg_score).mean()
        else:
            neg_loss = torch.tensor(0.0, device=h.device)

        return pos_loss + neg_loss

    def score_triples(
        self,
        h: torch.Tensor,
        edge_index: torch.Tensor,
        edge_type: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        src, dst = edge_index[0], edge_index[1]
        h_norm = F.normalize(h, p=2, dim=-1)
        if edge_type is not None and edge_type.numel() == edge_index.size(1):
            clamped_type = edge_type.clamp(0, self.rel_emb.num_embeddings - 1)
            r_vec = F.normalize(self.rel_emb(clamped_type), p=2, dim=-1)
            return (h_norm[src] * r_vec * h_norm[dst]).sum(dim=-1)
        return (h_norm[src] * h_norm[dst]).sum(dim=-1)

    def predict_exist(
        self,
        h: torch.Tensor,
        edge_index: torch.Tensor,
        edge_type: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        return self.score_triples(h, edge_index, edge_type)

    def forward(self, data: Data) -> Tuple[torch.Tensor, torch.Tensor]:
        x = data.x
        num_nodes = x.size(0)
        edge_type = getattr(data, "edge_type", None)
        max_rels = int(edge_type.max().item()) + 1 if (edge_type is not None and edge_type.numel() > 0) else self.num_relations
        node_ids = getattr(data, "original_indices", getattr(data, "n_id", getattr(data, "node_id", None)))
        if node_ids is None:
            self._ensure_capacity(num_nodes, max_rels, x.device)
            node_ids = torch.arange(num_nodes, device=x.device)
        else:
            node_ids = node_ids.to(x.device)
            self._ensure_capacity(int(node_ids.max().item()) + 1, max_rels, x.device)
        z_struct = self.node_emb(node_ids)
        z_feat = self.feat_proj(x)

        h = self.norm(z_struct + z_feat)
        h = F.dropout(h, p=self.dropout_rate, training=self.training)

        self.embedding_output = h
        logits = self.classifier(self.embedding_output)
        return logits, self.embedding_output
