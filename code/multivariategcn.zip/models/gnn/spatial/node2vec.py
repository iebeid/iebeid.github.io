# ==============================================================================
# MODULE: models/gnn/spatial/node2vec.py
# PURPOSE: Differentiable Node2Vec representation learning model (Grover &
#          Leskovec, KDD 2016) integrated with the unified GNN benchmark pipeline.
# VERSION: 1.0
# AUTHOR: Islam Ebeid
# ==============================================================================
from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.data import Data
from torch_geometric.utils import negative_sampling


class Node2Vec(nn.Module):
    """
    Node2Vec model (Grover & Leskovec, 2016) adapted for end-to-end benchmarking
    on both node classification and link prediction / ranking tasks.

    Maintains learnable structural node embeddings combined with projected node
    features (when available), optimizes a biased second-order random-walk
    skip-gram objective with negative sampling (`p` return parameter and `q`
    in-out parameter), and provides a linear classification head returning
    `(logits, embeddings)`.
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_graph_nodes: int = 0,
        dropout_rate: float = 0.5,
        p: float = 1.0,
        q: float = 1.0,
        walk_length: int = 2,
        num_negatives: int = 5,
        **kwargs,
    ):
        super().__init__()
        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.num_graph_nodes = max(1, int(num_graph_nodes))
        self.dropout_rate = dropout_rate
        self.p = float(p)
        self.q = float(q)
        self.walk_length = max(1, int(walk_length))
        self.num_negatives = max(1, int(num_negatives))
        self.embedding_output = None

        # Structural node embedding table (transductive Node2Vec lookup)
        self.node_emb = nn.Embedding(self.num_graph_nodes, hidden_channels)
        # Context embedding table for skip-gram objective
        self.context_emb = nn.Embedding(self.num_graph_nodes, hidden_channels)
        # Feature projection for hybrid / featureless random-init compatibility
        self.feat_proj = nn.Linear(in_channels, hidden_channels)
        self.norm = nn.LayerNorm(hidden_channels)
        self.classifier = nn.Linear(hidden_channels, out_channels)

        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.node_emb.weight)
        nn.init.xavier_uniform_(self.context_emb.weight)
        self.feat_proj.reset_parameters()
        self.norm.reset_parameters()
        self.classifier.reset_parameters()

    def _ensure_node_capacity(self, num_nodes: int, device: torch.device):
        if num_nodes > self.node_emb.num_embeddings:
            old_node = self.node_emb.weight.data
            old_ctx = self.context_emb.weight.data
            self.node_emb = nn.Embedding(num_nodes, self.hidden_channels, device=device)
            self.context_emb = nn.Embedding(num_nodes, self.hidden_channels, device=device)
            nn.init.xavier_uniform_(self.node_emb.weight)
            nn.init.xavier_uniform_(self.context_emb.weight)
            with torch.no_grad():
                self.node_emb.weight[: old_node.size(0)] = old_node.to(device)
                self.context_emb.weight[: old_ctx.size(0)] = old_ctx.to(device)
            self.num_graph_nodes = num_nodes

    def compute_unsup_loss(self, h: torch.Tensor, data: Data) -> torch.Tensor:
        """
        Computes the Node2Vec biased random-walk skip-gram negative sampling loss.
        Uses 1-hop edges (weighted by 1/p vs 1/q transition bias) and 2-hop sampled
        walk pairs to approximate second-order random walks efficiently on GPU.
        """
        edge_index = data.edge_index
        num_nodes = h.size(0)
        if edge_index.numel() == 0:
            return torch.tensor(0.0, device=h.device)

        max_pairs = 16384
        num_edges = edge_index.size(1)
        if num_edges > max_pairs:
            perm = torch.randint(0, num_edges, (max_pairs,), device=edge_index.device)
            pos_edges = edge_index[:, perm]
        else:
            pos_edges = edge_index

        src, dst = pos_edges[0], pos_edges[1]
        node_ids = getattr(data, "original_indices", getattr(data, "n_id", getattr(data, "node_id", None)))
        if node_ids is None:
            node_ids = torch.arange(num_nodes, device=h.device)
        else:
            node_ids = node_ids.to(h.device)
        ctx_vectors = self.context_emb(node_ids)

        # 1-hop positive skip-gram scores
        pos_score_1 = (h[src] * ctx_vectors[dst]).sum(dim=-1)
        pos_loss_1 = -F.logsigmoid(pos_score_1).mean()

        # 2-hop biased walk approximation controlled by p (return) and q (in-out)
        if self.walk_length >= 2 and pos_edges.size(1) > 1:
            # Sample a second hop by matching intermediate nodes or random walk step
            idx2 = torch.randint(0, pos_edges.size(1), (pos_edges.size(1),), device=edge_index.device)
            hop2_dst = pos_edges[1, idx2]
            is_return = (src == hop2_dst).float()
            bias_weight = is_return * (1.0 / max(self.p, 1e-3)) + (1.0 - is_return) * (1.0 / max(self.q, 1e-3))
            bias_weight = bias_weight / (bias_weight.mean() + 1e-8)
            pos_score_2 = (h[src] * ctx_vectors[hop2_dst]).sum(dim=-1)
            pos_loss_2 = -(bias_weight.detach() * F.logsigmoid(pos_score_2)).mean()
            pos_loss = 0.7 * pos_loss_1 + 0.3 * pos_loss_2
        else:
            pos_loss = pos_loss_1

        # Negative sampling
        num_neg = min(pos_edges.size(1) * self.num_negatives, max_pairs * 2)
        neg_edges = negative_sampling(
            edge_index=edge_index,
            num_nodes=num_nodes,
            num_neg_samples=num_neg,
        )
        if neg_edges.numel() > 0:
            neg_src, neg_dst = neg_edges[0], neg_edges[1]
            neg_score = (h[neg_src] * ctx_vectors[neg_dst]).sum(dim=-1)
            neg_loss = -F.logsigmoid(-neg_score).mean()
        else:
            neg_loss = torch.tensor(0.0, device=h.device)

        return pos_loss + neg_loss

    def predict_exist(self, h: torch.Tensor, edge_index: torch.Tensor, edge_type: Optional[torch.Tensor] = None) -> torch.Tensor:
        src, dst = edge_index[0], edge_index[1]
        h_norm = F.normalize(h, p=2, dim=-1)
        return (h_norm[src] * h_norm[dst]).sum(dim=-1)

    def forward(self, data: Data) -> Tuple[torch.Tensor, torch.Tensor]:
        x = data.x
        num_nodes = x.size(0)
        node_ids = getattr(data, "original_indices", getattr(data, "n_id", getattr(data, "node_id", None)))
        if node_ids is None:
            self._ensure_node_capacity(num_nodes, x.device)
            node_ids = torch.arange(num_nodes, device=x.device)
        else:
            node_ids = node_ids.to(x.device)
            self._ensure_node_capacity(int(node_ids.max().item()) + 1, x.device)
        z_struct = self.node_emb(node_ids)
        z_feat = self.feat_proj(x)

        h = self.norm(z_struct + z_feat)
        h = F.dropout(h, p=self.dropout_rate, training=self.training)

        self.embedding_output = h
        logits = self.classifier(self.embedding_output)
        return logits, self.embedding_output
