# ==============================================================================
# MODULE: models/gnn/chebnet.py
# PURPOSE: A standard implementation of the Chebyshev Spectral CNN (ChebNet).
# VERSION: 4.0 (Refactored to be a standalone nn.Module for architectural correctness)
# AUTHOR: Islam Ebeid
# ==============================================================================
from typing import Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.data import Data
from torch_geometric.nn import ChebConv


class ChebNet(nn.Module):
    """
    A standard implementation of the Chebyshev Spectral CNN (ChebNet) model.
    This architecture uses Chebyshev polynomials to define convolutions in the
    Fourier domain.
    """

    def __init__(self, in_channels: int, hidden_channels: int, out_channels: int,
                 K: int = 1, num_layers: int = 2, dropout_rate: float = 0.5, **kwargs):
        super().__init__()
        self.convs = nn.ModuleList()
        self.dropout_rate = dropout_rate
        self.embedding_output = None

        if num_layers <= 0:
            raise ValueError("num_layers must be positive")

        if num_layers == 1:
            self.convs.append(ChebConv(in_channels, out_channels, K=K, **kwargs))
            self.res_proj = nn.Identity()
        else:
            self.convs.append(ChebConv(in_channels, hidden_channels, K=K, **kwargs))
            
            # Residual connection projection: matches the output of the first layer
            if in_channels != hidden_channels:
                self.res_proj = nn.Linear(in_channels, hidden_channels)
            else:
                self.res_proj = nn.Identity()

            for _ in range(num_layers - 2):
                self.convs.append(ChebConv(hidden_channels, hidden_channels, K=K, **kwargs))
            self.convs.append(ChebConv(hidden_channels, out_channels, K=K, **kwargs))

    def forward(self, data: Data) -> Tuple[torch.Tensor, torch.Tensor]:
        x, edge_index, edge_weight = data.x, data.edge_index, getattr(data, 'edge_attr', None)
        
        # Hardcode lambda_max=2.0 to skip the extremely slow dynamic eigendecomposition during every subgraph batch
        lm = 2.0 
        
        if len(self.convs) == 1:
            logits = self.convs[0](x, edge_index, edge_weight, lambda_max=lm)
            self.embedding_output = logits
            return logits, self.embedding_output

        # Store original x for residual connection
        x_res = self.res_proj(x)

        for i, conv in enumerate(self.convs[:-1]):
            x = conv(x, edge_index, edge_weight, lambda_max=lm)
            if i == 0:  # Add residual after first layer
                x = x + x_res
            x = F.relu(x)
            x = F.dropout(x, p=self.dropout_rate, training=self.training)
            
        self.embedding_output = x
        logits = self.convs[-1](self.embedding_output, edge_index, edge_weight, lambda_max=lm)
        return logits, self.embedding_output
