# ==============================================================================
# MODULE: models/gnn/spectral/directgcn.py
# PURPOSE: Contains the PyTorch class definitions for the custom GCN model.
# ==============================================================================

from typing import Optional, List, Tuple, Dict, Union

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.data import Data
from torch_geometric.nn import MessagePassing, GCNConv

from utils.math_utils import MathUtils


class DecomposedLinear(nn.Module):
    """
    A linear layer that supports optional basis-decomposition or block-diagonal-decomposition
    of its weight matrix to reduce overfitting and parameter count.
    """

    def __init__(self, in_features: int, out_features: int,
                 bias: bool = False,
                 num_bases: Optional[int] = None,
                 num_blocks: Optional[int] = None):
        super().__init__()
        if num_bases is not None and num_blocks is not None:
            raise ValueError("Cannot use both basis and block decomposition at the same time.")
        self.in_features = in_features
        self.out_features = out_features
        self.num_bases = num_bases
        self.num_blocks = num_blocks

        if self.num_bases is not None:
            self.bases = nn.Parameter(torch.empty(self.num_bases, in_features, out_features))
            self.comp = nn.Parameter(torch.empty(self.num_bases))
            self.register_parameter('weight', None)
        elif self.num_blocks is not None:
            if in_features % num_blocks != 0 or out_features % num_blocks != 0:
                raise ValueError("in_features and out_features must be divisible by num_blocks.")
            self.block_in = in_features // num_blocks
            self.block_out = out_features // num_blocks
            self.weight_blocks = nn.Parameter(torch.empty(num_blocks, self.block_in, self.block_out))
            self.register_parameter('weight', None)
        else:
            self.weight = nn.Parameter(torch.empty(in_features, out_features))

        if bias:
            self.bias = nn.Parameter(torch.zeros(out_features))
        else:
            self.register_parameter('bias', None)

        self.reset_parameters()

    def reset_parameters(self):
        if self.num_bases is not None:
            nn.init.xavier_uniform_(self.bases)
            nn.init.xavier_uniform_(self.comp.unsqueeze(0))
        elif self.num_blocks is not None:
            nn.init.xavier_uniform_(self.weight_blocks)
        else:
            nn.init.xavier_uniform_(self.weight)
        if self.bias is not None:
            nn.init.zeros_(self.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.num_bases is not None:
            W = (self.comp @ self.bases.view(self.num_bases, -1)).view(self.in_features, self.out_features)
            out = x @ W
        elif self.num_blocks is not None:
            B = self.weight_blocks.size(0)
            x_blocks = x.reshape(x.size(0), B, self.block_in)
            out_blocks = torch.einsum('nbi,bio->nbo', x_blocks, self.weight_blocks)
            out = out_blocks.reshape(x.size(0), B * self.block_out)
        else:
            out = x @ self.weight
        if self.bias is not None:
            out = out + self.bias
        return out


class DirectGCNVariable(MessagePassing):
    """
    Represents a single dynamic path/view in the graph.
    """
    def __init__(self, in_channels: int, out_channels: int,
                 num_bases: Optional[int] = None,
                 num_blocks: Optional[int] = None,
                 decompose_projections: bool = False,
                 proj_num_bases: Optional[int] = None):
        super().__init__(aggr='add')
        
        self.lin_msg = DecomposedLinear(in_channels, out_channels, bias=False, num_bases=num_bases, num_blocks=num_blocks)
        self.bias_msg = nn.Parameter(torch.Tensor(out_channels))
        
        self.lin_root = DecomposedLinear(in_channels, out_channels, bias=False, num_bases=num_bases, num_blocks=num_blocks)
        self.bias_root = nn.Parameter(torch.Tensor(out_channels))
            
        self.reset_parameters()
        
    def reset_parameters(self):
        self.lin_msg.reset_parameters()
        nn.init.zeros_(self.bias_msg)
        self.lin_root.reset_parameters()
        nn.init.zeros_(self.bias_root)
            
    def forward(self, x, edge_index, edge_weight=None):
        h_msg = self.propagate(edge_index, x=self.lin_msg(x), edge_weight=edge_weight) + self.bias_msg
        h_root = self.lin_root(x) + self.bias_root
        return h_msg + h_root
        
    def message(self, x_j, edge_weight):
        return x_j if edge_weight is None else edge_weight.view(-1, 1) * x_j


class DirectGCNLayer(nn.Module):
    def __init__(self, in_channels: int, out_channels: int,
                  
                 path_names: List[str],
                 gating_mode: str = 'vector',
                 num_bases: Optional[int] = None,
                 num_blocks: Optional[int] = None,
                 decompose_projections: bool = False,
                 proj_num_bases: Optional[int] = None,
                 dropout_rate: float = 0.5):
        super().__init__()
        self.path_names = path_names
        self.gating_mode = str(gating_mode).lower().strip() if gating_mode is not None else 'none'
        self.dropout_rate = dropout_rate
        
        # Dictionary of Variable paths
        self.paths = nn.ModuleDict({
            path: DirectGCNVariable(in_channels, out_channels, num_bases, num_blocks, decompose_projections, proj_num_bases)
            for path in path_names
        })
        
        # Base node constant
        self.constant = nn.Parameter(torch.Tensor(1, out_channels))
        
        # Gating variables dynamically initialized per path
        if self.gating_mode == 'node_gate_vector':
            self.gate_proj = nn.ModuleDict({
                path: nn.Linear(in_channels, out_channels) for path in path_names
            })
        elif self.gating_mode == 'vector':
            self.gate_proj = nn.ModuleDict({
                path: nn.Linear(in_channels, 1) for path in path_names
            })
        elif self.gating_mode == 'scalar':
            self.C_scalar = nn.ParameterDict({
                path: nn.Parameter(torch.Tensor(1)) for path in path_names
            })
        elif self.gating_mode in ('none', 'no_gate', 'scalar_one', 'uniform', 'fixed_one'):
            # Ablation mode: No learnable gating coefficients at all (fixed scalar 1.0 per path)
            self.gate_proj = None
            self.C_scalar = None
        else:
            raise ValueError(f"DirectGCNLayer: Invalid gating mode: {gating_mode}")
            
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.zeros_(self.constant)
        
        for path in self.paths.values():
            path.reset_parameters()
            
        if self.gating_mode in ['node_gate_vector', 'vector']:
            for k in self.gate_proj.keys():
                nn.init.xavier_uniform_(self.gate_proj[k].weight)
                nn.init.zeros_(self.gate_proj[k].bias)
        elif self.gating_mode == 'scalar':
            for k in self.C_scalar.keys():
                nn.init.uniform_(self.C_scalar[k], 0, 1)

    def forward(self, x: Union[torch.Tensor, Dict[str, torch.Tensor]], data: Data) -> torch.Tensor:
        path_combinations = []
        gating_logits_list = []
        
        for path_name, path_mod in self.paths.items():
            edge_index = getattr(data, f"edge_index_{path_name}")
            edge_weight = getattr(data, f"edge_weight_{path_name}", None)
            
            # Select the correct input for this path
            x_path = x[path_name] if isinstance(x, dict) else x
            
            # Forward pass through the specialized variable
            out_path = path_mod(x_path, edge_index, edge_weight)
            out_path = F.dropout(out_path, p=self.dropout_rate, training=self.training)
            path_combinations.append(out_path)
            
            if self.gating_mode in ['node_gate_vector', 'vector']:
                gating_logits_batch = self.gate_proj[path_name](x_path)
                gating_logits_list.append(gating_logits_batch)
            elif self.gating_mode == 'scalar':
                gating_logits_list.append(self.C_scalar[path_name])
                
        if self.gating_mode in ('none', 'no_gate', 'scalar_one', 'uniform', 'fixed_one'):
            # Ablation: No gating coefficients (fixed scalar 1.0 per path)
            combined_h = sum(path_combinations[i] * 1.0 for i in range(len(self.path_names)))
        else:
            # Stack and tanh (which allows multiple paths to contribute strongly and negatively)
            gating_logits_stacked = torch.stack(gating_logits_list, dim=-1)
            gating_weights = torch.tanh(gating_logits_stacked)
            
            # Combine
            combined_h = sum(path_combinations[i] * gating_weights[..., i] for i in range(len(self.path_names)))
        
        # Add base node constant
        return combined_h + self.constant


class DirectGCNModule(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, num_layers: int,
                 
                 path_names: List[str],
                 gating_mode: str = 'vector',
                 num_bases: Optional[int] = None,
                 num_blocks: Optional[int] = None,
                 decompose_projections: bool = False,
                 proj_num_bases: Optional[int] = None,
                 dropout_rate: float = 0.5):
        super().__init__()
        self.num_layers = num_layers
        self.dropout_rate = dropout_rate

        self.layers = nn.ModuleList()
        self.norms = nn.ModuleList()
        if in_channels != out_channels:
            self.res_proj = nn.Linear(in_channels, out_channels, bias=True)
        else:
            self.res_proj = None
            
        for i in range(num_layers):
            in_dim = in_channels if i == 0 else out_channels
            self.layers.append(DirectGCNLayer(
                in_channels=in_dim,
                out_channels=out_channels,
                path_names=path_names,
                gating_mode=gating_mode,
                num_bases=num_bases,
                num_blocks=num_blocks,
                decompose_projections=decompose_projections,
                proj_num_bases=proj_num_bases,
                dropout_rate=dropout_rate
            ))
            self.norms.append(nn.LayerNorm(out_channels))

    def forward(self, x: Union[torch.Tensor, Dict[str, torch.Tensor]], data: Data) -> torch.Tensor:
        h = x
        for i, layer in enumerate(self.layers):
            h_new = layer(h, data)
            
            # Apply residual projection if it's the first layer
            if i == 0 and self.res_proj is not None:
                if isinstance(h, dict):
                    h_mean = sum(h.values()) / len(h)
                    h_new = h_new + self.res_proj(h_mean)
                else:
                    h_new = h_new + self.res_proj(h)
                
            h_new = self.norms[i](h_new)
            h_new = F.relu(h_new)
            h_new = F.dropout(h_new, p=self.dropout_rate, training=self.training)
            # Residual connection for subsequent layers
            if i > 0:
                # After the first layer, h is always a torch.Tensor (output of h_new)
                if h.size(-1) == h_new.size(-1):
                    h = h + h_new
                else:
                    h = h_new
            else:
                h = h_new
        return h


class DirectGCN(nn.Module):
    def __init__(self, in_channels: int, hidden_channels: int, out_channels: int,
                 
                 path_names: Optional[List[str]] = None,
                 num_layers_per_module: int = 2,
                 gating_mode: str = 'vector',
                 num_bases: Optional[int] = None,
                 num_blocks: Optional[int] = None,
                 decompose_projections: bool = False,
                 proj_num_bases: Optional[int] = None,
                 dropout_rate: float = 0.5):
        super().__init__()
        if path_names is None:
            self.path_names = ['mathcal_in', 'mathcal_out', 'undirected_norm', 'homophilic', 'heterophilic', 'cyclic', 'acyclic']
        else:
            self.path_names = path_names
            
        self.dropout_rate = dropout_rate

        self.path_convs = nn.ModuleDict({
            path: DirectGCNVariable(in_channels, hidden_channels, num_bases, num_blocks, decompose_projections, proj_num_bases) for path in self.path_names
        })
        self.module1 = DirectGCNModule(hidden_channels, hidden_channels, num_layers_per_module,
                                       self.path_names, gating_mode, num_bases, num_blocks,
                                       decompose_projections, proj_num_bases, dropout_rate)

        self.module2 = DirectGCNModule(hidden_channels, hidden_channels, num_layers_per_module,
                                       self.path_names, gating_mode, num_bases, num_blocks,
                                       decompose_projections, proj_num_bases, dropout_rate)

        # Final DirectGCNLayer for Node Classification (replacing MLP)
        self.classifier = DirectGCNLayer(hidden_channels, out_channels,
                                         self.path_names, gating_mode, num_bases, num_blocks,
                                         decompose_projections, proj_num_bases, dropout_rate)
        # Decoders for Link Tasks
        self.exist_decoder = nn.Sequential(
            nn.Linear(hidden_channels * 4, hidden_channels),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(hidden_channels, 1)
        )
        self.sim_decoder = nn.Sequential(
            nn.Linear(hidden_channels * 4, hidden_channels),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(hidden_channels, 1)
        )
        
        # Bilinear weight matrix for Edge Directionality Prediction
        
        self.dir_decoder = nn.Sequential(
            nn.Linear(hidden_channels * 4, hidden_channels),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(hidden_channels, 1)
        )
        self.cyc_decoder = nn.Sequential(
            nn.Linear(hidden_channels * 4, hidden_channels),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(hidden_channels, 1)
        )


    def _get_link_features(self, h: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        src, tgt = edge_index
        h_src = F.normalize(h[src], p=2, dim=-1)
        h_tgt = F.normalize(h[tgt], p=2, dim=-1)
        return torch.cat([h_src, h_tgt, h_src * h_tgt, torch.abs(h_src - h_tgt)], dim=-1)

    def predict_exist(self, h: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        features = self._get_link_features(h, edge_index)
        return self.exist_decoder(features).squeeze(-1)

    def predict_sim(self, h: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        features = self._get_link_features(h, edge_index)
        return self.sim_decoder(features).squeeze(-1)
        
    def predict_dir(self, h: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        features = self._get_link_features(h, edge_index)
        return self.dir_decoder(features).squeeze(-1)

    def predict_cyc(self, h: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        features = self._get_link_features(h, edge_index)
        return self.cyc_decoder(features).squeeze(-1)

    def forward(self, data: Data) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        x = getattr(data, 'x', None)
        if x is None:
            raise ValueError("DirectGCN requires 'x' in the Data object.")

        for key in self.path_names:
            if not hasattr(data, f'edge_index_{key}'):
                setattr(data, f'edge_index_{key}', data.edge_index)
                setattr(data, f'edge_weight_{key}', None)

        # --- Initial Spatial Smoothing Stage (Independent Per Path) ---
        x_dict = {}
        for path in self.path_names:
            edge_index_path = getattr(data, f'edge_index_{path}', data.edge_index)
            x_dict[path] = F.relu(self.path_convs[path](x, edge_index_path))

        # --- Module 1 Forward ---
        h1 = self.module1(x_dict, data)

        # --- Module 2 Forward ---
        h2 = self.module2(h1, data)

        # --- Node Classification ---
        logits = self.classifier(h2, data)

        # Return h1 so the training loop can sample edges and call predict functions dynamically
        return logits, h1, h2
