# ==============================================================================
# MODULE: models/gnn/spectral/dirgnn.py
# PURPOSE: Implements the exact Dir-GCN model from "Edge Directionality Improves
#          Learning on Heterophilic Graphs" (Rossi et al., LoG 2023, Eq. 7).
# VERSION: 8.0 (Exact Dir-GCN with independent W_fwd/W_bwd & directed norm)
# AUTHOR: Islam Ebeid
# ==============================================================================

from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.data import Data
from torch_geometric.nn import MessagePassing
from torch_geometric.utils import degree


class DirGCNConv(MessagePassing):
    """
    Exact Dir-GCN convolution layer from Rossi et al. (2023), Eq. (7):
        H^{(l)} = alpha * D_out^{-1/2} A D_in^{-1/2} H^{(l-1)} W_fwd
                + (1 - alpha) * D_in^{-1/2} A^T D_out^{-1/2} H^{(l-1)} W_bwd

    Uses separate learnable weight matrices for forward (src -> dst) and
    backward (dst -> src) message passing, with directed asymmetric degree
    normalization D_out(u)^{-1/2} * D_in(v)^{-1/2}.
    """

    def __init__(self, in_channels: int, out_channels: int, alpha: float = 0.5, bias: bool = True):
        super().__init__(aggr="add", flow="source_to_target")
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.alpha = alpha

        # Independent weight matrices W_{\rightarrow} and W_{\leftarrow}
        self.lin_src_to_dst = nn.Linear(in_channels, out_channels, bias=bias)
        self.lin_dst_to_src = nn.Linear(in_channels, out_channels, bias=bias)
        self.reset_parameters()

    def reset_parameters(self):
        self.lin_src_to_dst.reset_parameters()
        self.lin_dst_to_src.reset_parameters()

    @staticmethod
    def _directed_norm(
        edge_index: torch.Tensor,
        num_nodes: int,
        edge_weight: Optional[torch.Tensor] = None,
        dtype: Optional[torch.dtype] = None,
    ) -> torch.Tensor:
        row, col = edge_index[0], edge_index[1]
        if edge_weight is None:
            edge_weight = torch.ones(row.size(0), dtype=dtype or torch.float32, device=edge_index.device)
        else:
            edge_weight = edge_weight.to(dtype=dtype or torch.float32)

        # Out-degree d_{u, ->} and in-degree d_{v, <-}
        deg_out = degree(row, num_nodes, dtype=edge_weight.dtype)
        deg_in = degree(col, num_nodes, dtype=edge_weight.dtype)

        deg_out_inv_sqrt = deg_out.pow(-0.5)
        deg_out_inv_sqrt.masked_fill_(deg_out_inv_sqrt == float("inf"), 0.0)

        deg_in_inv_sqrt = deg_in.pow(-0.5)
        deg_in_inv_sqrt.masked_fill_(deg_in_inv_sqrt == float("inf"), 0.0)

        return deg_out_inv_sqrt[row] * edge_weight * deg_in_inv_sqrt[col]

    def forward(
        self,
        x: torch.Tensor,
        edge_index: torch.Tensor,
        edge_index_bwd: Optional[torch.Tensor] = None,
        edge_weight: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        num_nodes = x.size(0)

        # Forward pass (u -> v) with asymmetric directed normalization
        norm_fwd = self._directed_norm(edge_index, num_nodes, edge_weight, dtype=x.dtype)
        x_fwd = self.lin_src_to_dst(x)
        out_fwd = self.propagate(edge_index, x=x_fwd, norm=norm_fwd, size=(num_nodes, num_nodes))

        # Backward pass (v -> u) with transpose directed normalization
        if edge_index_bwd is None:
            edge_index_bwd = edge_index.flip([0])
            norm_bwd = norm_fwd
        else:
            # For reversed edges (v -> u), out-degree of original source u is deg_in of bwd col,
            # and in-degree of original target v is deg_out of bwd row.
            row_bwd, col_bwd = edge_index_bwd[0], edge_index_bwd[1]
            deg_in_orig = degree(row_bwd, num_nodes, dtype=x.dtype)
            deg_out_orig = degree(col_bwd, num_nodes, dtype=x.dtype)
            deg_in_inv_sqrt = deg_in_orig.pow(-0.5)
            deg_in_inv_sqrt.masked_fill_(deg_in_inv_sqrt == float("inf"), 0.0)
            deg_out_inv_sqrt = deg_out_orig.pow(-0.5)
            deg_out_inv_sqrt.masked_fill_(deg_out_inv_sqrt == float("inf"), 0.0)
            norm_bwd = deg_in_inv_sqrt[row_bwd] * deg_out_inv_sqrt[col_bwd]

        x_bwd = self.lin_dst_to_src(x)
        out_bwd = self.propagate(edge_index_bwd, x=x_bwd, norm=norm_bwd, size=(num_nodes, num_nodes))

        return self.alpha * out_fwd + (1.0 - self.alpha) * out_bwd

    def message(self, x_j: torch.Tensor, norm: torch.Tensor) -> torch.Tensor:
        return norm.view(-1, 1) * x_j


class DirGNN(nn.Module):
    """
    Exact implementation of Dir-GCN from Rossi et al. (2023),
    "Edge Directionality Improves Learning on Heterophilic Graphs".
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int = 2,
        dropout_rate: float = 0.5,
        alpha: float = 0.5,
        normalize: bool = True,
        **kwargs,
    ):
        super().__init__()
        self.alpha = alpha
        self.convs = nn.ModuleList()
        self.dropout_rate = dropout_rate
        self.normalize = normalize
        self.embedding_output = None

        if num_layers <= 0:
            raise ValueError("num_layers must be positive")

        if num_layers == 1:
            self.convs.append(DirGCNConv(in_channels, out_channels, alpha=self.alpha))
        else:
            self.convs.append(DirGCNConv(in_channels, hidden_channels, alpha=self.alpha))
            for _ in range(num_layers - 2):
                self.convs.append(DirGCNConv(hidden_channels, hidden_channels, alpha=self.alpha))
            self.convs.append(DirGCNConv(hidden_channels, out_channels, alpha=self.alpha))

    def forward(self, data: Data) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass for the exact Dir-GCN model (Rossi et al., 2023).
        """
        x, edge_index = data.x, data.edge_index
        edge_index_bwd = getattr(data, "edge_index_backward", None)

        for i in range(len(self.convs) - 1):
            x = self.convs[i](x, edge_index, edge_index_bwd)
            x = F.relu(x)
            if self.normalize:
                x = F.normalize(x, p=2.0, dim=-1)
            x = F.dropout(x, p=self.dropout_rate, training=self.training)

        self.embedding_output = x
        if len(self.convs) == 1:
            logits = self.convs[0](x, edge_index, edge_index_bwd)
        else:
            logits = self.convs[-1](self.embedding_output, edge_index, edge_index_bwd)

        return logits, self.embedding_output
