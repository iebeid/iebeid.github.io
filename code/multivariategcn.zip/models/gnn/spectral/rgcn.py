# ==============================================================================
# MODULE: models/gnn/spectral/rgcn.py
# PURPOSE: Relational Graph Convolutional Network (R-GCN, Schlichtkrull et al.,
#          ESWC 2018) with basis decomposition and DistMult relational decoder.
# VERSION: 7.0 (Added basis decomposition and DistMult triple scoring decoder)
# AUTHOR: Islam Ebeid
# ==============================================================================

from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.data import Data
from torch_geometric.nn import RGCNConv


class RGCN(nn.Module):
    """
    Relational Graph Convolutional Network (R-GCN, Schlichtkrull et al., 2018).
    Supports both entity/node classification (Section 3) and relational link
    prediction via a diagonal DistMult relation operator (Section 4, Eq. 6).
    Automatically uses basis decomposition (`num_bases`) when the number of
    relations is large (e.g., FB15k / WN18) to prevent parameter explosion.
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_relations: int = 2,
        num_layers: int = 2,
        dropout_rate: float = 0.5,
        num_bases: Optional[int] = None,
        **kwargs,
    ):
        super().__init__()
        self.convs = nn.ModuleList()
        self.dropout_rate = dropout_rate
        self.num_relations = max(1, int(num_relations))
        self.embedding_output = None

        # Use basis decomposition automatically for multi-relational KGs if not specified
        if num_bases is None and self.num_relations > 8:
            num_bases = min(30, self.num_relations)

        rgcn_kwargs = dict(kwargs)
        if num_bases is not None:
            rgcn_kwargs["num_bases"] = min(int(num_bases), self.num_relations)

        if num_layers == 1:
            self.convs.append(
                RGCNConv(in_channels, out_channels, num_relations=self.num_relations, **rgcn_kwargs)
            )
            self.res_proj = nn.Identity()
            emb_dim = out_channels
        else:
            self.convs.append(
                RGCNConv(in_channels, hidden_channels, num_relations=self.num_relations, **rgcn_kwargs)
            )
            if in_channels != hidden_channels:
                self.res_proj = nn.Linear(in_channels, hidden_channels)
            else:
                self.res_proj = nn.Identity()
            for _ in range(num_layers - 2):
                self.convs.append(
                    RGCNConv(hidden_channels, hidden_channels, num_relations=self.num_relations, **rgcn_kwargs)
                )
            self.convs.append(
                RGCNConv(hidden_channels, out_channels, num_relations=self.num_relations, **rgcn_kwargs)
            )
            emb_dim = hidden_channels

        # Diagonal DistMult relation operator R_r for R-GCN link prediction (Eq. 6)
        self.rel_emb = nn.Embedding(self.num_relations, emb_dim)
        nn.init.xavier_uniform_(self.rel_emb.weight)

    def score_triples(
        self,
        h: torch.Tensor,
        edge_index: torch.Tensor,
        edge_type: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        src, dst = edge_index[0], edge_index[1]
        h_norm = F.normalize(h, p=2, dim=-1)
        if edge_type is not None and edge_type.numel() == edge_index.size(1) and h_norm.size(-1) == self.rel_emb.embedding_dim:
            clamped_rel = edge_type.clamp(0, self.rel_emb.num_embeddings - 1)
            r_vec = self.rel_emb(clamped_rel)
            return (h_norm[src] * r_vec * h_norm[dst]).sum(dim=-1)
        return (h_norm[src] * h_norm[dst]).sum(dim=-1)

    def predict_exist(
        self,
        h: torch.Tensor,
        edge_index: torch.Tensor,
        edge_type: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        return self.score_triples(h, edge_index, edge_type)

    def forward(self, data: Data) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Custom forward pass for RGCN that handles `edge_type`.
        """
        x, edge_index = data.x, data.edge_index
        edge_type = getattr(data, "edge_type", None)
        if edge_type is None:
            edge_type = torch.zeros(edge_index.size(1), dtype=torch.long, device=edge_index.device)
        else:
            edge_type = edge_type.clamp(0, self.num_relations - 1)

        if len(self.convs) == 1:
            logits = self.convs[0](x, edge_index, edge_type)
            self.embedding_output = logits
            return logits, self.embedding_output

        x_res = self.res_proj(x)

        for i, conv in enumerate(self.convs[:-1]):
            x = conv(x, edge_index, edge_type)
            if i == 0:
                x = x + x_res
            x = F.relu(x)
            x = F.dropout(x, p=self.dropout_rate, training=self.training)

        self.embedding_output = x
        logits = self.convs[-1](self.embedding_output, edge_index, edge_type)

        return logits, self.embedding_output
