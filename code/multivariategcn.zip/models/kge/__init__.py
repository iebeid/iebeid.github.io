from models.kge.distmult import DistMult
from models.kge.complex import ComplEx

__all__ = ["DistMult", "ComplEx"]
