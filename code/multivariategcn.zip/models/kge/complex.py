# ==============================================================================
# MODULE: models/kge/complex.py
# PURPOSE: Implements the ComplEx (Complex Embeddings for Simple Link Prediction)
#          Knowledge Graph Embedding model (Trouillon et al., ICML 2016;
#          referenced in Schlichtkrull et al., ESWC 2018).
# VERSION: 1.0
# AUTHOR: Islam Ebeid
# ==============================================================================
from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.data import Data


class ComplEx(nn.Module):
    """
    ComplEx Knowledge Graph Embedding model (Trouillon et al., ICML 2016).

    Represents entities and relations in complex vector space C^d and scores
    relational triples via the real part of the Hermitian trilinear product:

        f(s, r, o) = Re(<e_s, w_r, conj(e_o)>)
                   = <Re(e_s), Re(w_r), Re(e_o)>
                   + <Im(e_s), Re(w_r), Im(e_o)>
                   + <Re(e_s), Im(w_r), Im(e_o)>
                   - <Im(e_s), Im(w_r), Re(e_o)>

    Because of the complex conjugate on the object entity `conj(e_o)`, ComplEx
    naturally models both symmetric and antisymmetric/directed relations
    (unlike DistMult, which is strictly symmetric).
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_graph_nodes: int = 0,
        num_relations: int = 2,
        dropout_rate: float = 0.5,
        num_negatives: int = 1,
        reg_weight: float = 0.01,
        **kwargs,
    ):
        super().__init__()
        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.num_graph_nodes = max(1, int(num_graph_nodes))
        self.num_relations = max(1, int(num_relations))
        self.dropout_rate = dropout_rate
        self.num_negatives = max(1, int(num_negatives))
        self.reg_weight = float(reg_weight)
        self.embedding_output = None

        # Real and Imaginary entity embeddings in R^d (concatenated in R^{2d})
        self.entity_re = nn.Embedding(self.num_graph_nodes, hidden_channels)
        self.entity_im = nn.Embedding(self.num_graph_nodes, hidden_channels)

        # Real and Imaginary relation embeddings in R^d
        self.rel_re = nn.Embedding(self.num_relations, hidden_channels)
        self.rel_im = nn.Embedding(self.num_relations, hidden_channels)

        # Feature projections into Real and Imaginary subspaces
        self.feat_proj_re = nn.Linear(in_channels, hidden_channels)
        self.feat_proj_im = nn.Linear(in_channels, hidden_channels)
        self.norm_re = nn.LayerNorm(hidden_channels)
        self.norm_im = nn.LayerNorm(hidden_channels)

        # Node classification head operating on concatenated [Re(e); Im(e)] in R^{2d}
        self.classifier = nn.Linear(hidden_channels * 2, out_channels)

        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.entity_re.weight)
        nn.init.xavier_uniform_(self.entity_im.weight)
        nn.init.xavier_uniform_(self.rel_re.weight)
        nn.init.xavier_uniform_(self.rel_im.weight)
        self.feat_proj_re.reset_parameters()
        self.feat_proj_im.reset_parameters()
        self.norm_re.reset_parameters()
        self.norm_im.reset_parameters()
        self.classifier.reset_parameters()

    def _ensure_capacity(self, num_nodes: int, num_rels: int, device: torch.device):
        if num_nodes > self.entity_re.num_embeddings:
            old_re = self.entity_re.weight.data
            old_im = self.entity_im.weight.data
            self.entity_re = nn.Embedding(num_nodes, self.hidden_channels, device=device)
            self.entity_im = nn.Embedding(num_nodes, self.hidden_channels, device=device)
            nn.init.xavier_uniform_(self.entity_re.weight)
            nn.init.xavier_uniform_(self.entity_im.weight)
            with torch.no_grad():
                self.entity_re.weight[: old_re.size(0)] = old_re.to(device)
                self.entity_im.weight[: old_im.size(0)] = old_im.to(device)
            self.num_graph_nodes = num_nodes

        if num_rels > self.rel_re.num_embeddings:
            old_r_re = self.rel_re.weight.data
            old_r_im = self.rel_im.weight.data
            self.rel_re = nn.Embedding(num_rels, self.hidden_channels, device=device)
            self.rel_im = nn.Embedding(num_rels, self.hidden_channels, device=device)
            nn.init.xavier_uniform_(self.rel_re.weight)
            nn.init.xavier_uniform_(self.rel_im.weight)
            with torch.no_grad():
                self.rel_re.weight[: old_r_re.size(0)] = old_r_re.to(device)
                self.rel_im.weight[: old_r_im.size(0)] = old_r_im.to(device)
            self.num_relations = num_rels

    def _split_complex(self, h: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        if h.size(-1) == 2 * self.hidden_channels:
            return h[..., : self.hidden_channels], h[..., self.hidden_channels :]
        half = h.size(-1) // 2
        return h[..., :half], h[..., half:]

    def score_triples(
        self,
        h: torch.Tensor,
        edge_index: torch.Tensor,
        edge_type: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Computes the exact ComplEx Hermitian bilinear score:
            f(s, r, o) = Re(<e_s, w_r, conj(e_o)>)
        """
        h_re, h_im = self._split_complex(h)
        src, dst = edge_index[0], edge_index[1]

        s_re, s_im = h_re[src], h_im[src]
        o_re, o_im = h_re[dst], h_im[dst]

        if edge_type is not None and edge_type.numel() == edge_index.size(1):
            clamped_rel = edge_type.clamp(0, self.rel_re.num_embeddings - 1)
            r_re = self.rel_re(clamped_rel)
            r_im = self.rel_im(clamped_rel)
        else:
            r_re = self.rel_re.weight[0].unsqueeze(0)
            r_im = self.rel_im.weight[0].unsqueeze(0)

        score = (
            (s_re * r_re * o_re)
            + (s_im * r_re * o_im)
            + (s_re * r_im * o_im)
            - (s_im * r_im * o_re)
        ).sum(dim=-1)
        return score

    def predict_exist(
        self,
        h: torch.Tensor,
        edge_index: torch.Tensor,
        edge_type: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        return self.score_triples(h, edge_index, edge_type)

    def compute_kge_loss(
        self,
        h: torch.Tensor,
        data: Data,
        num_negatives: Optional[int] = None,
    ) -> torch.Tensor:
        """
        Computes the negative-sampling binary cross-entropy loss with complex
        modulus L2/N3 regularization for ComplEx.
        """
        if getattr(data, "original_indices", getattr(data, "n_id", None)) is not None:
            edge_index = data.edge_index
            edge_type = getattr(data, "edge_type", None)
        else:
            edge_index = getattr(data, "train_edge_index", data.edge_index)
            edge_type = getattr(data, "train_edge_type", getattr(data, "edge_type", None))
        num_nodes = h.size(0)
        if edge_index.numel() == 0:
            return torch.tensor(0.0, device=h.device)

        max_rels = int(edge_type.max().item()) + 1 if (edge_type is not None and edge_type.numel() > 0) else 1
        self._ensure_capacity(num_nodes, max_rels, h.device)

        max_triples = 32768
        num_pos = edge_index.size(1)
        if num_pos > max_triples:
            perm = torch.randint(0, num_pos, (max_triples,), device=edge_index.device)
            pos_edges = edge_index[:, perm]
            pos_rels = edge_type[perm] if (edge_type is not None and edge_type.numel() == num_pos) else None
        else:
            pos_edges = edge_index
            pos_rels = edge_type if (edge_type is not None and edge_type.numel() == num_pos) else None

        pos_scores = self.score_triples(h, pos_edges, pos_rels)

        neg_ratio = num_negatives if num_negatives is not None else self.num_negatives
        neg_edges_list = []
        neg_rels_list = []
        num_batch = pos_edges.size(1)
        for _ in range(neg_ratio):
            corrupt_head = torch.rand(num_batch, device=h.device) < 0.5
            rand_nodes = torch.randint(0, num_nodes, (num_batch,), device=h.device)
            neg_src = torch.where(corrupt_head, rand_nodes, pos_edges[0])
            neg_dst = torch.where(corrupt_head, pos_edges[1], rand_nodes)
            neg_edges_list.append(torch.stack([neg_src, neg_dst], dim=0))
            if pos_rels is not None:
                neg_rels_list.append(pos_rels)

        neg_edges = torch.cat(neg_edges_list, dim=1)
        neg_rels = torch.cat(neg_rels_list, dim=0) if neg_rels_list else None
        neg_scores = self.score_triples(h, neg_edges, neg_rels)

        scores = torch.cat([pos_scores, neg_scores], dim=0)
        labels = torch.cat(
            [
                torch.ones_like(pos_scores),
                torch.zeros_like(neg_scores),
            ],
            dim=0,
        )
        bce_loss = F.binary_cross_entropy_with_logits(scores, labels)

        reg_loss = (
            h.pow(2).mean()
            + self.rel_re.weight.pow(2).mean()
            + self.rel_im.weight.pow(2).mean()
        )
        return bce_loss + self.reg_weight * reg_loss

    def forward(self, data: Data) -> Tuple[torch.Tensor, torch.Tensor]:
        x = data.x
        num_nodes = x.size(0)
        edge_type = getattr(data, "edge_type", None)
        max_rels = int(edge_type.max().item()) + 1 if (edge_type is not None and edge_type.numel() > 0) else self.num_relations
        node_ids = getattr(data, "original_indices", getattr(data, "n_id", getattr(data, "node_id", None)))
        if node_ids is None:
            self._ensure_capacity(num_nodes, max_rels, x.device)
            node_ids = torch.arange(num_nodes, device=x.device)
        else:
            node_ids = node_ids.to(x.device)
            self._ensure_capacity(int(node_ids.max().item()) + 1, max_rels, x.device)
        re = self.norm_re(self.entity_re(node_ids) + self.feat_proj_re(x))
        im = self.norm_im(self.entity_im(node_ids) + self.feat_proj_im(x))

        re = F.dropout(re, p=self.dropout_rate, training=self.training)
        im = F.dropout(im, p=self.dropout_rate, training=self.training)

        h = torch.cat([re, im], dim=-1)
        self.embedding_output = h
        logits = self.classifier(self.embedding_output)
        return logits, self.embedding_output
