# ==============================================================================
# MODULE: models/kge/distmult.py
# PURPOSE: Implements the DistMult Knowledge Graph Embedding (KGE) model
#          (Yang et al., ICLR 2015; Schlichtkrull et al., ESWC 2018, Eq. 6-7).
# VERSION: 1.0
# AUTHOR: Islam Ebeid
# ==============================================================================
from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.data import Data


class DistMult(nn.Module):
    """
    DistMult Knowledge Graph Embedding model (Yang et al., 2015) as formulated
    in R-GCN (Schlichtkrull et al., 2018):

        f(s, r, o) = e_s^T R_r e_o = sum_d (e_{s,d} * r_{r,d} * e_{o,d})

    where R_r = diag(r_r) is a diagonal matrix for relation r.
    Supports both multi-relational knowledge graphs (e.g., FB15k, WN18) and
    standard directed/undirected graphs, providing:
      - `score_triples(h, edge_index, edge_type)`: exact DistMult bilinear score
      - `compute_kge_loss(h, data)`: cross-entropy negative-sampling loss (Eq. 7)
        with L2 regularization on entity and relation factors
      - `forward(data)`: returns `(logits, embeddings)` for unified evaluation
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_graph_nodes: int = 0,
        num_relations: int = 2,
        dropout_rate: float = 0.5,
        num_negatives: int = 1,
        reg_weight: float = 0.01,
        **kwargs,
    ):
        super().__init__()
        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.num_graph_nodes = max(1, int(num_graph_nodes))
        self.num_relations = max(1, int(num_relations))
        self.dropout_rate = dropout_rate
        self.num_negatives = max(1, int(num_negatives))
        self.reg_weight = float(reg_weight)
        self.embedding_output = None

        # Learnable entity embeddings e_i in R^d
        self.entity_emb = nn.Embedding(self.num_graph_nodes, hidden_channels)
        # Learnable diagonal relation operators r_r in R^d
        self.rel_emb = nn.Embedding(self.num_relations, hidden_channels)

        # Feature encoder to incorporate node attributes when available
        self.feat_proj = nn.Linear(in_channels, hidden_channels)
        self.norm = nn.LayerNorm(hidden_channels)
        self.classifier = nn.Linear(hidden_channels, out_channels)

        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.entity_emb.weight)
        nn.init.xavier_uniform_(self.rel_emb.weight)
        self.feat_proj.reset_parameters()
        self.norm.reset_parameters()
        self.classifier.reset_parameters()

    def _ensure_capacity(self, num_nodes: int, num_rels: int, device: torch.device):
        if num_nodes > self.entity_emb.num_embeddings:
            old_ent = self.entity_emb.weight.data
            self.entity_emb = nn.Embedding(num_nodes, self.hidden_channels, device=device)
            nn.init.xavier_uniform_(self.entity_emb.weight)
            with torch.no_grad():
                self.entity_emb.weight[: old_ent.size(0)] = old_ent.to(device)
            self.num_graph_nodes = num_nodes

        if num_rels > self.rel_emb.num_embeddings:
            old_rel = self.rel_emb.weight.data
            self.rel_emb = nn.Embedding(num_rels, self.hidden_channels, device=device)
            nn.init.xavier_uniform_(self.rel_emb.weight)
            with torch.no_grad():
                self.rel_emb.weight[: old_rel.size(0)] = old_rel.to(device)
            self.num_relations = num_rels

    def score_triples(
        self,
        h: torch.Tensor,
        edge_index: torch.Tensor,
        edge_type: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Computes the DistMult bilinear diagonal score:
            f(s, r, o) = <e_s, r_r, e_o>
        """
        src, dst = edge_index[0], edge_index[1]
        e_s = h[src]
        e_o = h[dst]
        if edge_type is not None and edge_type.numel() == edge_index.size(1):
            clamped_rel = edge_type.clamp(0, self.rel_emb.num_embeddings - 1)
            r_vec = self.rel_emb(clamped_rel)
        else:
            r_vec = self.rel_emb.weight[0].unsqueeze(0)
        return (e_s * r_vec * e_o).sum(dim=-1)

    def predict_exist(
        self,
        h: torch.Tensor,
        edge_index: torch.Tensor,
        edge_type: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        return self.score_triples(h, edge_index, edge_type)

    def compute_kge_loss(
        self,
        h: torch.Tensor,
        data: Data,
        num_negatives: Optional[int] = None,
    ) -> torch.Tensor:
        """
        Computes the R-GCN / DistMult cross-entropy loss with negative sampling
        (Schlichtkrull et al., 2018, Eq. 7) by corrupting either the subject or
        the object of each positive triple.
        """
        # If batch_data is a subgraph while train_edge_index has global IDs, use batch_data.edge_index
        if getattr(data, "original_indices", getattr(data, "n_id", None)) is not None:
            edge_index = data.edge_index
            edge_type = getattr(data, "edge_type", None)
        else:
            edge_index = getattr(data, "train_edge_index", data.edge_index)
            edge_type = getattr(data, "train_edge_type", getattr(data, "edge_type", None))
        num_nodes = h.size(0)
        if edge_index.numel() == 0:
            return torch.tensor(0.0, device=h.device)

        max_rels = int(edge_type.max().item()) + 1 if (edge_type is not None and edge_type.numel() > 0) else 1
        self._ensure_capacity(num_nodes, max_rels, h.device)

        max_triples = 32768
        num_pos = edge_index.size(1)
        if num_pos > max_triples:
            perm = torch.randint(0, num_pos, (max_triples,), device=edge_index.device)
            pos_edges = edge_index[:, perm]
            pos_rels = edge_type[perm] if (edge_type is not None and edge_type.numel() == num_pos) else None
        else:
            pos_edges = edge_index
            pos_rels = edge_type if (edge_type is not None and edge_type.numel() == num_pos) else None

        pos_scores = self.score_triples(h, pos_edges, pos_rels)

        neg_ratio = num_negatives if num_negatives is not None else self.num_negatives
        neg_edges_list = []
        neg_rels_list = []
        num_batch = pos_edges.size(1)
        for _ in range(neg_ratio):
            corrupt_head = torch.rand(num_batch, device=h.device) < 0.5
            rand_nodes = torch.randint(0, num_nodes, (num_batch,), device=h.device)
            neg_src = torch.where(corrupt_head, rand_nodes, pos_edges[0])
            neg_dst = torch.where(corrupt_head, pos_edges[1], rand_nodes)
            neg_edges_list.append(torch.stack([neg_src, neg_dst], dim=0))
            if pos_rels is not None:
                neg_rels_list.append(pos_rels)

        neg_edges = torch.cat(neg_edges_list, dim=1)
        neg_rels = torch.cat(neg_rels_list, dim=0) if neg_rels_list else None
        neg_scores = self.score_triples(h, neg_edges, neg_rels)

        scores = torch.cat([pos_scores, neg_scores], dim=0)
        labels = torch.cat(
            [
                torch.ones_like(pos_scores),
                torch.zeros_like(neg_scores),
            ],
            dim=0,
        )
        bce_loss = F.binary_cross_entropy_with_logits(scores, labels)

        # L2 regularization on active entity and relation factors
        reg_loss = h.pow(2).mean() + self.rel_emb.weight.pow(2).mean()
        return bce_loss + self.reg_weight * reg_loss

    def forward(self, data: Data) -> Tuple[torch.Tensor, torch.Tensor]:
        x = data.x
        num_nodes = x.size(0)
        edge_type = getattr(data, "edge_type", None)
        max_rels = int(edge_type.max().item()) + 1 if (edge_type is not None and edge_type.numel() > 0) else self.num_relations
        node_ids = getattr(data, "original_indices", getattr(data, "n_id", getattr(data, "node_id", None)))
        if node_ids is None:
            self._ensure_capacity(num_nodes, max_rels, x.device)
            node_ids = torch.arange(num_nodes, device=x.device)
        else:
            node_ids = node_ids.to(x.device)
            self._ensure_capacity(int(node_ids.max().item()) + 1, max_rels, x.device)
        e_struct = self.entity_emb(node_ids)
        e_feat = self.feat_proj(x)

        h = self.norm(e_struct + e_feat)
        h = F.dropout(h, p=self.dropout_rate, training=self.training)

        self.embedding_output = h
        logits = self.classifier(self.embedding_output)
        return logits, self.embedding_output
