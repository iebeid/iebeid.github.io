import sys
import os
import shutil
from pathlib import Path

# Opt-out of MLflow filestore maintenance exception
os.environ["MLFLOW_ALLOW_FILE_STORE"] = "true"
# Fix CuBLAS deterministic algorithm error
os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"

# Workaround for WSL NTFS mount permission errors with MLflow artifact logging
_original_copystat = shutil.copystat
def _safe_copystat(*args, **kwargs):
    try:
        _original_copystat(*args, **kwargs)
    except PermissionError:
        pass
shutil.copystat = _safe_copystat

import pandas as pd
from configuration.config import Config
from torch_geometric.datasets import Planetoid
from train.gnns import GNNBenchmarker
config = Config('configuration/config.yaml')
project_root = Path(__file__).resolve().parent
sys.path.insert(0, str(project_root))
dataset_root = config.DATA_STANDARD_DATASETS_DIR
Planetoid(root=str(dataset_root), name='Cora')
benchmark_results_df = GNNBenchmarker(config).run()
if benchmark_results_df is not None and not benchmark_results_df.empty:
    print("\n--- Benchmark Results Summary ---")
    pd.set_option('display.max_columns', None)
    pd.set_option('display.width', 1000)
    if 'variant' in benchmark_results_df.columns:
        benchmark_results_df['variant'] = benchmark_results_df['variant'].fillna('Standard')
    # Group by dataset and then sort by accuracy and F1-score
    sort_cols = ['dataset']
    ascendings = [True]
    
    if 'Accuracy' in benchmark_results_df.columns:
        sort_cols.append('Accuracy')
        ascendings.append(False)
    
    if 'F1-Score (Macro)' in benchmark_results_df.columns:
        sort_cols.append('F1-Score (Macro)')
        ascendings.append(False)
        
    sorted_df = benchmark_results_df.sort_values(by=sort_cols, ascending=ascendings)
    print(sorted_df)