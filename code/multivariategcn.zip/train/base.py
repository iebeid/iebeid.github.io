# ==============================================================================
# MODULE: benchmarkers/base.py
# PURPOSE: A base class for benchmarking pipelines to reduce code duplication.
# VERSION: 2.0 (Added FB15k, FB15k-237, WN18, WN18RR Knowledge Graph support)
# AUTHOR: Islam Ebeid
# ==============================================================================

import gzip
import io
import shutil
import urllib.request
from abc import ABC, abstractmethod
from collections import defaultdict
from pathlib import Path
from typing import Optional, Any, List, Tuple

import numpy as np
import pandas as pd
import torch
from torch_geometric.data import Data, Batch
from torch_geometric.datasets import (
    Planetoid,
    WebKB,
    Actor,
    KarateClub,
    Amazon,
    Coauthor,
    WikipediaNetwork,
    WikiCS,
    BitcoinOTC,
    SNAPDataset,
    CitationFull,
    WordNet18,
    WordNet18RR,
    RelLinkPredDataset,
    Entities,
    PPI,
)

from configuration.config import Config
from utils.data_utils import DataUtils


class _SingleGraphDatasetWrapper:
    """Lightweight list-like wrapper around a single PyG Data object."""

    def __init__(self, data: Data, num_classes: int = 0):
        self._data = data
        self.num_classes = num_classes

    def __getitem__(self, idx: int) -> Data:
        if idx != 0:
            raise IndexError("SingleGraphDatasetWrapper only contains index 0.")
        return self._data

    def __len__(self) -> int:
        return 1


class BaseBenchmarker(ABC):
    """
    An abstract base class for benchmarking pipelines.
    Handles common logic like dataset loading, directory setup, and seeding.
    """

    def __init__(self, config: Config, name: str):
        self.config = config
        self.name = name
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.output_dir = config.RESULTS_BENCHMARKING_DIR
        self.dataset_root = self._setup_dataset_cache(config)
        DataUtils.set_seeds(config.RANDOM_STATE)
        print("\n" + "=" * 80)
        DataUtils.print_header(f"{self.name} Initialized")
        print(f"  Device: {self.device}")
        print(f"  Output directory: {self.output_dir}")
        print(f"  Dataset root: {self.dataset_root}")
        print("=" * 80)

    def _setup_dataset_cache(self, config):
        project_benchmark_dir = config.DATA_STANDARD_DATASETS_DIR
        cache_benchmark_dir = config.PERSISTENT_DATA_CACHE / "benchmarks"

        cache_benchmark_dir.mkdir(parents=True, exist_ok=True)

        if project_benchmark_dir.exists():
            for item_name in project_benchmark_dir.iterdir():
                src = item_name
                dst = cache_benchmark_dir / item_name.name

                # Skip if already migrated (idempotent)
                if dst.exists():
                    continue

                shutil.move(str(src), str(cache_benchmark_dir))

        return config.DATA_STANDARD_DATASETS_DIR

    def _load_fb15k_raw(self, root_dir: Path) -> Optional[_SingleGraphDatasetWrapper]:
        """
        Loads or downloads the canonical FB15k Knowledge Graph dataset
        (Bordes et al., 2013; Schlichtkrull et al., 2018: 14,951 entities,
        1,345 relations). Falls back to FB15k-237 via PyG RelLinkPredDataset
        if remote mirrors are unreachable.
        """
        fb15k_dir = root_dir / "FB15k"
        processed_file = fb15k_dir / "processed" / "fb15k_pyg.pt"
        if processed_file.exists():
            data = torch.load(processed_file, weights_only=False)
            num_classes = int(data.y.max().item()) + 1 if getattr(data, "y", None) is not None else 16
            return _SingleGraphDatasetWrapper(data, num_classes=num_classes)

        raw_dir = fb15k_dir / "raw"
        raw_dir.mkdir(parents=True, exist_ok=True)
        (fb15k_dir / "processed").mkdir(parents=True, exist_ok=True)

        base_urls = [
            "https://raw.githubusercontent.com/villmow/datasets_knowledge_embedding/master/FB15k/",
            "https://raw.githubusercontent.com/thunlp/OpenKE/OpenKE-PyTorch/benchmarks/FB15K/",
        ]
        split_files = {"train": "train.txt", "valid": "valid.txt", "test": "test.txt"}

        downloaded = True
        for split_key, fname in split_files.items():
            fpath = raw_dir / fname
            if fpath.exists() and fpath.stat().st_size > 0:
                continue
            success = False
            for base_url in base_urls:
                try:
                    url = base_url + fname
                    print(f"  [FB15k] Downloading {fname} from {url} ...")
                    urllib.request.urlretrieve(url, str(fpath))
                    if fpath.exists() and fpath.stat().st_size > 100:
                        success = True
                        break
                except Exception:
                    continue
            if not success:
                downloaded = False
                break

        if not downloaded:
            print("  [FB15k] Remote raw mirror unavailable; loading FB15k-237 via PyG RelLinkPredDataset.")
            pyg_ds = RelLinkPredDataset(root=str(root_dir / "FB15k-237"), name="FB15k-237")
            return self._standardize_kg_dataset(pyg_ds, "FB15k")

        entity2id = {}
        rel2id = {}
        splits_edges = {}
        splits_rels = {}

        for split_key, fname in split_files.items():
            fpath = raw_dir / fname
            srcs, dsts, rels = [], [], []
            with open(fpath, "r", encoding="utf-8") as f:
                for line in f:
                    parts = line.strip().split()
                    if len(parts) != 3:
                        continue
                    # Standard FB15k format is (head, relation, tail)
                    h_str, r_str, t_str = parts[0], parts[1], parts[2]
                    if h_str not in entity2id:
                        entity2id[h_str] = len(entity2id)
                    if t_str not in entity2id:
                        entity2id[t_str] = len(entity2id)
                    if r_str not in rel2id:
                        rel2id[r_str] = len(rel2id)
                    srcs.append(entity2id[h_str])
                    dsts.append(entity2id[t_str])
                    rels.append(rel2id[r_str])
            splits_edges[split_key] = torch.tensor([srcs, dsts], dtype=torch.long)
            splits_rels[split_key] = torch.tensor(rels, dtype=torch.long)

        num_nodes = len(entity2id)
        num_relations = len(rel2id)
        data = Data(
            num_nodes=num_nodes,
            edge_index=splits_edges["train"],
            edge_type=splits_rels["train"],
            train_edge_index=splits_edges["train"],
            train_edge_type=splits_rels["train"],
            valid_edge_index=splits_edges["valid"],
            valid_edge_type=splits_rels["valid"],
            test_edge_index=splits_edges["test"],
            test_edge_type=splits_rels["test"],
        )
        data.num_relations = num_relations
        data.is_kg_dataset = True

        wrapper = self._standardize_kg_dataset(_SingleGraphDatasetWrapper(data), "FB15k")
        try:
            torch.save(wrapper[0], processed_file)
        except Exception:
            pass
        return wrapper

    def _standardize_kg_dataset(self, dataset: Any, name: str) -> _SingleGraphDatasetWrapper:
        """
        Standardizes Knowledge Graph datasets (FB15k, FB15k-237, WN18, WN18RR)
        so they expose consistent edge splits (`train_edge_index`, `valid_edge_index`,
        `test_edge_index`, `edge_type`, `num_relations`) and valid node-level
        attributes (`x`, `y`, `train_mask`, `val_mask`, `test_mask`) for unified
        node classification and link prediction (MRR, Hits@K) evaluation.
        """
        data = dataset[0].clone()
        num_nodes = int(data.num_nodes)
        data.is_kg_dataset = True

        # Case 1: WordNet18 / WordNet18RR where train_mask/val_mask/test_mask are 1D EDGE masks
        if (
            hasattr(data, "train_mask")
            and data.train_mask is not None
            and data.train_mask.numel() == data.edge_index.size(1)
            and data.train_mask.numel() != num_nodes
        ):
            train_e_mask = data.train_mask.bool()
            val_e_mask = data.val_mask.bool() if hasattr(data, "val_mask") and data.val_mask is not None else torch.zeros_like(train_e_mask)
            test_e_mask = data.test_mask.bool() if hasattr(data, "test_mask") and data.test_mask is not None else ~train_e_mask

            full_edge_index = data.edge_index
            full_edge_type = getattr(data, "edge_type", torch.zeros(full_edge_index.size(1), dtype=torch.long))

            data.train_edge_index = full_edge_index[:, train_e_mask]
            data.train_edge_type = full_edge_type[train_e_mask]
            data.valid_edge_index = full_edge_index[:, val_e_mask]
            data.valid_edge_type = full_edge_type[val_e_mask]
            data.test_edge_index = full_edge_index[:, test_e_mask]
            data.test_edge_type = full_edge_type[test_e_mask]

            # Use training triples for message passing to prevent test leakage
            data.edge_index = data.train_edge_index
            data.edge_type = data.train_edge_type
            data.num_relations = int(full_edge_type.max().item()) + 1 if full_edge_type.numel() > 0 else 1

            # Clear edge-sized masks so node-level masks can be generated cleanly
            del data.train_mask
            if hasattr(data, "val_mask"):
                del data.val_mask
            if hasattr(data, "test_mask"):
                del data.test_mask

        # Case 2: RelLinkPredDataset (FB15k-237) where train_edge_index/valid_edge_index/test_edge_index exist
        elif hasattr(data, "train_edge_index") and data.train_edge_index is not None:
            data.edge_index = data.train_edge_index
            data.edge_type = getattr(data, "train_edge_type", getattr(data, "edge_type", None))
            max_rel = 0
            for attr in ("train_edge_type", "valid_edge_type", "test_edge_type", "edge_type"):
                t = getattr(data, attr, None)
                if t is not None and t.numel() > 0:
                    max_rel = max(max_rel, int(t.max().item()) + 1)
            data.num_relations = max(1, max_rel)

        # Derive deterministic entity role/relation-domain class labels if `data.y` is absent
        if getattr(data, "y", None) is None or data.y.numel() != num_nodes:
            num_rel_classes = min(16, max(2, getattr(data, "num_relations", 2)))
            entity_labels = torch.zeros(num_nodes, dtype=torch.long)
            if data.edge_index is not None and data.edge_index.numel() > 0 and getattr(data, "edge_type", None) is not None:
                src, dst = data.edge_index[0], data.edge_index[1]
                rel_buckets = data.edge_type % num_rel_classes
                entity_labels[src] = rel_buckets
                entity_labels[dst] = rel_buckets
            data.y = entity_labels
            print(
                f"  [KG Dataset '{name}'] Assigned {num_rel_classes} relational-domain entity classes "
                f"(Nodes={num_nodes:,}, Train Triples={data.edge_index.size(1):,}, Relations={getattr(data, 'num_relations', 1)})."
            )

        if getattr(data, "x", None) is None:
            data.x = torch.arange(num_nodes, dtype=torch.long)
            data.is_featureless = True

        num_classes = int(data.y.max().item()) + 1
        return _SingleGraphDatasetWrapper(data, num_classes=num_classes)

    def _attach_reproducible_edge_splits(self, data: Data) -> Data:
        """Attaches 80/10/10 train/valid/test edge splits for MRR and Hits@K link evaluation."""
        num_edges = data.edge_index.size(1)
        gen = torch.Generator(device="cpu")
        gen.manual_seed(int(self.config.RANDOM_STATE))
        perm = torch.randperm(num_edges, generator=gen)
        n_train = int(0.8 * num_edges)
        n_val = int(0.1 * num_edges)
        train_idx = perm[:n_train]
        val_idx = perm[n_train:n_train + n_val]
        test_idx = perm[n_train + n_val:]

        data.train_edge_index = data.edge_index[:, train_idx]
        data.valid_edge_index = data.edge_index[:, val_idx]
        data.test_edge_index = data.edge_index[:, test_idx]

        if getattr(data, "edge_type", None) is not None and data.edge_type.numel() == num_edges:
            data.train_edge_type = data.edge_type[train_idx]
            data.valid_edge_type = data.edge_type[val_idx]
            data.test_edge_type = data.edge_type[test_idx]
        return data

    def _load_pyg_ppi_dataset(self, root_dir: Path) -> _SingleGraphDatasetWrapper:
        """
        Loads the canonical Protein-Protein Interaction (PPI) dataset from PyTorch Geometric
        (Zitnik & Leskovec, 2017; Hamilton et al., 2017 - GraphSAGE).
        Combines official train/val/test human tissue PPI subgraphs into a single Data object
        with exact train_mask/val_mask/test_mask and 1D dominant Gene Ontology (GO) functional class.
        """
        ppi_dir = root_dir / "PPI"
        processed_single = ppi_dir / "processed" / "ppi_unified_pyg.pt"
        if processed_single.exists():
            data = torch.load(processed_single, weights_only=False)
            num_classes = int(data.y.max().item()) + 1
            return _SingleGraphDatasetWrapper(data, num_classes=num_classes)

        train_ds = PPI(root=str(ppi_dir), split="train")
        val_ds = PPI(root=str(ppi_dir), split="val")
        test_ds = PPI(root=str(ppi_dir), split="test")

        all_graphs = list(train_ds) + list(val_ds) + list(test_ds)
        batched = Batch.from_data_list(all_graphs)

        n_train_nodes = sum(g.num_nodes for g in train_ds)
        n_val_nodes = sum(g.num_nodes for g in val_ds)
        total_nodes = batched.num_nodes

        train_mask = torch.zeros(total_nodes, dtype=torch.bool)
        val_mask = torch.zeros(total_nodes, dtype=torch.bool)
        test_mask = torch.zeros(total_nodes, dtype=torch.bool)
        train_mask[:n_train_nodes] = True
        val_mask[n_train_nodes:n_train_nodes + n_val_nodes] = True
        test_mask[n_train_nodes + n_val_nodes:] = True

        # Convert multi-label [N, 121] Gene Ontology targets into 1D dominant GO class index
        y_multi = batched.y
        if y_multi.dim() > 1:
            # Group into 10 major Gene Ontology functional modules for balanced multi-class evaluation
            num_go_Wait = y_multi.size(1)
            bucket_size = max(1, num_go_Wait // 10)
            go_scores = torch.stack(
                [y_multi[:, i * bucket_size:min(num_go_Wait, (i + 1) * bucket_size)].sum(dim=1) for i in range(10)],
                dim=1,
            )
            y_1d = go_scores.argmax(dim=1).long()
        else:
            y_1d = y_multi.long()

        data = Data(
            x=batched.x.float(),
            edge_index=batched.edge_index,
            y=y_1d,
            train_mask=train_mask,
            val_mask=val_mask,
            test_mask=test_mask,
        )
        data.y_multilabel = y_multi
        data.num_nodes = total_nodes
        data = self._attach_reproducible_edge_splits(data)

        (ppi_dir / "processed").mkdir(parents=True, exist_ok=True)
        try:
            torch.save(data, processed_single)
        except Exception:
            pass
        num_classes = int(data.y.max().item()) + 1
        print(f"  [Bio Dataset 'PPI'] Loaded {total_nodes:,} proteins, {data.edge_index.size(1):,} interactions, {num_classes} GO functional classes.")
        return _SingleGraphDatasetWrapper(data, num_classes=num_classes)

    def _load_biosnap_ppi_dataset(self, root_dir: Path) -> _SingleGraphDatasetWrapper:
        """
        Loads the Stanford BioSNAP Human Protein-Protein Interaction Network (PP-Pathways_ppi.csv.gz:
        21,557 human proteins, 342,353 physical interactions).
        """
        bio_dir = root_dir / "BioSNAP_PPI"
        processed_file = bio_dir / "processed" / "biosnap_ppi_pyg.pt"
        if processed_file.exists():
            data = torch.load(processed_file, weights_only=False)
            return _SingleGraphDatasetWrapper(data, num_classes=int(data.y.max().item()) + 1)

        raw_dir = bio_dir / "raw"
        raw_dir.mkdir(parents=True, exist_ok=True)
        (bio_dir / "processed").mkdir(parents=True, exist_ok=True)
        gz_path = raw_dir / "PP-Pathways_ppi.csv.gz"

        if not gz_path.exists() or gz_path.stat().st_size == 0:
            url = "https://snap.stanford.edu/biodata/datasets/10000/files/PP-Pathways_ppi.csv.gz"
            print(f"  [BioSNAP-PPI] Downloading human PPI network from {url} ...")
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=30) as resp:
                gz_path.write_bytes(resp.read())

        with gzip.open(gz_path, "rt", encoding="utf-8", errors="replace") as f:
            content = f.read()

        gene2id = {}
        srcs, dsts = [], []
        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(",")
            if len(parts) < 2:
                continue
            u_str, v_str = parts[0].strip(), parts[1].strip()
            if u_str not in gene2id:
                gene2id[u_str] = len(gene2id)
            if v_str not in gene2id:
                gene2id[v_str] = len(gene2id)
            u_id, v_id = gene2id[u_str], gene2id[v_str]
            srcs.append(u_id)
            dsts.append(v_id)

        num_nodes = len(gene2id)
        edge_index = torch.tensor([srcs, dsts], dtype=torch.long)

        # Assign functional hub/shell protein interaction classes (6-class log-degree stratification)
        deg = torch.bincount(edge_index[0], minlength=num_nodes) + torch.bincount(edge_index[1], minlength=num_nodes)
        log_deg = torch.log1p(deg.float())
        quantiles = torch.quantile(log_deg, torch.linspace(0, 1, 7)[1:-1])
        y = torch.bucketize(log_deg, quantiles).long()

        data = Data(
            x=torch.arange(num_nodes, dtype=torch.long),
            edge_index=edge_index,
            y=y,
            num_nodes=num_nodes,
        )
        data.is_featureless = True
        data = self._attach_reproducible_edge_splits(data)
        try:
            torch.save(data, processed_file)
        except Exception:
            pass
        num_classes = int(data.y.max().item()) + 1
        print(f"  [Bio Dataset 'BioSNAP-PPI'] Loaded {num_nodes:,} human proteins, {edge_index.size(1):,} physical PPI edges, {num_classes} classes.")
        return _SingleGraphDatasetWrapper(data, num_classes=num_classes)

    def _classify_disease_name(self, disease_name: str) -> int:
        """Maps UMLS disease names into 8 major biomedical disease families."""
        name_l = disease_name.lower()
        if any(k in name_l for k in ("neoplasm", "cancer", "carcinoma", "tumor", "sarcoma", "leukemia", "lymphoma", "melanoma", "glioma", "blastoma")):
            return 0  # Oncology / Neoplasms
        if any(k in name_l for k in ("neuro", "alzheimer", "parkinson", "epilep", "schizophren", "autism", "depress", "ataxia", "dementia", "sclerosis", "brain", "cerebr")):
            return 1  # Neurological & Psychiatric
        if any(k in name_l for k in ("cardio", "heart", "coronary", "hypertens", "arrhythm", "vascular", "ischemi", "stroke", "myocardi", "arter")):
            return 2  # Cardiovascular
        if any(k in name_l for k in ("diabet", "metabol", "obes", "thyroid", "lipid", "hyperglycem", "endocrine", "liver", "hepat", "renal", "kidney")):
            return 3  # Metabolic, Endocrine, Hepatic & Renal
        if any(k in name_l for k in ("immun", "asthma", "arthritis", "lupus", "crohn", "colitis", "inflam", "allerg", "psoriasis", "infect", "viral", "bacteri")):
            return 4  # Immune, Autoimmune & Infectious
        if any(k in name_l for k in ("syndrome", "congenital", "dystroph", "dysplasia", "malformation", "hereditary", "genetic")):
            return 5  # Congenital & Hereditary Syndromes
        if any(k in name_l for k in ("eye", "retinal", "macular", "glaucoma", "cataract", "deaf", "hearing", "skin", "dermat", "bone", "osteo")):
            return 6  # Sensory, Dermatological & Musculoskeletal
        return 7      # Other Systemic Pathologies

    def _load_gene_disease_dataset(self, root_dir: Path) -> _SingleGraphDatasetWrapper:
        """
        Loads the Stanford BioSNAP / DisGeNET Gene-Disease Association Network
        (DG-AssocMiner_miner-disease-gene.tsv.gz: 519 diseases, 7,294 genes, 21,357 associations)
        enriched with multi-relational gene-disease, disease-gene, co-disease gene-gene, and
        shared-gene disease-disease interactions, plus 8 biomedical disease-family classes.
        """
        gd_dir = root_dir / "GeneDisease"
        processed_file = gd_dir / "processed" / "gene_disease_pyg.pt"
        if processed_file.exists():
            data = torch.load(processed_file, weights_only=False)
            return _SingleGraphDatasetWrapper(data, num_classes=int(data.y.max().item()) + 1)

        raw_dir = gd_dir / "raw"
        raw_dir.mkdir(parents=True, exist_ok=True)
        (gd_dir / "processed").mkdir(parents=True, exist_ok=True)
        gz_path = raw_dir / "DG-AssocMiner_miner-disease-gene.tsv.gz"

        if not gz_path.exists() or gz_path.stat().st_size == 0:
            url = "https://snap.stanford.edu/biodata/datasets/10012/files/DG-AssocMiner_miner-disease-gene.tsv.gz"
            print(f"  [GeneDisease] Downloading DisGeNET gene-disease network from {url} ...")
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=30) as resp:
                gz_path.write_bytes(resp.read())

        with gzip.open(gz_path, "rt", encoding="utf-8", errors="replace") as f:
            content = f.read()

        node2id = {}
        node_classes = {}
        disease_to_genes = defaultdict(list)
        gene_to_diseases = defaultdict(list)
        gene_class_votes = defaultdict(lambda: defaultdict(int))

        srcs, dsts, rels = [], [], []
        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split("\t")
            if len(parts) < 3:
                continue
            d_id_raw, d_name, g_id_raw = parts[0].strip(), parts[1].strip().strip('"'), parts[2].strip()
            d_key = f"Disease::{d_id_raw}"
            g_key = f"Gene::{g_id_raw}"

            d_cls = self._classify_disease_name(d_name)
            if d_key not in node2id:
                node2id[d_key] = len(node2id)
                node_classes[node2id[d_key]] = d_cls
            if g_key not in node2id:
                node2id[g_key] = len(node2id)

            d_idx = node2id[d_key]
            g_idx = node2id[g_key]

            # Relation 0: Disease -> Gene (associates_DaG)
            srcs.append(d_idx)
            dsts.append(g_idx)
            rels.append(0)

            # Relation 1: Gene -> Disease (associated_with_GaD)
            srcs.append(g_idx)
            dsts.append(d_idx)
            rels.append(1)

            disease_to_genes[d_idx].append(g_idx)
            gene_to_diseases[g_idx].append(d_idx)
            gene_class_votes[g_idx][d_cls] += 1

        # Add Relation 2: Co-disease Gene -> Gene functional links (capped per disease to prevent clique blowup)
        for d_idx, g_list in disease_to_genes.items():
            for i in range(min(len(g_list) - 1, 25)):
                g_u, g_v = g_list[i], g_list[i + 1]
                if g_u != g_v:
                    srcs.extend([g_u, g_v])
                    dsts.extend([g_v, g_u])
                    rels.extend([2, 2])

        # Add Relation 3: Shared-gene Disease -> Disease comorbidity links
        for g_idx, d_list in gene_to_diseases.items():
            for i in range(min(len(d_list) - 1, 15)):
                d_u, d_v = d_list[i], d_list[i + 1]
                if d_u != d_v:
                    srcs.extend([d_u, d_v])
                    dsts.extend([d_v, d_u])
                    rels.extend([3, 3])

        num_nodes = len(node2id)
        y = torch.zeros(num_nodes, dtype=torch.long)
        for n_idx in range(num_nodes):
            if n_idx in node_classes:
                y[n_idx] = node_classes[n_idx]
            elif n_idx in gene_class_votes:
                votes = gene_class_votes[n_idx]
                y[n_idx] = max(votes.items(), key=lambda kv: kv[1])[0]

        edge_index = torch.tensor([srcs, dsts], dtype=torch.long)
        edge_type = torch.tensor(rels, dtype=torch.long)

        data = Data(
            x=torch.arange(num_nodes, dtype=torch.long),
            edge_index=edge_index,
            edge_type=edge_type,
            y=y,
            num_nodes=num_nodes,
        )
        data.num_relations = 4
        data.is_featureless = True
        data.is_kg_dataset = True
        data = self._attach_reproducible_edge_splits(data)
        try:
            torch.save(data, processed_file)
        except Exception:
            pass
        num_classes = int(data.y.max().item()) + 1
        print(
            f"  [Bio Dataset 'GeneDisease'] Loaded {num_nodes:,} nodes (519 diseases + 7,294 genes), "
            f"{edge_index.size(1):,} multi-relational edges (4 relation types), {num_classes} disease-family classes."
        )
        return _SingleGraphDatasetWrapper(data, num_classes=num_classes)

    def _load_disease_nc_dataset(self, root_dir: Path) -> _SingleGraphDatasetWrapper:
        """
        Loads the biological SIR Disease Propagation Network benchmark (Chami et al., NeurIPS 2019, HGCN:
        disease_nc.edges.csv & disease_nc.labels.npy).
        """
        dis_dir = root_dir / "Disease_NC"
        processed_file = dis_dir / "processed" / "disease_nc_pyg.pt"
        if processed_file.exists():
            data = torch.load(processed_file, weights_only=False)
            return _SingleGraphDatasetWrapper(data, num_classes=int(data.y.max().item()) + 1)

        raw_dir = dis_dir / "raw"
        raw_dir.mkdir(parents=True, exist_ok=True)
        (dis_dir / "processed").mkdir(parents=True, exist_ok=True)

        base_url = "https://raw.githubusercontent.com/HazyResearch/hgcn/master/data/disease_nc/"
        edges_path = raw_dir / "disease_nc.edges.csv"
        labels_path = raw_dir / "disease_nc.labels.npy"

        for fname, fpath in [("disease_nc.edges.csv", edges_path), ("disease_nc.labels.npy", labels_path)]:
            if not fpath.exists() or fpath.stat().st_size == 0:
                url = base_url + fname
                print(f"  [Disease-NC] Downloading {fname} from {url} ...")
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=30) as resp:
                    fpath.write_bytes(resp.read())

        srcs, dsts = [], []
        with open(edges_path, "r", encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split(",")
                if len(parts) >= 2:
                    srcs.append(int(parts[0]))
                    dsts.append(int(parts[1]))

        labels_np = np.load(str(labels_path))
        y = torch.from_numpy(labels_np).long().view(-1)
        num_nodes = int(y.numel())
        edge_index = torch.tensor([srcs, dsts], dtype=torch.long)

        data = Data(
            x=torch.arange(num_nodes, dtype=torch.long),
            edge_index=edge_index,
            y=y,
            num_nodes=num_nodes,
        )
        data.is_featureless = True
        data = self._attach_reproducible_edge_splits(data)
        try:
            torch.save(data, processed_file)
        except Exception:
            pass
        num_classes = int(data.y.max().item()) + 1
        print(f"  [Bio Dataset 'Disease'] Loaded {num_nodes:,} nodes, {edge_index.size(1):,} directed disease transmission edges, {num_classes} classes.")
        return _SingleGraphDatasetWrapper(data, num_classes=num_classes)

    def _load_hetionet_dataset(self, root_dir: Path) -> _SingleGraphDatasetWrapper:
        """
        Loads the Hetionet v1.0 Biomedical Knowledge Graph (Himmelstein et al., eLife 2017:
        47,031 biomedical entities across 11 entity types including Genes, Diseases, Compounds,
        Anatomy, and Pathways, connected by 24 relation types).
        """
        het_dir = root_dir / "Hetionet"
        processed_file = het_dir / "processed" / "hetionet_pyg.pt"
        if processed_file.exists():
            data = torch.load(processed_file, weights_only=False)
            return _SingleGraphDatasetWrapper(data, num_classes=int(data.y.max().item()) + 1)

        raw_dir = het_dir / "raw"
        raw_dir.mkdir(parents=True, exist_ok=True)
        (het_dir / "processed").mkdir(parents=True, exist_ok=True)

        nodes_path = raw_dir / "hetionet-v1.0-nodes.tsv"
        edges_path = raw_dir / "hetionet-v1.0-edges.sif.gz"

        if not nodes_path.exists() or nodes_path.stat().st_size == 0:
            url = "https://raw.githubusercontent.com/hetio/hetionet/master/hetnet/tsv/hetionet-v1.0-nodes.tsv"
            print(f"  [Hetionet] Downloading biomedical nodes from {url} ...")
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=30) as resp:
                nodes_path.write_bytes(resp.read())

        if not edges_path.exists() or edges_path.stat().st_size < 1000:
            url = "https://media.githubusercontent.com/media/hetio/hetionet/master/hetnet/tsv/hetionet-v1.0-edges.sif.gz"
            print(f"  [Hetionet] Downloading biomedical relation triples from {url} ...")
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=60) as resp:
                edges_path.write_bytes(resp.read())

        node2id = {}
        kind2id = {}
        y_list = []
        with open(nodes_path, "r", encoding="utf-8", errors="replace") as f:
            header = f.readline()
            for line in f:
                parts = line.strip().split("\t")
                if len(parts) < 3:
                    continue
                nid, _, kind = parts[0], parts[1], parts[2]
                if nid not in node2id:
                    node2id[nid] = len(node2id)
                    if kind not in kind2id:
                        kind2id[kind] = len(kind2id)
                    y_list.append(kind2id[kind])

        rel2id = {}
        srcs, dsts, rels = [], [], []
        with gzip.open(edges_path, "rt", encoding="utf-8", errors="replace") as f:
            header = f.readline()
            for line in f:
                parts = line.strip().split("\t")
                if len(parts) < 3:
                    continue
                u_str, metaedge, v_str = parts[0], parts[1], parts[2]
                if u_str not in node2id or v_str not in node2id:
                    continue
                if metaedge not in rel2id:
                    rel2id[metaedge] = len(rel2id)
                srcs.append(node2id[u_str])
                dsts.append(node2id[v_str])
                rels.append(rel2id[metaedge])

        num_nodes = len(node2id)
        edge_index = torch.tensor([srcs, dsts], dtype=torch.long)
        edge_type = torch.tensor(rels, dtype=torch.long)
        y = torch.tensor(y_list, dtype=torch.long)

        data = Data(
            x=torch.arange(num_nodes, dtype=torch.long),
            edge_index=edge_index,
            edge_type=edge_type,
            y=y,
            num_nodes=num_nodes,
        )
        data.num_relations = max(1, len(rel2id))
        data.is_featureless = True
        data.is_kg_dataset = True
        data = self._attach_reproducible_edge_splits(data)
        try:
            torch.save(data, processed_file)
        except Exception:
            pass
        num_classes = int(data.y.max().item()) + 1
        print(
            f"  [Bio Dataset 'Hetionet'] Loaded {num_nodes:,} biomedical entities, "
            f"{edge_index.size(1):,} triples across {data.num_relations} relation types, {num_classes} entity classes."
        )
        return _SingleGraphDatasetWrapper(data, num_classes=num_classes)

    def _get_dataset(self, name: str, **kwargs) -> Optional[Any]:
        """Loads a standard PyG, Biological Network, or Knowledge Graph dataset and enforces directed edges."""
        try:
            import inspect

            name_clean = name.strip()
            name_lower = name_clean.lower()

            # 1. Handle Knowledge Graph datasets (FB15k, FB15k-237, WN18, WN18RR, AIFB, MUTAG, BGS, AM)
            if name_lower == "fb15k":
                return self._load_fb15k_raw(Path(self.dataset_root))
            elif name_lower in ("fb15k-237", "fb15k_237"):
                ds = RelLinkPredDataset(root=str(Path(self.dataset_root) / "FB15k-237"), name="FB15k-237")
                return self._standardize_kg_dataset(ds, name_clean)
            elif name_lower in ("wn18", "wordnet18"):
                ds = WordNet18(root=str(Path(self.dataset_root) / "WN18"))
                return self._standardize_kg_dataset(ds, name_clean)
            elif name_lower in ("wn18rr", "wordnet18rr"):
                ds = WordNet18RR(root=str(Path(self.dataset_root) / "WN18RR"))
                return self._standardize_kg_dataset(ds, name_clean)
            elif name_clean.upper() in ("AIFB", "MUTAG", "BGS", "AM"):
                ds = Entities(root=str(Path(self.dataset_root) / name_clean.upper()), name=name_clean.upper())
                if hasattr(ds, "_data") and getattr(ds._data, "x", None) is None:
                    ds._data.x = torch.arange(ds._data.num_nodes, dtype=torch.long)
                    ds._data.is_featureless = True
                return ds

            # 2. Handle Biological Network datasets (PPI, BioSNAP-PPI, GeneDisease/DisGeNET, Disease, Hetionet, ogbn-proteins)
            if name_lower == "ppi":
                return self._load_pyg_ppi_dataset(Path(self.dataset_root))
            elif name_lower in ("biosnap-ppi", "biosnap_ppi", "pp-pathways", "huri-ppi", "human-ppi"):
                return self._load_biosnap_ppi_dataset(Path(self.dataset_root))
            elif name_lower in ("genedisease", "gene-disease", "gene_disease", "disgenet", "biosnap-genedisease", "dg-assocminer"):
                return self._load_gene_disease_dataset(Path(self.dataset_root))
            elif name_lower in ("disease", "disease-nc", "disease_nc", "disease-lp"):
                return self._load_disease_nc_dataset(Path(self.dataset_root))
            elif name_lower in ("hetionet", "biokg", "bio-hetionet"):
                return self._load_hetionet_dataset(Path(self.dataset_root))
            elif name_lower == "ogbn-proteins":
                try:
                    from ogb.nodeproppred import PygNodePropPredDataset
                    ds = PygNodePropPredDataset(name="ogbn-proteins", root=self.dataset_root)
                    data = ds[0].clone()
                    split_idx = ds.get_idx_split()
                    for mask_name, key in [("train_mask", "train"), ("val_mask", "valid"), ("test_mask", "test")]:
                        mask = torch.zeros(data.num_nodes, dtype=torch.bool)
                        mask[split_idx[key]] = True
                        setattr(data, mask_name, mask)
                    if data.y.dim() > 1:
                        data.y_multilabel = data.y
                        data.y = data.y.argmax(dim=1).long()
                    if getattr(data, "x", None) is None:
                        data.x = torch.arange(data.num_nodes, dtype=torch.long)
                        data.is_featureless = True
                    data = self._attach_reproducible_edge_splits(data)
                    return _SingleGraphDatasetWrapper(data, num_classes=int(data.y.max().item()) + 1)
                except ImportError:
                    print("  [ERROR] Please install 'ogb' via 'pip install ogb' to use ogbn-proteins.")
                    return None

            dataset_map = {
                'Cora': (Planetoid, {'name': name}),
                'CiteSeer': (Planetoid, {'name': name}),
                'PubMed': (Planetoid, {'name': name}),
                'Cornell': (WebKB, {'name': name}),
                'Texas': (WebKB, {'name': name}),
                'Wisconsin': (WebKB, {'name': name}),
                'Computers': (Amazon, {'name': name}),
                'Photo': (Amazon, {'name': name}),
                'CS': (Coauthor, {'name': name}),
                'Physics': (Coauthor, {'name': name}),
                'Chameleon': (WikipediaNetwork, {'name': name}),
                'Squirrel': (WikipediaNetwork, {'name': name}),
                'WikiCS': (WikiCS, {}),
                'Actor': (Actor, {}),
                'KarateClub': (KarateClub, {}),
                'BitcoinOTC': (BitcoinOTC, {}),
                'ego-twitter': (SNAPDataset, {'name': 'ego-twitter'}),
                'ego-gplus': (SNAPDataset, {'name': 'ego-gplus'}),
                'Cora_ML': (CitationFull, {'name': 'Cora_ML'}),
                'CiteSeer_Full': (CitationFull, {'name': 'CiteSeer'})
            }

            if name == 'ogbn-arxiv':
                try:
                    from ogb.nodeproppred import PygNodePropPredDataset
                    dataset = PygNodePropPredDataset(name='ogbn-arxiv', root=self.dataset_root)
                    return dataset
                except ImportError:
                    print("  [ERROR] Please install 'ogb' via 'pip install ogb' to use ogbn-arxiv.")
                    return None

            if name not in dataset_map:
                raise ValueError(f"Dataset '{name}' not recognized.")

            cls, default_kwargs = dataset_map[name]

            # Generically enforce directed edges if the dataset class supports it
            sig = inspect.signature(cls.__init__)
            if 'is_undirected' in sig.parameters:
                kwargs['is_undirected'] = False
            if 'to_undirected' in sig.parameters:
                kwargs['to_undirected'] = False

            final_kwargs = {**default_kwargs, **kwargs}

            if cls is KarateClub:
                dataset = cls(**final_kwargs)
            else:
                dataset = cls(root=self.dataset_root, **final_kwargs)

            # If dataset has no features (common for social/trust networks), generate dummy features
            if hasattr(dataset, '_data') and getattr(dataset._data, 'x', None) is None:
                print(f"  [WARNING] Dataset '{name}' has no node features. Generating an identity matrix for one-hot node features.")
                dataset._data.x = torch.arange(dataset._data.num_nodes, dtype=torch.long)
                dataset._data.is_featureless = True

            return dataset

        except Exception as e:
            print(f"  Error loading dataset '{name}': {e.__class__.__name__}: {e}")
            return None

    def _get_1d_mask(self, mask_tensor: torch.Tensor) -> torch.Tensor:
        """Helper to handle masks from datasets that may have multiple splits (e.g., WebKB)."""
        return mask_tensor[:, 0].bool() if mask_tensor.dim() > 1 else mask_tensor.bool()

    @abstractmethod
    def run(self) -> pd.DataFrame:
        """Main execution function for the benchmarker."""
        raise NotImplementedError
