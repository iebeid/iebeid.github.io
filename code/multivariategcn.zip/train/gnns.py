# ==============================================================================
# MODULE: benchmarkers/gnns.py
# PURPOSE: Handles benchmarking of various GNN models on standard datasets.
# VERSION: 5.3 (Configurable homophily sampling: coin_flip vs cosine_similarity)
# AUTHOR: Islam Ebeid
# ==============================================================================

import os
import gc
import time
import traceback
import math
from typing import Dict, List, Any, Tuple, Optional
import mlflow
from pathlib import Path
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from sklearn.metrics import f1_score, precision_score, recall_score, accuracy_score
from torch_geometric.data import Data
from torch_geometric.utils import add_self_loops, degree, subgraph, negative_sampling, coalesce
from configuration.config import Config
from train.base import BaseBenchmarker
# from source.utils.fs.file_utils import FileUtils
from models.factory import ModelFactory


# from source.utils.data.data_utils import DataUtils
# --- DEFINITIVE FIX: Import the Network Embedding Benchmarker ---
# from source.benchmarkers.nes import NetworkEmbeddingBenchmarker


def focal_loss(logits, targets, alpha=1.0, gamma=2.0):
    ce_loss = F.cross_entropy(logits, targets, reduction='none')
    pt = torch.exp(-ce_loss)
    focal_loss = alpha * (1 - pt) ** gamma * ce_loss
    return focal_loss.mean()


class GNNBenchmarker(BaseBenchmarker):
    def __init__(self, config: Config):
        super().__init__(config, "GNN Benchmarker")
        self.embedding_dir = config.RESULTS_BENCHMARK_EMBEDDINGS_DIR
        self.model_factory = ModelFactory(config, context='benchmark')
        print(f"Benchmark embeddings will be saved to: {self.embedding_dir}")

    def _save_embeddings(self, model: torch.nn.Module, data: Data):
        """Extracts and saves GNN node embeddings to an H5 file."""
        print(f"    Extracting embeddings for {model.__class__.__name__}...")
        with torch.no_grad():
            model.eval()
            model_out = model(data)
            embeddings = model_out[-1]  # Always the last element
            
        if embeddings is None:
            print("    Warning: Could not extract embeddings.")
            return

        embeddings_np = embeddings.cpu().numpy()
        emb_dim = embeddings_np.shape[1]
        
        # --- Apply PCA if required ---
        target_dim = self.config.BENCHMARK_PCA_TARGET_DIM
        if target_dim and target_dim < emb_dim:
            print(f"      Applying PCA to reduce embeddings from {emb_dim} to {target_dim}...")
            from sklearn.decomposition import PCA
            pca = PCA(n_components=target_dim, random_state=self.config.RANDOM_STATE)
            embeddings_np = pca.fit_transform(embeddings_np)
            emb_dim = target_dim

        emb_dict = {str(i): embeddings_np[i] for i in range(embeddings_np.shape[0])}

        # Construct the full path for the output file
        dataset_name = getattr(data, 'name', 'unknown_dataset')
        model_name = model.__class__.__name__
        variant_suffix = getattr(data, 'variant_suffix', None)

        base_name = f"{model_name}_embeddings_dim{emb_dim}" if not variant_suffix else f"{model_name}_{variant_suffix}_embeddings_dim{emb_dim}"
        h5_filename = f"{base_name}.h5"
        full_h5_path = self.embedding_dir / dataset_name / h5_filename

        full_h5_path.parent.mkdir(parents=True, exist_ok=True)
        import h5py
        with h5py.File(full_h5_path, 'w') as f:
            for k, v in emb_dict.items():
                f.create_dataset(k, data=v)
        
        print(f"      Saved embeddings to {full_h5_path}")

    def _compute_directgcn_losses(self, model, h_emb, batch_data, train_mask, logits):
        target = batch_data.y[train_mask].long()
        loss_cls = F.cross_entropy(logits[train_mask], target)

        # 1. Link Existence Loss
        pos_edge_index = batch_data.edge_index
        neg_edge_index = negative_sampling(
            edge_index=pos_edge_index,
            num_nodes=batch_data.num_nodes,
            num_neg_samples=int(pos_edge_index.size(1) * self.config.BENCHMARK_NEGATIVE_SAMPLING_RATIO)
        )
        edge_index_all = torch.cat([pos_edge_index, neg_edge_index], dim=-1)
        pred_exist = model.predict_exist(h_emb, edge_index_all)
        true_exist = torch.cat([torch.ones(pos_edge_index.size(1)), torch.zeros(neg_edge_index.size(1))]).to(h_emb.device)
        loss_exist = F.binary_cross_entropy_with_logits(pred_exist, true_exist)

        # 2. Link Similarity Loss
        row, col = pos_edge_index
        valid_edge_mask = train_mask[row] & train_mask[col]
        valid_sim_edges = pos_edge_index[:, valid_edge_mask]
        if valid_sim_edges.size(1) > 0:
            pred_sim = model.predict_sim(h_emb, valid_sim_edges)
            true_sim = (batch_data.y[valid_sim_edges[0]] == batch_data.y[valid_sim_edges[1]]).float()
            loss_sim = F.binary_cross_entropy_with_logits(pred_sim, true_sim)
        else:
            loss_sim = torch.tensor(0.0, device=h_emb.device, requires_grad=True)

        # 3. Edge Directionality Loss
        pos_dir_edge_index = getattr(batch_data, 'edge_index_mathcal_out_raw', None)
        if pos_dir_edge_index is None:
            pos_dir_edge_index = pos_edge_index
        neg_dir_edge_index = pos_dir_edge_index.flip([0])
        all_dir_edges = torch.cat([pos_dir_edge_index, neg_dir_edge_index], dim=-1)
        pred_dir = model.predict_dir(h_emb, all_dir_edges)
        true_dir = torch.cat([torch.ones(pos_dir_edge_index.size(1)), torch.zeros(neg_dir_edge_index.size(1))]).to(h_emb.device)
        loss_dir = F.binary_cross_entropy_with_logits(pred_dir, true_dir)

        # 4. Edge Cyclicity (Reciprocity) Loss
        pos_cyc_edge_index = getattr(batch_data, 'edge_index_cyclic_raw', getattr(batch_data, 'edge_index_cyclic', None))
        neg_cyc_edge_index = getattr(batch_data, 'edge_index_acyclic_raw', getattr(batch_data, 'edge_index_acyclic', None))
        if pos_cyc_edge_index is not None and neg_cyc_edge_index is not None and (pos_cyc_edge_index.size(1) + neg_cyc_edge_index.size(1)) > 0:
            all_cyc_edges = torch.cat([pos_cyc_edge_index, neg_cyc_edge_index], dim=-1)
            pred_cyc = model.predict_cyc(h_emb, all_cyc_edges)
            true_cyc = torch.cat([
                torch.ones(pos_cyc_edge_index.size(1), device=h_emb.device),
                torch.zeros(neg_cyc_edge_index.size(1), device=h_emb.device)
            ])
            loss_cyc = F.binary_cross_entropy_with_logits(pred_cyc, true_cyc)
        else:
            loss_cyc = torch.tensor(0.0, device=h_emb.device, requires_grad=True)

        # Normalize weights to sum to 1
        w_cls = getattr(self.config, 'LOSS_WEIGHT_CLS', 0.4)
        w_exist = getattr(self.config, 'LOSS_WEIGHT_EXIST', 0.2)
        w_sim = getattr(self.config, 'LOSS_WEIGHT_SIM', 0.2)
        w_dir = getattr(self.config, 'LOSS_WEIGHT_DIR', 0.2)
        w_cyc = getattr(self.config, 'LOSS_WEIGHT_CYC', 0.2)
        
        w_total = w_cls + w_exist + w_sim + w_dir + w_cyc
        if w_total > 0:
            w_cls, w_exist, w_sim, w_dir, w_cyc = w_cls/w_total, w_exist/w_total, w_sim/w_total, w_dir/w_total, w_cyc/w_total

        total_loss = (w_cls * loss_cls) + (w_exist * loss_exist) + (w_sim * loss_sim) + (w_dir * loss_dir) + (w_cyc * loss_cyc)
        avg_link_loss = (loss_exist + loss_sim + loss_dir + loss_cyc) / 4.0
        
        return total_loss, loss_cls, avg_link_loss

    def _score_edges_for_model(
        self,
        model: torch.nn.Module,
        model_eval_out: Any,
        edge_index: torch.Tensor,
        edge_type: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, bool]:
        """
        Scores candidate edges/triples `(s, r, o)` for any model in the benchmark.
        Returns `(scores, uses_logit_threshold)` where `uses_logit_threshold` is True
        if the model's link scorer is trained with binary cross-entropy logits around 0.
        """
        base_mdl = getattr(model, "base_model", model)
        is_directgcn = hasattr(base_mdl, "path_names") and hasattr(base_mdl, "predict_exist")

        if is_directgcn and isinstance(model_eval_out, tuple) and len(model_eval_out) == 3:
            h1_eval = model_eval_out[1]
            return base_mdl.predict_exist(h1_eval, edge_index), True

        h_eval = model_eval_out[-1] if isinstance(model_eval_out, tuple) else model_eval_out
        if hasattr(base_mdl, "score_triples"):
            uses_bce = hasattr(base_mdl, "compute_kge_loss")
            return base_mdl.score_triples(h_eval, edge_index, edge_type), uses_bce
        if hasattr(base_mdl, "predict_exist"):
            return base_mdl.predict_exist(h_eval, edge_index), False

        # Fallback for standard GNNs (GCN, GAT, GraphSAGE, ChebNet, DirGNN, GTN): cosine similarity
        h_norm = F.normalize(h_eval, p=2.0, dim=-1)
        src, dst = edge_index[0], edge_index[1]
        return (h_norm[src] * h_norm[dst]).sum(dim=-1), False

    def _evaluate_link_metrics(
        self,
        model: torch.nn.Module,
        model_eval_out: Any,
        data: Data,
    ) -> Dict[str, float]:
        """
        Computes Link Prediction Accuracy, Mean Reciprocal Rank (MRR), and Hits@K
        (e.g., Hits@1, Hits@3, Hits@10) across ALL models using negative corruptions.
        """
        hits_k_list = getattr(self.config, "BENCHMARK_HITS_AT_K", [1, 3, 10])
        eval_mrr = getattr(self.config, "BENCHMARK_EVAL_MRR", True)
        num_neg_per_pos = int(getattr(self.config, "BENCHMARK_MRR_NUM_NEGATIVES", 100))
        max_eval_triples = int(getattr(self.config, "BENCHMARK_MRR_MAX_EVAL_TRIPLES", 2048))

        result = {"Link_Pred_Accuracy": 0.0, "MRR": 0.0}
        for k in hits_k_list:
            result[f"Hits@{int(k)}"] = 0.0

        # Select positive test triples/edges
        if hasattr(data, "test_edge_index") and data.test_edge_index is not None and data.test_edge_index.numel() > 0:
            pos_edge_index = data.test_edge_index.to(self.device)
            pos_edge_type = getattr(data, "test_edge_type", None)
            if pos_edge_type is not None:
                pos_edge_type = pos_edge_type.to(self.device)
        else:
            raw_edges = getattr(data, "edge_index_mathcal_out_raw", data.edge_index)
            raw_types = getattr(data, "edge_type", None)
            if hasattr(data, "test_mask") and data.test_mask is not None:
                test_mask = self._get_1d_mask(data.test_mask).to(raw_edges.device)
                edge_mask = test_mask[raw_edges[0]] | test_mask[raw_edges[1]]
                if int(edge_mask.sum().item()) > 0:
                    pos_edge_index = raw_edges[:, edge_mask]
                    pos_edge_type = raw_types[edge_mask] if (raw_types is not None and raw_types.numel() == raw_edges.size(1)) else None
                else:
                    pos_edge_index = raw_edges
                    pos_edge_type = raw_types if (raw_types is not None and raw_types.numel() == raw_edges.size(1)) else None
            else:
                pos_edge_index = raw_edges
                pos_edge_type = raw_types if (raw_types is not None and raw_types.numel() == raw_edges.size(1)) else None

        num_pos = pos_edge_index.size(1)
        if num_pos == 0 or data.num_nodes <= 1:
            return result

        # Deterministic subsampling of evaluation triples for speed & reproducibility
        if num_pos > max_eval_triples:
            gen = torch.Generator(device="cpu")
            gen.manual_seed(int(self.config.RANDOM_STATE))
            perm = torch.randperm(num_pos, generator=gen)[:max_eval_triples].to(pos_edge_index.device)
            eval_pos_edges = pos_edge_index[:, perm]
            eval_pos_types = pos_edge_type[perm] if pos_edge_type is not None else None
        else:
            eval_pos_edges = pos_edge_index
            eval_pos_types = pos_edge_type

        num_eval = eval_pos_edges.size(1)
        pos_scores, uses_logit_threshold = self._score_edges_for_model(
            model, model_eval_out, eval_pos_edges, eval_pos_types
        )

        # 1. Link Prediction Binary Accuracy (1:1 positive vs negative)
        neg_1to1 = negative_sampling(
            edge_index=data.edge_index,
            num_nodes=data.num_nodes,
            num_neg_samples=num_eval,
        )
        if neg_1to1.size(1) < num_eval:
            gen_neg = torch.Generator(device="cpu")
            gen_neg.manual_seed(int(self.config.RANDOM_STATE) + 13)
            neg_1to1 = torch.randint(0, data.num_nodes, (2, num_eval), generator=gen_neg).to(self.device)
        else:
            neg_1to1 = neg_1to1[:, :num_eval].to(self.device)

        neg_1to1_scores, _ = self._score_edges_for_model(
            model, model_eval_out, neg_1to1, eval_pos_types
        )

        if uses_logit_threshold:
            all_scores = torch.cat([pos_scores, neg_1to1_scores], dim=0)
            all_labels = torch.cat(
                [torch.ones_like(pos_scores), torch.zeros_like(neg_1to1_scores)], dim=0
            )
            link_acc = float(((all_scores > 0.0).float() == all_labels).float().mean().item())
        else:
            # For cosine/dot-product embeddings, evaluate calibrated threshold (median/mean) or pairwise accuracy
            threshold = 0.5 * (pos_scores.mean() + neg_1to1_scores.mean())
            all_scores = torch.cat([pos_scores, neg_1to1_scores], dim=0)
            all_labels = torch.cat(
                [torch.ones_like(pos_scores), torch.zeros_like(neg_1to1_scores)], dim=0
            )
            link_acc = float(((all_scores > threshold).float() == all_labels).float().mean().item())
        result["Link_Pred_Accuracy"] = link_acc

        if not eval_mrr:
            return result

        # 2. Filtered/Corrupted Ranking Evaluation for MRR and Hits@K
        gen_rank = torch.Generator(device="cpu")
        gen_rank.manual_seed(int(self.config.RANDOM_STATE) + 99)

        # Corrupt tails for half, corrupt heads for half (standard KGE protocol)
        rand_entities = torch.randint(
            0, data.num_nodes, (num_eval, num_neg_per_pos), generator=gen_rank
        ).to(self.device)
        corrupt_head_mask = (
            torch.rand((num_eval, num_neg_per_pos), generator=gen_rank).to(self.device) < 0.5
        )

        pos_src_exp = eval_pos_edges[0].unsqueeze(1).expand(num_eval, num_neg_per_pos)
        pos_dst_exp = eval_pos_edges[1].unsqueeze(1).expand(num_eval, num_neg_per_pos)

        neg_src = torch.where(corrupt_head_mask, rand_entities, pos_src_exp)
        neg_dst = torch.where(corrupt_head_mask, pos_dst_exp, rand_entities)

        # Avoid accidental self-collision with the exact positive triple
        same_as_pos = (neg_src == pos_src_exp) & (neg_dst == pos_dst_exp)
        if same_as_pos.any():
            neg_dst = torch.where(same_as_pos, (neg_dst + 1) % data.num_nodes, neg_dst)

        flat_neg_edges = torch.stack([neg_src.reshape(-1), neg_dst.reshape(-1)], dim=0)
        flat_neg_types = (
            eval_pos_types.unsqueeze(1).expand(num_eval, num_neg_per_pos).reshape(-1)
            if eval_pos_types is not None
            else None
        )

        # Score negative triples in chunks to bound GPU memory
        chunk_size = 32768
        neg_scores_list = []
        total_neg = flat_neg_edges.size(1)
        for start_idx in range(0, total_neg, chunk_size):
            end_idx = min(start_idx + chunk_size, total_neg)
            chunk_edges = flat_neg_edges[:, start_idx:end_idx]
            chunk_types = flat_neg_types[start_idx:end_idx] if flat_neg_types is not None else None
            c_scores, _ = self._score_edges_for_model(model, model_eval_out, chunk_edges, chunk_types)
            neg_scores_list.append(c_scores)

        neg_scores = torch.cat(neg_scores_list, dim=0).view(num_eval, num_neg_per_pos)
        pos_scores_col = pos_scores.unsqueeze(1)

        # Realistic rank: 1 + #strictly_greater + 0.5 * #ties
        num_greater = (neg_scores > pos_scores_col).float().sum(dim=1)
        num_equal = ( (neg_scores - pos_scores_col).abs() <= 1e-7 ).float().sum(dim=1)
        ranks = 1.0 + num_greater + 0.5 * num_equal

        result["MRR"] = float((1.0 / ranks).mean().item())
        for k in hits_k_list:
            k_int = int(k)
            result[f"Hits@{k_int}"] = float((ranks <= float(k_int)).float().mean().item())

        return result

    def _train_and_evaluate(self, model: torch.nn.Module, data: Data,
                            epochs_override: Optional[int] = None,
                            lr_override: Optional[float] = None,
                            wd_override: Optional[float] = None) -> Tuple[Dict[str, float], pd.DataFrame]:
        """Handles the training and evaluation loop for a given model and data."""
        model.to(self.device)
        data = data.to(self.device)
        lr = lr_override if lr_override is not None else self.config.BENCHMARK_GNN_LEARNING_RATE
        wd = wd_override if wd_override is not None else self.config.BENCHMARK_GNN_WEIGHT_DECAY
        optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=wd)

        best_val_acc = -1
        test_acc_at_best_val = -1
        # --- DEFINITIVE FIX for UnboundLocalError ---
        # Initialize metrics to a default value before the loop.
        f1_at_best_val = -1.0
        precision_at_best_val = -1.0
        recall_at_best_val = -1.0
        link_acc_at_best_val = 0.0
        hits_k_list = getattr(self.config, 'BENCHMARK_HITS_AT_K', [1, 3, 10])
        best_link_metrics: Dict[str, float] = {
            'Link_Pred_Accuracy': 0.0,
            'MRR': 0.0,
            **{f'Hits@{int(k)}': 0.0 for k in hits_k_list},
        }
        history = {
            'epoch': [], 'loss': [], 'val_acc': [], 'test_acc': [],
            'val_link_acc': [], 'test_link_acc': [], 'test_mrr': [],
            **{f'test_hits@{int(k)}': [] for k in hits_k_list},
        }

        train_mask = self._get_1d_mask(data.train_mask)
        val_mask = self._get_1d_mask(data.val_mask)
        test_mask = self._get_1d_mask(data.test_mask)

        total_epochs = int(epochs_override) if epochs_override is not None else int(self.config.BENCHMARK_GNN_EPOCHS)
        start_time = time.time()
        
        # --- Automated Clustering Logic ---
        use_clustering = data.num_nodes > self.config.BENCHMARK_SUBGRAPH_NODES_N
        if use_clustering:
            loader_type = getattr(self.config, 'BENCHMARK_SUBGRAPH_LOADER_TYPE', 'bfs').lower()
            
            if loader_type == 'cluster':
                print(f"    [Training] Graph is large ({data.num_nodes} > {self.config.BENCHMARK_SUBGRAPH_NODES_N}).")
                print(f"    [Training] Using PyTorch Geometric ClusterLoader.")
                from torch_geometric.loader import ClusterData, ClusterLoader
                # Partition the graph into num_parts
                num_parts = max(1, data.num_nodes // self.config.BENCHMARK_SUBGRAPH_NODES_N)
                # We need to temporarily move data to cpu for ClusterData, then loader handles it
                cpu_data = data.clone().cpu()
                cluster_data = ClusterData(cpu_data, num_parts=num_parts, recursive=False, save_dir=None)
                cluster_loader = ClusterLoader(cluster_data, batch_size=1, shuffle=True, num_workers=0)
            else:
                # Dynamically calculate number of batches based on graph size
                oversample_factor = 2.0 # Ensure we cover the graph ~2 times per epoch
                optimal_batches = max(1, int(math.ceil((data.num_nodes * oversample_factor) / self.config.BENCHMARK_SUBGRAPH_NODES_N)))
                
                # Cap it at a user-defined max to prevent memory/time explosion on massive datasets
                num_batches_to_use = min(optimal_batches, self.config.BENCHMARK_SUBGRAPH_BATCHES_M)
                
                print(f"    [Training] Graph is large ({data.num_nodes} > {self.config.BENCHMARK_SUBGRAPH_NODES_N}).")
                print(f"    [Training] Dynamically scaled to {num_batches_to_use} batches/epoch (Max: {self.config.BENCHMARK_SUBGRAPH_BATCHES_M}).")
                from utils.graph_utils import StratifiedConnectedSubgraphLoader
                cluster_loader = StratifiedConnectedSubgraphLoader(
                    data, 
                    batch_size=self.config.BENCHMARK_SUBGRAPH_NODES_N,
                    num_batches=num_batches_to_use,
                    bfs_root_ratio=self.config.BENCHMARK_SUBGRAPH_BFS_ROOT_RATIO
                )
        else:
            print(f"    [Training] Graph is small ({data.num_nodes} <= {self.config.BENCHMARK_SUBGRAPH_NODES_N}). Using Full Batch Training.")
            cluster_loader = None
            
        global_sampled_mask = torch.zeros(data.num_nodes, dtype=torch.bool, device=self.device)
        
        pbar = None

        for epoch in range(1, total_epochs + 1):
            model.train()
            is_directgcn = hasattr(model, 'path_names') and hasattr(model, 'predict_exist')
            
            epoch_loss = 0.0
            epoch_loss_cls = 0.0
            epoch_loss_link = 0.0
            
            if cluster_loader is not None:
                num_batches = len(cluster_loader)
                valid_batches = 0
                optimizer.zero_grad()
                
                for batch_data in cluster_loader:
                    batch_data = batch_data.to(self.device)
                    indices = getattr(batch_data, 'original_indices', getattr(batch_data, 'n_id', getattr(batch_data, 'node_id', None)))
                    if indices is not None:
                        global_sampled_mask[indices] = True
                    
                    batch_train_mask = self._get_1d_mask(batch_data.train_mask)
                    if batch_train_mask.sum() == 0:
                        continue
                        
                    # --- Subgraph Interception for Custom Edge Indices ---
                    base_mdl_cls = getattr(model, 'base_model', model).__class__.__name__
                    if is_directgcn or base_mdl_cls in ('DirGNN', 'RGCN', 'DistMult', 'ComplEx', 'MetaPath2Vec'):
                        if hasattr(batch_data, 'edge_index_mathcal_out_raw'):
                            batch_data.edge_index = batch_data.edge_index_mathcal_out_raw
                            batch_data.edge_attr = None
                        for attr in ['edge_index_backward', 'edge_index_mathcal_in', 'edge_index_mathcal_out', 
                                     'edge_index_undirected_norm', 'edge_index_homophilic', 'edge_index_heterophilic',
                                     'edge_index_mathcal_in_raw', 'edge_index_mathcal_out_raw', 'edge_index_undirected_norm_raw',
                                     'edge_index_homophilic_raw', 'edge_index_heterophilic_raw',
                                     'edge_index_cyclic', 'edge_index_acyclic',
                                     'edge_index_cyclic_raw', 'edge_index_acyclic_raw']:
                            if hasattr(batch_data, attr):
                                delattr(batch_data, attr)
                        
                        batch_data = self._prepare_data_for_model(
                            base_mdl_cls,
                            batch_data,
                            verbose=False,
                            homophily_sampling=getattr(data, 'homophily_sampling', None)
                        )
                        batch_data = batch_data.to(self.device)
                        
                    valid_batches += 1
                    model_out = model(batch_data)
                    if is_directgcn and len(model_out) == 3:
                        logits, h1, h2 = model_out
                        loss, loss_cls, avg_link_loss = self._compute_directgcn_losses(model, h1, batch_data, batch_train_mask, logits)
                        
                        loss = loss / num_batches
                        epoch_loss_cls += loss_cls.item()
                        epoch_loss_link += avg_link_loss.item()
                    else:
                        logits, h_emb = model_out if isinstance(model_out, tuple) else (model_out, None)
                        target = batch_data.y[batch_train_mask].long()
                        loss_cls = F.cross_entropy(logits[batch_train_mask], target)
                        base_mdl = getattr(model, 'base_model', model)
                        if hasattr(base_mdl, 'compute_kge_loss') and h_emb is not None:
                            loss_aux = base_mdl.compute_kge_loss(h_emb, batch_data)
                            loss = 0.5 * loss_cls + 0.5 * loss_aux
                            epoch_loss_link += loss_aux.item()
                        elif hasattr(base_mdl, 'compute_unsup_loss') and h_emb is not None:
                            loss_aux = base_mdl.compute_unsup_loss(h_emb, batch_data)
                            loss = 0.5 * loss_cls + 0.5 * loss_aux
                            epoch_loss_link += loss_aux.item()
                        else:
                            loss = loss_cls
                        loss = loss / num_batches
                        epoch_loss_cls += loss_cls.item()
                        
                    loss.backward()
                    epoch_loss += loss.item() * num_batches
                    
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=self.config.BENCHMARK_GRADIENT_CLIPPING_NORM)
                optimizer.step()
                loss_val = epoch_loss / valid_batches if valid_batches > 0 else 0.0
                epoch_loss_cls = epoch_loss_cls / valid_batches if valid_batches > 0 else 0.0
                epoch_loss_link = epoch_loss_link / valid_batches if valid_batches > 0 else 0.0
            else:
                optimizer.zero_grad()
                model_out = model(data)
                if is_directgcn and len(model_out) == 3:
                    logits, h1, h2 = model_out
                    loss, loss_cls, avg_link_loss = self._compute_directgcn_losses(model, h1, data, train_mask, logits)
                    epoch_loss_cls = loss_cls.item()
                    epoch_loss_link = avg_link_loss.item()
                else:
                    logits, h_emb = model_out if isinstance(model_out, tuple) else (model_out, None)
                    target = data.y[train_mask].long()
                    loss_cls = F.cross_entropy(logits[train_mask], target)
                    base_mdl = getattr(model, 'base_model', model)
                    if hasattr(base_mdl, 'compute_kge_loss') and h_emb is not None:
                        loss_aux = base_mdl.compute_kge_loss(h_emb, data)
                        loss = 0.5 * loss_cls + 0.5 * loss_aux
                        epoch_loss_link = loss_aux.item()
                    elif hasattr(base_mdl, 'compute_unsup_loss') and h_emb is not None:
                        loss_aux = base_mdl.compute_unsup_loss(h_emb, data)
                        loss = 0.5 * loss_cls + 0.5 * loss_aux
                        epoch_loss_link = loss_aux.item()
                    else:
                        loss = loss_cls
                        epoch_loss_link = 0.0
                    epoch_loss_cls = loss_cls.item()
                    
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=self.config.BENCHMARK_GRADIENT_CLIPPING_NORM)
                optimizer.step()
                loss_val = loss.item()

            if epoch == 1 or epoch % self.config.BENCHMARK_EVAL_FREQUENCY == 0 or epoch == total_epochs:
                model.eval()
                torch.cuda.empty_cache()
                with torch.no_grad():
                    model_eval_out = model(data)
                    logits_eval = model_eval_out[0] if isinstance(model_eval_out, tuple) else model_eval_out
                    # Full graph evaluation already handles all nodes inductively

                    pred = logits_eval.argmax(dim=1)
                    val_correct = (pred[val_mask] == data.y[val_mask]).sum()
                    val_acc = int(val_correct) / int(val_mask.sum()) if val_mask.sum() > 0 else 0.0
                    test_correct = (pred[test_mask] == data.y[test_mask]).sum()
                    test_acc = int(test_correct) / int(test_mask.sum()) if test_mask.sum() > 0 else 0.0
                    
                    # Link Prediction & Ranking Evaluation (MRR, Hits@K, Link_Pred_Accuracy) for ALL models
                    link_metrics = self._evaluate_link_metrics(model, model_eval_out, data)
                    val_link_acc = link_metrics.get('Link_Pred_Accuracy', 0.0)
                    test_link_acc = val_link_acc
                    test_mrr = link_metrics.get('MRR', 0.0)

            else:
                val_acc = history['val_acc'][-1] if len(history['val_acc']) > 0 else 0.0
                test_acc = history['test_acc'][-1] if len(history['test_acc']) > 0 else 0.0
                val_link_acc = history['val_link_acc'][-1] if len(history['val_link_acc']) > 0 else 0.0
                test_link_acc = history['test_link_acc'][-1] if len(history['test_link_acc']) > 0 else 0.0
                test_mrr = history['test_mrr'][-1] if len(history['test_mrr']) > 0 else 0.0
                link_metrics = {
                    'Link_Pred_Accuracy': test_link_acc,
                    'MRR': test_mrr,
                    **{
                        f'Hits@{int(k)}': (history[f'test_hits@{int(k)}'][-1] if len(history[f'test_hits@{int(k)}']) > 0 else 0.0)
                        for k in hits_k_list
                    },
                }

            history['epoch'].append(epoch)
            history['loss'].append(loss_val)
            history['val_acc'].append(val_acc)
            history['test_acc'].append(test_acc)
            history['val_link_acc'].append(val_link_acc)
            history['test_link_acc'].append(test_link_acc)
            history['test_mrr'].append(test_mrr)
            for k in hits_k_list:
                history[f'test_hits@{int(k)}'].append(link_metrics.get(f'Hits@{int(k)}', 0.0))

            if val_acc > best_val_acc:
                best_val_acc = val_acc
                test_acc_at_best_val = test_acc
                link_acc_at_best_val = test_link_acc
                best_link_metrics = dict(link_metrics)
                # --- Capture all test metrics at the best validation epoch ---
                y_true_test = data.y[test_mask].cpu().numpy()
                y_pred_test = pred[test_mask].cpu().numpy()
                f1_at_best_val = f1_score(y_true_test, y_pred_test, average='macro', zero_division=0)
                precision_at_best_val = precision_score(y_true_test, y_pred_test, average='macro', zero_division=0)
                recall_at_best_val = recall_score(y_true_test, y_pred_test, average='macro', zero_division=0)

            if self.config.DEBUG_VERBOSE:
                if epoch == 1:
                    if is_directgcn:
                        print(f"    [Training] Epoch 001/{total_epochs} | L_cls: {epoch_loss_cls:.4f} L_link: {epoch_loss_link:.4f} | Node Acc (Val/Test): {val_acc:.4f}/{test_acc:.4f} | Link Acc: {val_link_acc:.4f}")
                    else:
                        print(f"    [Training] Epoch 001/{total_epochs} | Loss: {loss_val:.4f} | Node Acc (Val/Test): {val_acc:.4f}/{test_acc:.4f}")
                    
                    from tqdm import tqdm
                    # Initialize progress bar starting from epoch 2
                    pbar = tqdm(total=total_epochs, initial=1, desc="    [Training]", leave=False, dynamic_ncols=True)
                
                if pbar is not None:
                    if is_directgcn:
                        pbar.set_postfix({'L_cls': f"{epoch_loss_cls:.3f}", 'L_lnk': f"{epoch_loss_link:.3f}", 'VAcc': f"{val_acc:.3f}"})
                    else:
                        pbar.set_postfix({'Loss': f"{loss_val:.3f}", 'VAcc': f"{val_acc:.3f}"})
                    if epoch > 1:
                        pbar.update(1)

        if pbar is not None:
            pbar.close()

        end_time = time.time()
        duration_ms = (end_time - start_time) * 1000.0

        metrics = {
            'Accuracy': test_acc_at_best_val,
            'Link_Pred_Accuracy': link_acc_at_best_val,
            'MRR': best_link_metrics.get('MRR', 0.0),
            **{f'Hits@{int(k)}': best_link_metrics.get(f'Hits@{int(k)}', 0.0) for k in hits_k_list},
            'F1-Score (Macro)': f1_at_best_val,
            'Precision (Macro)': precision_at_best_val,
            'Recall (Macro)': recall_at_best_val,
            'Training Duration (ms)': duration_ms
        }

        print(
            f"  Finished training. Best Val Node Acc: {best_val_acc:.4f} | "
            f"Test Node Acc: {test_acc_at_best_val:.4f} | Link Acc: {link_acc_at_best_val:.4f} | "
            f"MRR: {best_link_metrics.get('MRR', 0.0):.4f} | "
            f"Hits@10: {best_link_metrics.get('Hits@10', 0.0):.4f}"
        )

        if self.config.BENCHMARK_SAVE_EMBEDDINGS:
            self._save_embeddings(model, data)

        return metrics, pd.DataFrame(history)

    @staticmethod
    def _sparse_identity(size: int, device: torch.device) -> torch.Tensor:
        """Creates a sparse identity matrix of given size."""
        if size <= 0:
            empty_indices = torch.empty((2, 0), dtype=torch.long, device=device)
            empty_values = torch.empty(0, dtype=torch.float32, device=device)
            valid_size = max(0, size)
            return torch.sparse_coo_tensor(empty_indices, empty_values, (valid_size, valid_size)).coalesce()

        indices = torch.arange(size, device=device).unsqueeze(0).repeat(2, 1)
        values = torch.ones(size, device=device, dtype=torch.float32)
        return torch.sparse_coo_tensor(indices, values, (size, size)).coalesce()

    @staticmethod
    def _calculate_single_propagation_matrix(A_w_torch_sparse: torch.Tensor, num_nodes: int, epsilon: float) -> torch.Tensor:
        """
        Calculates the DirectGCN propagation matrix for a single direction (in or out).

        The formula is:
            mathcal{A} = sqrt( 0.5 * ( (D_inv * A)^2 + ((D_inv * A)^2)^T ) + epsilon ) + I

        Where A is the weighted adjacency matrix, D_inv is the inverse of the
        diagonal degree matrix, and I is the identity matrix.
        using sparse tensor operations and an optimized formula.
        """
        if num_nodes == 0 or (A_w_torch_sparse.is_sparse and A_w_torch_sparse._nnz() == 0):
            empty_indices = torch.empty((2, 0), dtype=torch.long, device=A_w_torch_sparse.device)
            empty_values = torch.empty(0, dtype=torch.float32, device=A_w_torch_sparse.device)
            size = (num_nodes, num_nodes)
            return torch.sparse_coo_tensor(empty_indices, empty_values, size).coalesce()

        dev = A_w_torch_sparse.device
        # Step 1: Calculate D_inv * A (row-normalized matrix A_n)

        row_sum = torch.sparse.sum(A_w_torch_sparse, dim=1).to_dense()
        # --- DEFINITIVE FIX: Clamp row_sum to prevent division by very small numbers, which causes NaNs. ---
        row_sum_clamped = torch.clamp(row_sum, min=epsilon)

        D_inv_diag_vals = torch.zeros_like(row_sum_clamped, dtype=torch.float32, device=dev)
        non_zero_degrees_mask = row_sum_clamped != 0
        if torch.any(non_zero_degrees_mask):
            D_inv_diag_vals[non_zero_degrees_mask] = 1.0 / row_sum_clamped[non_zero_degrees_mask]
        del row_sum, row_sum_clamped

        A_w_indices = A_w_torch_sparse.indices()
        A_w_values = A_w_torch_sparse.values()
        scaled_values = A_w_values * D_inv_diag_vals[A_w_indices[0]]
        A_n_sparse = torch.sparse_coo_tensor(A_w_indices, scaled_values, A_w_torch_sparse.size()).coalesce()
        del D_inv_diag_vals

        # Step 2: Calculate 0.5 * (A_n^2 + (A_n^2)^T)
        A_n_sq_values = A_n_sparse.values().pow(2)
        A_n_sq_sparse = torch.sparse_coo_tensor(A_n_sparse.indices(), A_n_sq_values, A_n_sparse.size()).coalesce()
        del A_n_sq_values

        A_n_sq_t_sparse = A_n_sq_sparse.t().coalesce()
        S_sq_plus_K_sq_sparse = (A_n_sq_sparse + A_n_sq_t_sparse).coalesce()
        S_sq_plus_K_sq_sparse = torch.sparse_coo_tensor(
            S_sq_plus_K_sq_sparse.indices(),
            S_sq_plus_K_sq_sparse.values() * 0.5,
            S_sq_plus_K_sq_sparse.size()
        ).coalesce()
        del A_n_sq_sparse, A_n_sq_t_sparse, A_n_sparse
        gc.collect()

        # Step 3: Final calculation: sqrt(...) + I
        epsilon_tensor = torch.tensor(epsilon, device=dev, dtype=torch.float32)
        mathcal_A_base_values = torch.sqrt(S_sq_plus_K_sq_sparse.values() + epsilon_tensor)
        mathcal_A_base_sparse = torch.sparse_coo_tensor(S_sq_plus_K_sq_sparse.indices(), mathcal_A_base_values,
                                                        S_sq_plus_K_sq_sparse.size()).coalesce()
        del S_sq_plus_K_sq_sparse, mathcal_A_base_values
        gc.collect()

        identity_sparse = GNNBenchmarker._sparse_identity(num_nodes, device=dev)
        mathcal_A_with_self_loops_sparse = (mathcal_A_base_sparse + identity_sparse).coalesce()
        del mathcal_A_base_sparse, identity_sparse
        gc.collect()

        return mathcal_A_with_self_loops_sparse

    def _prepare_data_for_model(
        self,
        model_name: str,
        data: Data,
        verbose: bool = True,
        homophily_sampling: Optional[str] = None
    ) -> Data:
        """
        A just-in-time data preparation utility. It creates a model-specific
        data object with the correct graph representations.
        """
        # Start with a fresh clone of the original data
        data_for_model = data.clone()
        if data_for_model.y is not None and data_for_model.y.dim() > 1:
            data_for_model.y = data_for_model.y.squeeze()
        model_name_lower = model_name.lower()

        # --- Base representation: Raw undirected graph ---
        # Most models (GCN, GAT, etc.) will use this and apply their own normalization.
        base_edge_weight = data.edge_attr if hasattr(data, 'edge_attr') and data.edge_attr is not None else torch.ones(data.edge_index.shape[1], device=data.edge_index.device)
        A_out_w_sparse = torch.sparse_coo_tensor(data.edge_index, base_edge_weight, (data.num_nodes, data.num_nodes)).coalesce()
        A_undir_w = (A_out_w_sparse + A_out_w_sparse.t()).coalesce()
        data_for_model.edge_index = A_undir_w.indices()
        data_for_model.edge_attr = A_undir_w.values()

        # --- Model-specific overrides ---
        if model_name_lower == 'directgcn':
            if verbose: print("    -> Preparing specialized matrices for DirectGCN...")
            # --- REFACTOR: Use the static methods from DirectedNgramGraph ---
            A_in_w_sparse = A_out_w_sparse.t().coalesce()
            data_for_model.mathcal_A_in = GNNBenchmarker._calculate_single_propagation_matrix(
                A_in_w_sparse, data.num_nodes, self.config.DIRECTGCN_PROPAGATION_EPSILON)
            data_for_model.mathcal_A_out = GNNBenchmarker._calculate_single_propagation_matrix(
                A_out_w_sparse, data.num_nodes, self.config.DIRECTGCN_PROPAGATION_EPSILON)

            # Reconstruct undirected adjacency by adding mathcal_A_in and mathcal_A_out
            reconstructed_undir = (data_for_model.mathcal_A_in + data_for_model.mathcal_A_out).coalesce()

            # Test: Check if the reconstructed matrix is symmetric
            reconstructed_undir_t = reconstructed_undir.t().coalesce()
            diff = (reconstructed_undir - reconstructed_undir_t).coalesce()
            if diff._nnz() > 0 and diff.values().abs().max() > 1e-4:
                if verbose: print("    -> Warning: Reconstructed undirected adjacency is not perfectly symmetric!")
            else:
                if verbose: print("    -> Test Passed: Reconstructed undirected adjacency is symmetric.")

            data_for_model.A_undirected_norm_sparse = reconstructed_undir

            # Raw matrices for reconstruction targets
            data_for_model.edge_index_mathcal_in_raw = A_in_w_sparse.indices()
            data_for_model.edge_index_mathcal_out_raw = A_out_w_sparse.indices()
            data_for_model.edge_index_undirected_norm_raw = A_undir_w.indices()

            # Attach as edge_index attributes for compatibility with the model's forward pass
            data_for_model.edge_index_mathcal_in = data_for_model.mathcal_A_in.indices()
            data_for_model.edge_weight_mathcal_in = data_for_model.mathcal_A_in.values()
            data_for_model.edge_index_mathcal_out = data_for_model.mathcal_A_out.indices()
            data_for_model.edge_weight_mathcal_out = data_for_model.mathcal_A_out.values()
            data_for_model.edge_index_undirected_norm = data_for_model.A_undirected_norm_sparse.indices()
            data_for_model.edge_weight_undirected_norm = data_for_model.A_undirected_norm_sparse.values()

            # --- Homophilic and Heterophilic Paths (Vectorized Coin-Flip vs Cosine-Similarity) ---
            sampling_mode = (
                homophily_sampling
                or getattr(data, 'homophily_sampling', None)
                or getattr(self.config, 'BENCHMARK_DIRECTGCN_HOMOPHILY_SAMPLING', 'coin_flip')
            ).lower()
            data_for_model.homophily_sampling = sampling_mode

            dev = data.edge_index.device
            src, tgt = data.edge_index[0], data.edge_index[1]
            num_edges = src.size(0)

            y_flat = data.y.view(-1).to(dev)
            train_mask_flat = self._get_1d_mask(data.train_mask).to(dev)

            known_mask = train_mask_flat[src] & train_mask_flat[tgt]
            known_homo = (y_flat[src] == y_flat[tgt])

            num_known = int(known_mask.sum().item())
            if num_known > 0:
                train_homo_count = int((known_mask & known_homo).sum().item())
                p_homo = train_homo_count / num_known
            else:
                p_homo = 0.5

            if verbose:
                print(f"    -> Homophily Prior ({sampling_mode}): P(homo) = {p_homo:.4f}, P(hetero) = {1 - p_homo:.4f}")

            if num_edges > 0:
                if sampling_mode in ('cosine_similarity', 'cosine', 'feature_similarity'):
                    x_for_sim = getattr(data, 'x_native', data.x)
                    if x_for_sim is not None and x_for_sim.dim() == 2 and x_for_sim.size(1) > 1:
                        x_norm = F.normalize(x_for_sim.to(dev).float(), p=2.0, dim=-1)
                        is_homo_mask = known_homo.clone()
                        unobs_idx = (~known_mask).nonzero(as_tuple=False).view(-1)
                        if unobs_idx.numel() > 0:
                            cos_sim = (x_norm[src[unobs_idx]] * x_norm[tgt[unobs_idx]]).sum(dim=-1)
                            if p_homo <= 0.0:
                                unobs_homo = torch.zeros(unobs_idx.numel(), dtype=torch.bool, device=dev)
                            elif p_homo >= 1.0:
                                unobs_homo = torch.ones(unobs_idx.numel(), dtype=torch.bool, device=dev)
                            else:
                                k_homo = max(1, min(unobs_idx.numel(), int(round(p_homo * unobs_idx.numel()))))
                                _, top_indices = torch.topk(cos_sim, k=k_homo, largest=True, sorted=False)
                                unobs_homo = torch.zeros(unobs_idx.numel(), dtype=torch.bool, device=dev)
                                unobs_homo[top_indices] = True
                            is_homo_mask[unobs_idx] = unobs_homo
                    else:
                        gen = torch.Generator(device='cpu')
                        gen.manual_seed(int(self.config.RANDOM_STATE))
                        rand_vals = torch.rand(num_edges, generator=gen).to(dev)
                        is_homo_mask = torch.where(known_mask, known_homo, rand_vals < p_homo)
                else:
                    gen = torch.Generator(device='cpu')
                    gen.manual_seed(int(self.config.RANDOM_STATE))
                    rand_vals = torch.rand(num_edges, generator=gen).to(dev)
                    is_homo_mask = torch.where(known_mask, known_homo, rand_vals < p_homo)

                homo_dir = data.edge_index[:, is_homo_mask]
                hetero_dir = data.edge_index[:, ~is_homo_mask]

                homo_edge_index = torch.cat([homo_dir, homo_dir.flip([0])], dim=1)
                hetero_edge_index = torch.cat([hetero_dir, hetero_dir.flip([0])], dim=1)

                if homo_edge_index.size(1) > 0:
                    homo_edge_index, _ = coalesce(homo_edge_index, None, data.num_nodes, data.num_nodes)
                if hetero_edge_index.size(1) > 0:
                    hetero_edge_index, _ = coalesce(hetero_edge_index, None, data.num_nodes, data.num_nodes)
            else:
                homo_edge_index = torch.empty((2, 0), dtype=torch.long, device=dev)
                hetero_edge_index = torch.empty((2, 0), dtype=torch.long, device=dev)

            # Attach for the model
            data_for_model.edge_index_homophilic = homo_edge_index
            data_for_model.edge_weight_homophilic = None
            data_for_model.edge_index_heterophilic = hetero_edge_index
            data_for_model.edge_weight_heterophilic = None
            
            # Attach raw for reconstruction targets
            data_for_model.edge_index_homophilic_raw = homo_edge_index
            data_for_model.edge_index_heterophilic_raw = hetero_edge_index

            # --- Cyclic and Acyclic Paths ---
            dir_indices = A_out_w_sparse.indices()
            non_self_mask = dir_indices[0] != dir_indices[1]
            dir_no_loops = dir_indices[:, non_self_mask]

            if dir_no_loops.size(1) > 0:
                ones = torch.ones(dir_no_loops.size(1), dtype=torch.float32, device=dir_no_loops.device)
                A_bin = torch.sparse_coo_tensor(dir_no_loops, ones, (data.num_nodes, data.num_nodes)).coalesce()
                A_bin = torch.sparse_coo_tensor(A_bin.indices(), torch.ones_like(A_bin.values()), (data.num_nodes, data.num_nodes)).coalesce()
                A_sym_sum = (A_bin + A_bin.t()).coalesce()
                sym_indices = A_sym_sum.indices()
                sym_values = A_sym_sum.values()

                cyclic_mask = sym_values > 1.5
                acyclic_mask = (sym_values > 0.5) & (sym_values < 1.5)

                cyclic_edge_index = sym_indices[:, cyclic_mask]
                acyclic_edge_index = sym_indices[:, acyclic_mask]
            else:
                cyclic_edge_index = torch.empty((2, 0), dtype=torch.long, device=data.edge_index.device)
                acyclic_edge_index = torch.empty((2, 0), dtype=torch.long, device=data.edge_index.device)

            if verbose:
                total_sym_edges = cyclic_edge_index.size(1) + acyclic_edge_index.size(1)
                p_cyc = (cyclic_edge_index.size(1) / total_sym_edges) if total_sym_edges > 0 else 0.0
                print(f"    -> Structural Reciprocity: Cyclic edges = {cyclic_edge_index.size(1)} ({p_cyc:.4f}), Acyclic (symmetrized) edges = {acyclic_edge_index.size(1)} ({1 - p_cyc:.4f})")

            # Attach for the model
            data_for_model.edge_index_cyclic = cyclic_edge_index
            data_for_model.edge_weight_cyclic = None
            data_for_model.edge_index_acyclic = acyclic_edge_index
            data_for_model.edge_weight_acyclic = None

            # Attach raw for reconstruction targets
            data_for_model.edge_index_cyclic_raw = cyclic_edge_index
            data_for_model.edge_index_acyclic_raw = acyclic_edge_index

        elif model_name_lower in ('rgcn', 'distmult', 'complex', 'metapath2vec', 'gtn'):
            has_native_relations = (
                getattr(data, 'edge_type', None) is not None
                and data.edge_type.numel() == data.edge_index.size(1)
                and int(data.edge_type.max().item()) > 0
            )
            if has_native_relations:
                if verbose:
                    print(f"    -> Using native multi-relational edge_type ({int(getattr(data, 'num_relations', int(data.edge_type.max().item()) + 1))} relations) for {model_name}.")
                data_for_model.edge_index = data.edge_index
                data_for_model.edge_type = data.edge_type.long()
                data_for_model.num_relations = int(getattr(data, 'num_relations', int(data.edge_type.max().item()) + 1))
            else:
                if verbose:
                    print(f"    -> Preparing directed forward/backward relation format (2 relations) for {model_name}.")
                edge_index_out = A_out_w_sparse.indices()
                edge_index_in = A_out_w_sparse.t().coalesce().indices()
                data_for_model.edge_index = torch.cat([edge_index_out, edge_index_in], dim=1)
                edge_type_out = torch.zeros(edge_index_out.size(1), dtype=torch.long, device=edge_index_out.device)
                edge_type_in = torch.ones(edge_index_in.size(1), dtype=torch.long, device=edge_index_in.device)
                data_for_model.edge_type = torch.cat([edge_type_out, edge_type_in])
                data_for_model.num_relations = 2
            if 'edge_attr' in data_for_model:
                del data_for_model.edge_attr

        elif model_name_lower == 'dirgnn':
            if verbose: print("    -> Preparing raw directed edge format for DirGNN.")
            data_for_model.edge_index = A_out_w_sparse.indices()
            data_for_model.edge_attr = A_out_w_sparse.values()
            data_for_model.edge_index_backward = A_out_w_sparse.t().coalesce().indices()

        return data_for_model

    def _run_on_dataset_variant(self, dataset: Any, variant_name: str) -> List[Dict]:
        """Runs all configured models on a single dataset variant."""
        print("\n" + "=" * 50)
        print(f"### Benchmarking on Dataset: {variant_name} ###")
        print("=" * 50 + "\n")

        results = []

        data = dataset[0].clone()
        data.name = variant_name

        print(f"  [Dataset Info] Nodes: {data.num_nodes:,} | Edges: {data.edge_index.size(1):,}")
        num_features = data.num_features if hasattr(data, 'num_features') else 0
        num_classes = dataset.num_classes if hasattr(dataset, 'num_classes') else (len(torch.unique(data.y)) if data.y is not None else 0)
        print(f"  [Dataset Info] Node Features: {num_features} | Target Classes: {num_classes}")
        if all(hasattr(data, mask) and getattr(data, mask) is not None for mask in ['train_mask', 'val_mask', 'test_mask']):
            print(f"  [Dataset Info] Train Nodes: {self._get_1d_mask(data.train_mask).sum().item():,} | Val Nodes: {self._get_1d_mask(data.val_mask).sum().item():,} | Test Nodes: {self._get_1d_mask(data.test_mask).sum().item():,}")

        # --- FIX for CUDA device-side assert ---
        # Instead of trusting dataset.num_classes, derive it directly from the labels.
        # This prevents errors if labels are e.g., [1, 2, 3, 4] but num_classes is reported as 4.
        num_classes = int(data.y.max().item()) + 1
        # --- END FIX ---

        # Handle data splits
        if not all(hasattr(data, mask) and getattr(data, mask) is not None and getattr(data, mask).any() for mask in ['train_mask', 'val_mask', 'test_mask']):
            print(f"  Generating custom seeded split for {variant_name}.")
            num_nodes = data.num_nodes
            # FIX: Use a seeded random number generator for reproducible splits.
            rng = np.random.default_rng(self.config.RANDOM_STATE)
            indices = rng.permutation(num_nodes)
            train_size = int(num_nodes * self.config.BENCHMARK_SPLIT_RATIOS['train'])
            val_size = int(num_nodes * self.config.BENCHMARK_SPLIT_RATIOS['val'])
            data.train_mask = torch.zeros(num_nodes, dtype=torch.bool)
            data.val_mask = torch.zeros(num_nodes, dtype=torch.bool)
            data.test_mask = torch.zeros(num_nodes, dtype=torch.bool)
            data.train_mask[indices[:train_size]] = True
            data.val_mask[indices[train_size:train_size + val_size]] = True
            data.test_mask[indices[train_size + val_size:]] = True
        else:
            print(f"  Using existing standard masks for {variant_name}.")
        print(f"  [Dataset Info] Train Nodes: {self._get_1d_mask(data.train_mask).sum().item():,} | Val Nodes: {self._get_1d_mask(data.val_mask).sum().item():,} | Test Nodes: {self._get_1d_mask(data.test_mask).sum().item():,}")

        print(f"  {variant_name.split('_')[0]} loaded: Nodes={data.num_nodes}, Edges={data.num_edges}, Features={data.num_features}, Classes={num_classes}")

        # Preserve native node features for optional cosine_similarity homophily routing ablation
        if hasattr(data, 'x') and data.x is not None:
            data.x_native = data.x.clone()

        # --- Ignore existing features and initialize random features (Featureless Structural Mode) ---
        new_feature_dim = self.config.BENCHMARK_GNN_INIT_DIM
        if new_feature_dim is not None:
            print(f"  Ignoring original features. Initializing new random features with dimension: {new_feature_dim}")
            gen = torch.Generator(device='cpu')
            gen.manual_seed(int(self.config.RANDOM_STATE))
            data.x = torch.randn((data.num_nodes, new_feature_dim), generator=gen)

        for model_name in self.config.BENCHMARK_GNN_MODELS_TO_RUN:
            print(f"--- Benchmarking Model: {model_name} on Dataset: {variant_name} ---")
            try:
                if model_name.lower() == 'directgcn':
                    base_lr = float(self.config.BENCHMARK_GNN_LEARNING_RATE)
                    base_wd = float(self.config.BENCHMARK_GNN_WEIGHT_DECAY)
                    base_epochs = int(self.config.BENCHMARK_GNN_EPOCHS)
                    try:
                        base_dropout = float(self.config.BENCHMARK_GNN_DROPOUT_RATE)
                    except Exception:
                        base_dropout = 0.5

                    current_gating_mode = str(getattr(self.config, 'BENCHMARK_DIRECTGCN_GATING_MODE', 'vector') or 'none').lower().strip()
                    configured_sampling = str(getattr(self.config, 'BENCHMARK_DIRECTGCN_HOMOPHILY_SAMPLING', 'coin_flip')).lower().strip()

                    gating_modes_to_run = (
                        ['vector', 'none'] if current_gating_mode == 'ablation' else [current_gating_mode]
                    )
                    sampling_modes_to_run = (
                        ['coin_flip', 'cosine_similarity'] if configured_sampling == 'ablation' else [configured_sampling]
                    )

                    variants = []
                    for gm in gating_modes_to_run:
                        for sm in sampling_modes_to_run:
                            sm_tag = 'cosine_sim' if sm == 'cosine_similarity' else sm
                            if len(gating_modes_to_run) == 1 and len(sampling_modes_to_run) == 1 and configured_sampling != 'ablation' and current_gating_mode != 'ablation':
                                suffix = f'full_{gm}'
                            else:
                                suffix = f'full_{gm}_{sm_tag}'
                            variants.append({
                                'suffix': suffix,
                                'gating_mode': gm,
                                'path_selection': 'full',
                                'homophily_sampling': sm,
                                'dropout': base_dropout,
                                'lr': base_lr,
                                'wd': base_wd,
                                'epochs': base_epochs,
                            })

                    for var in variants:
                        variant_name_tag = f"{model_name}[{var['suffix']}]"
                        print(f"\n  [Benchmark] Starting variant: {variant_name_tag}")
                        print(f"    - Epochs: {var['epochs']} | LR: {var['lr']} | WD: {var['wd']} | Dropout: {var['dropout']}")
                        print(f"    - Gating Mode: {var['gating_mode']} | Path Selection: {var['path_selection']} | Homophily Sampling: {var['homophily_sampling']}")
                        mlflow.set_tracking_uri(self.output_dir.as_uri())
                        with mlflow.start_run(run_name=f"{variant_name_tag}_on_{variant_name}", nested=True):
                            mlflow.set_tag("model_name", variant_name_tag)
                            mlflow.set_tag("dataset_name", variant_name)
                            mlflow.log_param("epochs", var['epochs'])
                            mlflow.log_param("learning_rate", var['lr'])
                            mlflow.log_param("weight_decay", var['wd'])
                            mlflow.log_param("gating_mode", var['gating_mode'])
                            mlflow.log_param("path_selection", var['path_selection'])
                            mlflow.log_param("homophily_sampling", var['homophily_sampling'])
                            mlflow.log_param("is_undirected", "_Undirected" in variant_name)

                            data_for_model = self._prepare_data_for_model(
                                model_name=model_name,
                                data=data,
                                homophily_sampling=var['homophily_sampling']
                            )
                            # mark variant for embedding filenames
                            setattr(data_for_model, 'variant_suffix', var['suffix'])

                            model = self.model_factory.create_model(
                                model_name=model_name,
                                in_channels=data_for_model.num_features,
                                is_featureless=getattr(data_for_model, 'is_featureless', getattr(data, 'is_featureless', False)),
                                num_classes=num_classes,
                                num_graph_nodes=data.num_nodes,
                                gating_mode=var['gating_mode'],
                                dropout_rate=var['dropout'],
                                path_selection=var['path_selection']
                            )

                            if self.config.DEBUG_VERBOSE:
                                print("  Variant Architecture:")
                                print(model)

                            metrics, history_df = self._train_and_evaluate(
                                model, data_for_model,
                                epochs_override=var['epochs'],
                                lr_override=var['lr'],
                                wd_override=var['wd']
                            )
                            # Keep base model name for summary categorization; store variant separately
                            result_row = {
                                "dataset": variant_name,
                                "model": model_name,
                                "variant": var['suffix'],
                                "error": None
                            }
                            result_row.update(metrics)
                            results.append(result_row)

                            mlflow.log_metrics({
                                "test_accuracy": metrics.get('Accuracy', 0.0),
                                "link_pred_accuracy": metrics.get('Link_Pred_Accuracy', 0.0),
                                "mrr": metrics.get('MRR', 0.0),
                                "hits_at_1": metrics.get('Hits@1', 0.0),
                                "hits_at_3": metrics.get('Hits@3', 0.0),
                                "hits_at_10": metrics.get('Hits@10', 0.0),
                                "f1_macro": metrics.get('F1-Score (Macro)', 0.0)
                            })
                            Path(self.output_dir).mkdir(parents=True, exist_ok=True)
                            history_path = Path(self.output_dir) / f"history_{variant_name_tag}_{variant_name}.csv"
                            history_df.to_csv(history_path, index=False)
                            mlflow.log_artifact(str(history_path), "training_history")
                            if os.path.exists(history_path):
                                os.remove(history_path)
                else:
                    print(f"\n  [Benchmark] Starting standard model: {model_name}")
                    print(f"    - Epochs: {self.config.BENCHMARK_GNN_EPOCHS} | LR: {self.config.BENCHMARK_GNN_LEARNING_RATE} | WD: {self.config.BENCHMARK_GNN_WEIGHT_DECAY}")
                    mlflow.set_tracking_uri(self.output_dir.as_uri())
                    with mlflow.start_run(run_name=f"{model_name}_on_{variant_name}", nested=True):
                        mlflow.set_tag("model_name", model_name)
                        mlflow.set_tag("dataset_name", variant_name)
                        mlflow.log_param("epochs", self.config.BENCHMARK_GNN_EPOCHS)
                        mlflow.log_param("learning_rate", self.config.BENCHMARK_GNN_LEARNING_RATE)
                        mlflow.log_param("is_undirected", "_Undirected" in variant_name)

                        data_for_model = self._prepare_data_for_model(
                            model_name=model_name,
                            data=data
                        )

                        model = self.model_factory.create_model(
                            model_name=model_name,
                            in_channels=data_for_model.num_features,
                            is_featureless=getattr(data_for_model, 'is_featureless', getattr(data, 'is_featureless', False)),
                            num_classes=num_classes,
                            num_graph_nodes=data.num_nodes,
                            num_relations=int(getattr(data_for_model, 'num_relations', getattr(data, 'num_relations', self.config.BENCHMARK_RGCN_NUM_RELATIONS)))
                        )

                        if self.config.DEBUG_VERBOSE:
                            print("  Model Architecture:")
                            print(model)

                        metrics, history_df = self._train_and_evaluate(model, data_for_model)
                        result_row = {"dataset": variant_name, "model": model_name, "error": None}
                        result_row.update(metrics)
                        results.append(result_row)

                        mlflow.log_metrics({
                            "test_accuracy": metrics.get('Accuracy', 0.0),
                            "link_pred_accuracy": metrics.get('Link_Pred_Accuracy', 0.0),
                            "mrr": metrics.get('MRR', 0.0),
                            "hits_at_1": metrics.get('Hits@1', 0.0),
                            "hits_at_3": metrics.get('Hits@3', 0.0),
                            "hits_at_10": metrics.get('Hits@10', 0.0),
                            "f1_macro": metrics.get('F1-Score (Macro)', 0.0)
                        })
                        Path(self.output_dir).mkdir(parents=True, exist_ok=True)
                        history_path = Path(self.output_dir) / f"history_{model_name}_{variant_name}.csv"
                        history_df.to_csv(history_path, index=False)
                        mlflow.log_artifact(str(history_path), "training_history")
                        if os.path.exists(history_path):
                            os.remove(history_path)

            except Exception as e:
                print(f"ERROR during training/evaluation of {model_name} on {variant_name}: {e}")
                traceback.print_exc()
                if mlflow.active_run() is not None:
                    mlflow.set_tag("status", "FAILED")
                    # Use a unique key and truncate to 250 chars to avoid MLflow limits
                    mlflow.log_param(f"err_{model_name}", str(e)[:250])
                results.append({"dataset": variant_name, "model": model_name, "error": str(e)})
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
        return results

    def run(self):
        """Main execution function for the benchmarker."""
        all_results = []
        print(f"Standard PyG datasets will be stored in/loaded from: {self.dataset_root}")

        for dataset_name in self.config.BENCHMARK_NODE_CLASSIFICATION_DATASETS:
            dataset_results = []

            # --- Run on Original (potentially directed) Graph ---
            dataset_original = self._get_dataset(dataset_name)
            if dataset_original:
                dataset_results.extend(self._run_on_dataset_variant(dataset_original, f"{dataset_name}_Original"))

            # --- Run on Undirected Version if BENCHMARK_TEST_ON_UNDIRECTED is True ---
            if self.config.BENCHMARK_TEST_ON_UNDIRECTED and dataset_original:
                from torch_geometric.utils import to_undirected
                data_undirected = dataset_original[0].clone()
                data_undirected.edge_index = to_undirected(data_undirected.edge_index, data_undirected.num_nodes)
                dataset_results.extend(self._run_on_dataset_variant([data_undirected], f"{dataset_name}_Undirected"))

            # --- Save summary for the current dataset ---
            if dataset_results:
                all_results.extend(dataset_results)

        # --- Save a final, grand summary of all results ---
        if all_results:
            summary_df = pd.DataFrame(all_results)
            Path(self.output_dir).mkdir(parents=True, exist_ok=True)
            summary_path = Path(self.output_dir) / "summary.csv"
            try:
                summary_df.to_csv(summary_path, index=False)
                print(f"  Benchmarking summary saved to: {summary_path}")
            except Exception as e:
                print(f"  WARNING: Could not save benchmarking summary: {e}")

            del all_results
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            return summary_df
        return pd.DataFrame()
