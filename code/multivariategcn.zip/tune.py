import sys
import os
import shutil
from pathlib import Path
import pandas as pd

# Opt-out of MLflow filestore maintenance exception
os.environ["MLFLOW_ALLOW_FILE_STORE"] = "true"
# Fix CuBLAS deterministic algorithm error
os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"

# Workaround for WSL NTFS mount permission errors with MLflow artifact logging
_original_copystat = shutil.copystat
def _safe_copystat(*args, **kwargs):
    try:
        _original_copystat(*args, **kwargs)
    except PermissionError:
        pass
shutil.copystat = _safe_copystat

import optuna
from configuration.config import Config
from torch_geometric.datasets import CitationFull
from train.gnns import GNNBenchmarker

# Insert path logic identical to train.py
project_root = Path(__file__).resolve().parent
sys.path.insert(0, str(project_root))

def objective(trial):
    config = Config('configuration/config.yaml')
    
    # Expanded hyperparameter search ranges
    lr = trial.suggest_float('learning_rate', 1e-5, 1e-1, log=True)
    wd = trial.suggest_float('weight_decay', 1e-6, 1e-1, log=True)
    dropout = trial.suggest_float('dropout_rate', 0.0, 0.8)
    
    # Expanded architecture params
    hidden_dim = trial.suggest_categorical('hidden_dim', [16, 32, 64, 128, 256])
    num_bases = trial.suggest_categorical('num_bases', [2, 4, 8, 16, 32])
    num_layers_per_module = trial.suggest_int('num_layers_per_module', 1, 3)
    gnn_num_layers = trial.suggest_int('gnn_num_layers', 1, 4)
    gating_mode = trial.suggest_categorical('gating_mode', ['scalar', 'vector', 'node_gate_vector'])
    
    # Expanded loss weights
    config.LOSS_WEIGHT_CLS = trial.suggest_float('loss_weight_cls', 0.05, 1.0)
    config.LOSS_WEIGHT_EXIST = trial.suggest_float('loss_weight_exist', 0.0, 1.0)
    config.LOSS_WEIGHT_SIM = trial.suggest_float('loss_weight_sim', 0.0, 1.0)
    config.LOSS_WEIGHT_DIR = trial.suggest_float('loss_weight_dir', 0.0, 1.0)
    config.LOSS_WEIGHT_CYC = trial.suggest_float('loss_weight_cyc', 0.0, 1.0)
    
    # Override shared GNN config for this trial
    config.BENCHMARK_GNN_LEARNING_RATE = lr
    config.BENCHMARK_GNN_WEIGHT_DECAY = wd
    config.BENCHMARK_GNN_DROPOUT_RATE = dropout
    config.BENCHMARK_GNN_HIDDEN_CHANNELS = hidden_dim
    config.BENCHMARK_GNN_NUM_LAYERS = gnn_num_layers
    config.GNN_LEARNING_RATE = lr
    config.GNN_WEIGHT_DECAY = wd
    config.GNN_DROPOUT_RATE = dropout
    config.GNN_HIDDEN_CHANNELS = hidden_dim
    config.GNN_NUM_LAYERS = gnn_num_layers
    
    # Override DirectGCN config for this trial
    config.BENCHMARK_DIRECTGCN_HIDDEN_DIM = hidden_dim
    config.BENCHMARK_DIRECTGCN_NUM_BASES = num_bases
    config.BENCHMARK_DIRECTGCN_PROJ_NUM_BASES = num_bases
    config.BENCHMARK_DIRECTGCN_NUM_LAYERS_PER_MODULE = num_layers_per_module
    config.BENCHMARK_DIRECTGCN_GATING_MODE = gating_mode
    config.DIRECTGCN_HIDDEN_DIM = hidden_dim
    config.DIRECTGCN_NUM_BASES = num_bases
    config.DIRECTGCN_PROJ_NUM_BASES = num_bases
    config.DIRECTGCN_NUM_LAYERS_PER_MODULE = num_layers_per_module
    config.DIRECTGCN_GATING_MODE = gating_mode
    
    # Run all 4 models on Cora_ML and CiteSeer_Full
    config.BENCHMARK_GNN_MODELS_TO_RUN = ['GCN', 'RGCN', 'DirGNN', 'DirectGCN']
    config.BENCHMARK_NODE_CLASSIFICATION_DATASETS = ['Cora_ML', 'CiteSeer_Full']
    
    dataset_root = config.DATA_STANDARD_DATASETS_DIR
    CitationFull(root=str(dataset_root), name='Cora_ML', to_undirected=False)
    CitationFull(root=str(dataset_root), name='CiteSeer', to_undirected=False)
    
    benchmarker = GNNBenchmarker(config)
    results_df = benchmarker.run()
    
    if results_df is None or results_df.empty:
        raise optuna.TrialPruned()

    # Log per-model / per-dataset accuracy attributes on the trial
    for _, row in results_df.iterrows():
        ds_name = row.get('dataset', 'unknown')
        mdl_name = row.get('model', 'unknown')
        acc_val = row.get('Accuracy', -1.0)
        if pd.notna(acc_val):
            trial.set_user_attr(f"{ds_name}_{mdl_name}_Acc", float(acc_val))

    # Maximize DirectGCN's average Accuracy across Cora_ML and CiteSeer_Full
    directgcn_df = results_df[results_df['model'].str.lower() == 'directgcn']
    if directgcn_df.empty:
        raise optuna.TrialPruned()

    mean_directgcn_acc = float(directgcn_df['Accuracy'].mean())
    return mean_directgcn_acc

if __name__ == "__main__":
    study = optuna.create_study(direction="maximize", study_name="DirectGCN_CoraML_CiteSeerFull_Optimization")
    study.optimize(objective, n_trials=20)
    
    print("\n==================================")
    print("Optimization Finished")
    print("==================================")
    print("Number of finished trials: ", len(study.trials))
    print("Best trial:")
    trial = study.best_trial
    
    print("  Value (Mean DirectGCN Accuracy): ", trial.value)
    print("  Model Accuracies in Best Trial:")
    for k, v in sorted(trial.user_attrs.items()):
        print(f"    {k}: {v:.4f}")
    print("  Params: ")
    for key, value in trial.params.items():
        print("    {}: {}".format(key, value))
