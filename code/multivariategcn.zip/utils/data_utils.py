# ==============================================================================
# MODULE: utils/data/data_utils.py
# PURPOSE: Contains general, non-I/O data loading and processing utilities.
# VERSION: 4.1 (Added memory reporting utility)
# AUTHOR: Islam Ebeid
# ==============================================================================

import os
import random
import shutil
from pathlib import Path
from typing import Iterator, List, Optional, Any, Tuple

import h5py
import numpy as np
import pandas as pd
import psutil
import torch
# --- DEFINITIVE FIX for Singleton Evaluation: Add networkx and community for robust community detection ---
import networkx as nx
from torch_geometric.data import Data
from torch_geometric.utils import to_networkx
import community as community_louvain
import scipy.sparse as sp


# ==============================================================================
# 1. General Data Utilities (Moved from embedding_loader.py)
# ==============================================================================
class DataUtils:
    """General data utility functions."""

    @staticmethod
    def set_seeds(seed: int):
        """
        Sets random seeds for all relevant libraries to ensure reproducibility.
        Also configures PyTorch to use deterministic algorithms for CUDA.
        """
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        # --- DEFINITIVE FIX for Reproducibility ---
        # This forces PyTorch to use deterministic algorithms, which is essential for run-to-run consistency.
        # It may impact performance slightly but is crucial for reliable experiments.
        torch.use_deterministic_algorithms(True)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
            # The following two lines are crucial for GPU reproducibility
            torch.backends.cudnn.deterministic = True
            torch.backends.cudnn.benchmark = False
        print(f"  Seeds set to {seed} for reproducibility. PyTorch CUDA deterministic mode is ON.")

    @staticmethod
    def print_header(title: str):
        """Prints a standardized header to the console."""
        border = "=" * (len(title) + 6)
        print(f"\n{border}\n### {title} ###\n{border}\n")
