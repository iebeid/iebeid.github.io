import random
from typing import List

import networkx as nx
import torch
from torch_geometric.data import Data
from torch_geometric.utils import to_networkx, subgraph

try:
    import networkx.algorithms.community as nx_comm
except ImportError:
    nx_comm = None

# class LouvainClusterData:
#     """
#     Partitions a graph into clusters using the Louvain community detection algorithm.
#     """
#     def __init__(self, data: Data, max_cluster_size: int = 1000):
#         self.data = data
#         self.max_cluster_size = max_cluster_size
#         self.num_nodes = data.num_nodes
#         self.clusters = self._partition_graph(data)
#
#     def _partition_graph(self, data: Data) -> List[torch.Tensor]:
#         try:
#             import metis
#             print("    Converting edge_index to NetworkX for METIS partitioning (Fast)...")
#             G = nx.Graph()
#             G.add_edges_from(data.edge_index.t().tolist())
#
#             num_clusters = max(1, data.num_nodes // self.max_cluster_size)
#             print(f"    Running METIS graph partitioning into {num_clusters} clusters...")
#             _, parts = metis.part_graph(G, num_clusters, seed=42)
#
#             import collections
#             clusters_dict = collections.defaultdict(list)
#             for node_idx, cluster_id in enumerate(parts):
#                 clusters_dict[cluster_id].append(node_idx)
#
#             final_clusters = [torch.tensor(nodes, dtype=torch.long) for nodes in clusters_dict.values()]
#             print(f"    Graph partitioned into {len(final_clusters)} clusters (METIS).")
#             return final_clusters
#         except ImportError:
#             print("    METIS not found. Converting to NetworkX for Louvain partitioning (Slower)...")
#             if nx_comm is None or not hasattr(nx_comm, 'louvain_communities'):
#                 raise ImportError("networkx>=2.6 is required for Louvain partitioning. Please install/update networkx.")
#
#             G = to_networkx(data, to_undirected=True)
#             print("    Running Louvain community detection...")
#             communities = nx_comm.louvain_communities(G)
#
#             # Enforce max_cluster_size
#             final_clusters = []
#             for comm in communities:
#                 comm_list = list(comm)
#                 if len(comm_list) > self.max_cluster_size:
#                     # Randomly split oversized communities
#                     random.shuffle(comm_list)
#                     for i in range(0, len(comm_list), self.max_cluster_size):
#                         chunk = comm_list[i:i + self.max_cluster_size]
#                         final_clusters.append(torch.tensor(chunk, dtype=torch.long))
#                 else:
#                     final_clusters.append(torch.tensor(comm_list, dtype=torch.long))
#
#             print(f"    Graph partitioned into {len(final_clusters)} clusters (Louvain, max_size={self.max_cluster_size}).")
#             return final_clusters
#
#     def __len__(self):
#         return len(self.clusters)

# class LouvainClusterLoader:
#     """
#     Creates stratified, pre-computed mini-batches of subgraphs from LouvainClusterData.
#     """
#     def __init__(self, cluster_data: LouvainClusterData, batch_size: int = 20, shuffle: bool = True):
#         self.cluster_data = cluster_data
#         self.batch_size = batch_size
#         self.shuffle = shuffle
#
#         print("    Pre-computing stratified batches for fast training...")
#         self.batches = self._precompute_batches()
#
#     def _precompute_batches(self) -> List[Data]:
#         # 1. Calculate class distribution per cluster for stratified sampling
#         data = self.cluster_data.data
#         has_y = data.y is not None
#         num_classes = int(data.y.max().item()) + 1 if has_y else 1
#
#         cluster_profiles = []
#         for i, cluster_nodes in enumerate(self.cluster_data.clusters):
#             if has_y:
#                 labels = data.y[cluster_nodes]
#                 # Filter out -1 (unlabeled) if any exist
#                 valid_labels = labels[labels >= 0]
#                 if len(valid_labels) > 0:
#                     counts = torch.bincount(valid_labels, minlength=num_classes).float().cpu()
#                     counts = counts / (counts.sum() + 1e-9)
#                 else:
#                     counts = torch.ones(num_classes).cpu() / num_classes
#             else:
#                 counts = torch.ones(1).cpu()
#             cluster_profiles.append((i, counts, len(cluster_nodes)))
#
#         # 2. Greedily create batches to balance labels
#         # Sort clusters by size (largest first) to place them first
#         cluster_profiles.sort(key=lambda x: x[2], reverse=True)
#
#         # Determine number of batches based on total nodes, targeting ~1000 nodes per batch
#         # This prevents over-fragmentation on small graphs (like CiteSeer) and reduces loop overhead
#         target_nodes_per_batch = 1000
#         num_batches = max(1, self.cluster_data.num_nodes // target_nodes_per_batch)
#
#         # Override if batch_size was explicitly meant to be very small, but generally we want num_batches
#         batches_indices = [[] for _ in range(num_batches)]
#         batch_profiles = [torch.zeros(num_classes) for _ in range(num_batches)]
#
#         batch_nodes_count = [0] * num_batches
#
#         for idx, profile, size in cluster_profiles:
#             # Find the batch that needs this profile the most to balance out the label distribution,
#             # while also penalizing batches that already have too many nodes.
#             # We want to minimize the dot product (least similar profile) and keep node counts balanced.
#             best_b = min(range(num_batches), key=lambda b: (batch_nodes_count[b], torch.dot(batch_profiles[b], profile).item()))
#             batches_indices[best_b].append(idx)
#             batch_profiles[best_b] += profile
#             batch_nodes_count[best_b] += size
#
#         # 3. Induce subgraphs for each batch
#         precomputed_batches = []
#         for b_indices in batches_indices:
#             if not b_indices:
#                 continue
#
#             selected_nodes = [self.cluster_data.clusters[idx] for idx in b_indices]
#             subset = torch.cat(selected_nodes).to(data.edge_index.device)
#
#             # Induce subgraph
#             sub_edge_index, sub_edge_attr = subgraph(
#                 subset,
#                 data.edge_index,
#                 edge_attr=getattr(data, 'edge_type', None),
#                 relabel_nodes=True
#             )
#
#             # Create a new Data object for the subgraph
#             sub_data = Data(
#                 x=data.x[subset],
#                 edge_index=sub_edge_index,
#                 y=data.y[subset] if data.y is not None else None,
#             )
#
#             if sub_edge_attr is not None:
#                 sub_data.edge_type = sub_edge_attr
#
#             # Keep track of original node indices in case we need to map back
#             sub_data.n_id = subset
#             sub_data.original_indices = subset
#             sub_data.num_nodes = subset.size(0)
#
#             # Transfer masks if they exist
#             for mask_name in ['train_mask', 'val_mask', 'test_mask']:
#                 if hasattr(data, mask_name):
#                     setattr(sub_data, mask_name, getattr(data, mask_name)[subset])
#
#             # Support for DirectGCN specialized matrices
#             specialized_edges = [
#                 ('edge_index_mathcal_in', 'edge_weight_mathcal_in'),
#                 ('edge_index_mathcal_out', 'edge_weight_mathcal_out'),
#                 ('edge_index_undirected_norm', 'edge_weight_undirected_norm'),
#                 ('edge_index_mathcal_in_raw', None),
#                 ('edge_index_mathcal_out_raw', None),
#                 ('edge_index_undirected_norm_raw', None)
#             ]
#             for e_idx_name, e_weight_name in specialized_edges:
#                 if hasattr(data, e_idx_name):
#                     e_idx = getattr(data, e_idx_name)
#                     e_weight = getattr(data, e_weight_name, None)
#                     sub_e_idx, sub_e_weight = subgraph(subset, e_idx, edge_attr=e_weight, relabel_nodes=True)
#                     setattr(sub_data, e_idx_name, sub_e_idx)
#                     if sub_e_weight is not None:
#                         setattr(sub_data, e_weight_name, sub_e_weight)
#
#             precomputed_batches.append(sub_data)
#
#         print(f"    Pre-computed {len(precomputed_batches)} balanced subgraphs for fast training.")
#         return precomputed_batches
#
#     def __iter__(self):
#         if self.shuffle:
#             random.shuffle(self.batches)
#         for batch in self.batches:
#             yield batch

class StratifiedConnectedSubgraphLoader:
    """
    Creates stratified, dynamically connected mini-batches (subgraphs) 
    using BFS from balanced class roots to guarantee connectivity 
    and label balance without community detection overhead.
    """
    def __init__(self, data: Data, batch_size: int = 1000, num_batches: int = None, bfs_root_ratio: float = 0.10):
        self.data = data
        self.batch_size = batch_size
        self.num_nodes = data.num_nodes
        self.num_batches = num_batches or max(1, self.num_nodes // batch_size)
        self.bfs_root_ratio = bfs_root_ratio
        
        print(f"    [Sampler] Initializing Stratified BFS Subgraph Loader")
        print(f"    [Sampler] Subgraph Target Size (N): {self.batch_size} nodes")
        print(f"    [Sampler] Batches per Epoch (M): {self.num_batches}")
        print(f"    [Sampler] Global Graph Size: {self.num_nodes} nodes, {data.edge_index.size(1)} edges")
        print(f"    [Sampler] Profiling node classes for balanced root sampling...")
        
        if data.y is not None:
            import numpy as np
            labels = data.y.cpu().numpy()
            self.classes = np.unique(labels[labels >= 0])
            self.class_indices = {c: np.where(labels == c)[0] for c in self.classes}
            class_counts = {c: len(idx) for c, idx in self.class_indices.items()}
            print(f"    [Sampler] Found {len(self.classes)} distinct classes.")
        else:
            self.classes = [0]
            self.class_indices = {0: np.arange(self.num_nodes)}
            print(f"    [Sampler] No labels found. Treating all nodes as a single class.")
            
        target_roots = max(len(self.classes), int(self.batch_size * self.bfs_root_ratio))
        print(f"    [Sampler] BFS Root Ratio: {self.bfs_root_ratio:.2f} -> Seeding each subgraph with {target_roots} diverse roots.")
        
        print("    [Sampler] Building sparse CSR adjacency matrix for ultra-fast BFS expansion...")
        from torch_geometric.utils import to_scipy_sparse_matrix
        # Ensure we only use original graph edges (not homophily paths) for strict connectivity
        self.adj = to_scipy_sparse_matrix(data.edge_index, num_nodes=self.num_nodes).tocsr()
        
        print("    [Sampler] Pre-computing subgraphs for fast training epochs...")
        self.batches = [self._get_connected_subgraph() for _ in range(self.num_batches)]
        
        # --- Edge Recovery Phase ---
        print("    [Sampler] Scanning for severed edges to ensure 100% graph coverage...")
        device = self.data.edge_index.device
        covered_edges = torch.zeros(self.data.edge_index.size(1), dtype=torch.bool, device=device)
        
        for batch in self.batches:
            # Create a dense node mask for this batch's nodes
            node_mask = torch.zeros(self.num_nodes, dtype=torch.bool, device=device)
            node_mask[batch.original_indices] = True
            # Edges where both source and target are in the batch are covered
            batch_edge_mask = node_mask[self.data.edge_index[0]] & node_mask[self.data.edge_index[1]]
            covered_edges |= batch_edge_mask
            
        uncovered_edge_indices = (~covered_edges).nonzero(as_tuple=False).view(-1)
        
        if uncovered_edge_indices.numel() > 0:
            print(f"    [Sampler] Found {uncovered_edge_indices.numel()} severed edges. Creating recovery batches...")
            uncovered_src = self.data.edge_index[0, uncovered_edge_indices]
            uncovered_tgt = self.data.edge_index[1, uncovered_edge_indices]
            uncovered_nodes = torch.cat([uncovered_src, uncovered_tgt]).unique()
            
            # Group uncovered nodes into batches of max `batch_size`
            nodes_list = uncovered_nodes.tolist()
            recovery_batches_count = 0
            for i in range(0, len(nodes_list), self.batch_size):
                chunk = nodes_list[i:i + self.batch_size]
                chunk_tensor = torch.tensor(chunk, dtype=torch.long, device=device)
                recovery_batch = self._build_subgraph_from_nodes(chunk_tensor)
                self.batches.append(recovery_batch)
                recovery_batches_count += 1
                
            print(f"    [Sampler] Added {recovery_batches_count} recovery batches containing the severed edges.")
        else:
            print("    [Sampler] All edges successfully covered in the initial BFS batches.")
            
        self.num_batches = len(self.batches)
        print(f"    [Sampler] Initialization complete. Total batches: {self.num_batches}")

    def _sample_balanced_roots(self, target_roots):
        import numpy as np
        roots = []
        roots_per_class = max(1, target_roots // len(self.classes))
        for c in self.classes:
            indices = self.class_indices[c]
            if len(indices) > 0:
                sampled = np.random.choice(indices, min(roots_per_class, len(indices)), replace=False)
                roots.extend(sampled)
        np.random.shuffle(roots)
        return roots

    def _get_connected_subgraph(self):
        import numpy as np
        from collections import deque
        target_nodes = self.batch_size
        target_roots = max(len(self.classes), int(target_nodes * self.bfs_root_ratio))
        roots = self._sample_balanced_roots(target_roots)
        
        visited = set(roots)
        queue = deque(roots)
        
        # BFS expansion ensuring connectivity
        while queue and len(visited) < target_nodes:
            node = queue.popleft()
            neighbors = self.adj.indices[self.adj.indptr[node]:self.adj.indptr[node+1]]
            
            for neighbor in neighbors:
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)
                    if len(visited) >= target_nodes:
                        break

        subset = torch.tensor(list(visited), dtype=torch.long, device=self.data.edge_index.device)
        return self._build_subgraph_from_nodes(subset)

    def _build_subgraph_from_nodes(self, subset):
        sub_edge_index, sub_edge_attr = subgraph(
            subset, 
            self.data.edge_index,
            edge_attr=getattr(self.data, 'edge_type', None),
            relabel_nodes=True
        )
        
        sub_data = Data(
            x=self.data.x[subset],
            edge_index=sub_edge_index,
            y=self.data.y[subset] if self.data.y is not None else None,
        )
        
        if hasattr(self.data, 'x_native') and self.data.x_native is not None:
            sub_data.x_native = self.data.x_native[subset]
        if hasattr(self.data, 'homophily_sampling'):
            sub_data.homophily_sampling = self.data.homophily_sampling

        if sub_edge_attr is not None:
            sub_data.edge_type = sub_edge_attr
            
        sub_data.n_id = subset
        sub_data.original_indices = subset
        sub_data.num_nodes = subset.size(0)
        
        for mask_name in ['train_mask', 'val_mask', 'test_mask']:
            if hasattr(self.data, mask_name):
                setattr(sub_data, mask_name, getattr(self.data, mask_name)[subset])
                
        specialized_edges = [
            ('edge_index_mathcal_in', 'edge_weight_mathcal_in'),
            ('edge_index_mathcal_out', 'edge_weight_mathcal_out'),
            ('edge_index_undirected_norm', 'edge_weight_undirected_norm'),
            ('edge_index_mathcal_in_raw', None),
            ('edge_index_mathcal_out_raw', None),
            ('edge_index_undirected_norm_raw', None),
            ('edge_index_homophilic', 'edge_weight_homophilic'),
            ('edge_index_heterophilic', 'edge_weight_heterophilic'),
            ('edge_index_homophilic_raw', None),
            ('edge_index_heterophilic_raw', None),
            ('edge_index_cyclic', 'edge_weight_cyclic'),
            ('edge_index_acyclic', 'edge_weight_acyclic'),
            ('edge_index_cyclic_raw', None),
            ('edge_index_acyclic_raw', None),
        ]
        
        for e_idx_name, e_weight_name in specialized_edges:
            if hasattr(self.data, e_idx_name):
                full_e_idx = getattr(self.data, e_idx_name)
                
                if e_weight_name:
                    full_e_weight = getattr(self.data, e_weight_name, None)
                    if full_e_weight is None:
                        full_e_weight = torch.ones(full_e_idx.size(1), dtype=torch.float32, device=full_e_idx.device)
                else:
                    full_e_weight = None
                    
                s_idx, s_weight = subgraph(subset, full_e_idx, edge_attr=full_e_weight, relabel_nodes=True, num_nodes=self.num_nodes)
                setattr(sub_data, e_idx_name, s_idx)
                if e_weight_name and s_weight is not None:
                    setattr(sub_data, e_weight_name, s_weight)
                    
        return sub_data

    def __iter__(self):
        import random
        random.shuffle(self.batches)
        for batch in self.batches:
            yield batch
            
    def __len__(self):
        return self.num_batches
