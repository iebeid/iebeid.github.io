# ==============================================================================
# MODULE: utils/post/math_utils.py
# PURPOSE: Contains tools for loading and post-processing embeddings, such as PCA,
#          normalization, pooling, and edge feature creation.
# VERSION: 7.0 (Aligned DirectGCN embedding extraction with Parallel Views architecture)
# AUTHOR: Islam Ebeid
# ==============================================================================
import tempfile

from pathlib import Path
from typing import Dict
from typing import Optional, List, Tuple, Union, TYPE_CHECKING, Callable

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from gensim.models import Word2Vec
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from torch_geometric.data import Data
from tqdm.auto import tqdm

# from source.utils.data.id_mapper import IDMapper
# from source.utils.fs.file_utils import FileUtils
# from source.utils.post.embedding_loader import EmbeddingLoader

from configuration.config import Config


class MathUtils:
    """
    A class for handling common processing tasks for embeddings.
    """

    @staticmethod
    def l2_normalize_torch(embeddings: torch.Tensor, eps: float = 1e-12) -> torch.Tensor:
        norm = torch.norm(embeddings, p=2, dim=-1, keepdim=True)
        return embeddings / (norm + eps)
