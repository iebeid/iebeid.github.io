import time

numbers_list = [1,2,3,4,5]
numbers_dictionary = {'a':1, 'b':2, 'c':3, 'd':4, 'e':5}


# print(numbers_dictionary['c'])

data_file_object = open("data.txt","r")
lines = data_file_object.readlines()
numbers_list_2 = []
for line in lines:
    numbers_list_2.append(int(line))
print(numbers_list_2)

data_file_object = open("data.txt","r")
lines = data_file_object.readlines()
numbers_dictionary_2 = dict()
counter = 0
for line in lines:
    numbers_dictionary_2[counter] = int(line)
    counter += 1
print(numbers_dictionary_2)

data_file_object = open("data.txt","r")
lines = data_file_object.readlines()
numbers_dictionary_2 = dict()
counter = 0
alphabetical_letter = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n']
for line in lines:
    numbers_dictionary_2[alphabetical_letter[counter]] = int(line)
    counter += 1
print(numbers_dictionary_2)


numbers_dictionary = {'a':1, 'b':2, 'c':3, 'd':4, 'e':5}
numbers_dictionary_2 = dict(numbers_dictionary)


numbers_dictionary = {'a':1, 'b':2, 'c':3, 'd':4, 'e':5}
if 'a' in numbers_dictionary.values():
    print(True)
else:
    print(False)

# A python dictionary is stored in hash tables

# implement a function that counts how many letters appeared in a word
# "banana" --> {'a':3, 'b':1, 'n':2}

def value_counts_slow(word):
    unique_letters = []
    for letter in word:
        if letter not in unique_letters:
            unique_letters.append(letter)
    word_counts = []
    for ul in unique_letters:
        counter = 0
        for letter in word:
            if ul == letter:
                counter +=1
        word_counts.append([ul, counter])
    print(word_counts)

def value_counts_fast(word):
    unique_counts = {}
    for letter in word:
        if letter in unique_counts.keys():
            unique_counts[letter]+=1
        else:
            unique_counts[letter] = 1
    print(unique_counts)



start_time = time.perf_counter()
value_counts_slow("banana")
end_time = time.perf_counter()
print(end_time - start_time)
start_time = time.perf_counter()
value_counts_fast("banana")
end_time = time.perf_counter()
print(end_time - start_time)


print("-"*80)

numbers_dictionary = {'a':1, 'b':2, 'c':3, 'd':4, 'e':5}
for key, value in numbers_dictionary.items():
    print(key, value)


numbers_dictionary = {'a':[1,2], 'b':[3,4], 'c':[5,6], 'd':[7,8], 'e':[9,10]}














