# lists --> arrays
from math import remainder

A = ['a','b','c','d']
# dictionaries --> hash tables --> lists
B = {0:'banana', 1:'book', 2:'apple', 3:'pen'}
# hash function --> b -> rank in the alphabet , b->2, a->1, n->13 -->
# 2+1+13=16 --> [,,,,,,,,,,'banana',,]
# sets {1,2,3,4}
# tuple (1,2,3,4) --> immutable
# t = (1,2,3,4)
# t1 = 1,2,3,4
# print(type(A))
# print(type(B))
# print(type(t))
# print(type(t1))
t = 15,
# print(type(t))

C = ["tuesday", "wensday"]
C[1] = "wednesday"
#print(C)


D = tuple("banana")
#print(D)


E = (5,8,10,22,3,7)
E = sorted(E)
E = tuple(reversed(E))
#print(E)


d = {}
d['a'] = [1,2,3,4,5]
d['b'] = [2]
d['c'] = [3,16]
d['d'] = [4]
d['e'] = [5,6]
#print(d)

a,b,c  = 1,2,3

email = 'monty@python.org'
username, domain = email.split('@')
# print(email)
# print(username)
# print(domain)


a = 200
b = 300
temp = a
a = b
b = temp

a,b=b,a


B = {0:'banana', 1:'book', 2:'apple', 3:'pen'}
# for key, value in B.items():
#     print(key, value)


quotient, remainder = divmod(7,3)
#print(quotient, remainder)

def min_max(list_of_numbers):
    return min(list_of_numbers), max(list_of_numbers)

#print(min_max([1,2,3,4,5]))

scores1 = [1, 2, 4, 5, 1, 5, 2]
scores2 = [5, 5, 2, 2, 5, 2, 3]
pairs = zip(scores1, scores2)
for pair in pairs:
    print(pair)








