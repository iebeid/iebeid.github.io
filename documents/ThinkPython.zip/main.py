import pygame

pygame.init()

color = (255, 255, 255)
rect_color = (255, 0, 0)
canvas = pygame.display.set_mode((500, 500))
pygame.display.set_caption("Static Rectangle")

exit = False

# A clock is needed to control animation speed (FPS)
clock = pygame.time.Clock()

rect_x = 30
rect_y = 30
# Hint, calculate the target (center) position

while not exit:
    canvas.fill(color)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            exit = True

    # --- PROBLEM ---
    # The position (30, 30) is "hard-coded".
    # It never changes, so the box never moves.
    # Hint add logic to run and update every frame, "animating" the state

    pygame.draw.rect(canvas, rect_color,
                     pygame.Rect(rect_x, rect_y, 60, 60))

    pygame.display.update()

    # Tell pygame to wait long enough to run at 60 FPS
    clock.tick(60)

pygame.quit()