# Import and initialize the Pygame library
import pygame

pygame.init()

# --- 1. Define Constants and Setup ---

# Screen dimensions
SCREEN_WIDTH = 500
SCREEN_HEIGHT = 500

# Rectangle dimensions
RECT_WIDTH = 60
RECT_HEIGHT = 60

# Colors (R, G, B)
WHITE = (255, 255, 255)
RED = (255, 0, 0)  # Color from article

# Create the game window (canvas)
# .set_mode() creates the display surface
canvas = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

# Set the window title
pygame.display.set_caption("My First Animation")

# --- 2. Define State Variables ---

# Create a clock to control the frame rate
clock = pygame.time.Clock()

# Set the rectangle's starting position
# We use variables so we can change them over time
rect_x = 30
rect_y = 30

# Calculate the target coordinates for the rectangle's TOP-LEFT corner
# to make its CENTER align with the SCREEN'S center.
# Target X = (Screen Center) - (Half Rectangle Width)
target_x = (SCREEN_WIDTH / 2) - (RECT_WIDTH / 2)
# Target Y = (Screen Center) - (Half Rectangle Height)
target_y = (SCREEN_HEIGHT / 2) - (RECT_HEIGHT / 2)

# --- 3. Main Game Loop ---

# The 'running' variable controls the game loop
running = True
while running:

    # --- 4. Event Handling ---

    # Check for all user events
    for event in pygame.event.get():
        # If the user clicks the window's 'X' button
        if event.type == pygame.QUIT:
            running = False  # Stop the loop

    # --- 5. Game Logic (Update State) ---

    # This is the animation logic
    # If the rectangle is not yet at its target X position...
    if rect_x < target_x:
        rect_x += 1  # ...move it 1 pixel to the right

    # If the rectangle is not yet at its target Y position...
    if rect_y < target_y:
        rect_y += 1  # ...move it 1 pixel down

    # --- 6. Drawing (Redraw Screen) ---

    # Fill the entire screen with a background color (white)
    # This "clears" the previous frame's drawing.
    canvas.fill(WHITE)

    # Draw the rectangle at its new (rect_x, rect_y) position
    # The arguments are (surface, color, (x, y, width, height))
    pygame.draw.rect(canvas, RED, (rect_x, rect_y, RECT_WIDTH, RECT_HEIGHT))

    # --- 7. Update Display and Control Speed ---

    # Push all our drawings to the screen
    pygame.display.update()

    # Limit the game to 60 frames per second (FPS)
    # This keeps the animation speed consistent
    clock.tick(60)

# --- 8. Quit ---

# Once the loop is 'running = False', quit Pygame
pygame.quit()